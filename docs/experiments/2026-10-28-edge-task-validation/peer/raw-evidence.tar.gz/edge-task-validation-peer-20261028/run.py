import subprocess, pathlib, hashlib, json, os, sys, datetime, platform, time
ROOT=pathlib.Path('/Users/wanglian/Projects/tangying-robot-agent-os')
OUT=pathlib.Path('/tmp/edge-task-validation-peer-20261028')
def snapshot():
    paths=sorted(p for p in ROOT.rglob('*.go') if not set(p.relative_to(ROOT).parts).intersection({'artifacts','.git','vendor','node_modules'}))
    paths += [ROOT/'go.mod', ROOT/'go.sum']
    files={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    return {'files':files,'digest':hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest()}
phase=sys.argv[1]; args=sys.argv[2:]; folder=OUT/phase; folder.mkdir()
cmd=['go','test','-json','-race',*args]
env=os.environ.copy(); env.update(GOTOOLCHAIN='local',GOPROXY='off',GOSUMDB='off'); env.pop('GOFLAGS',None); env.pop('GORACE',None)
for k in list(env):
    if k.startswith(('AGENT_','TANGYING_CONTEXT_','TANGYING_MODEL_')): env.pop(k)
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); before=snapshot()
metadata={'command':cmd,'cwd':str(ROOT),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'branch':subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip(),'go':subprocess.check_output(['go','version'],cwd=ROOT,text=True).strip(),'platform':platform.platform(),'startedAtUTC':start,'scope':'in-process scripted robot/model fixtures, real temporary SQLite and loopback HTTP/TLS only; no Gazebo/ROS/physical robot/real LLM','environmentOverrides':{'GOTOOLCHAIN':'local','GOPROXY':'off','GOSUMDB':'off','cleared':'GOFLAGS,GORACE,AGENT_*,TANGYING_CONTEXT_*,TANGYING_MODEL_*'}}
(folder/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n'); (folder/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
clock=time.monotonic()
with (folder/'go-test-events.jsonl').open('w') as out:
    process=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=out,stderr=subprocess.STDOUT)
    try: code=process.wait(timeout=240)
    except subprocess.TimeoutExpired: process.kill(); code=process.wait(); metadata['outerTimeout']=True
elapsed=time.monotonic()-clock; after=snapshot(); (folder/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
counts={}; failures=[]; nonjson=[]; experiment=[]
for line in (folder/'go-test-events.jsonl').read_text().splitlines():
    try: event=json.loads(line)
    except ValueError: nonjson.append(line); continue
    name=event.get('Test','')
    if name and '/' not in name and event.get('Action') in ('pass','fail','skip'):
        action=event['Action']; counts[action]=counts.get(action,0)+1
    if event.get('Action')=='fail': failures.append(event)
    if 'PEER_EXPERIMENT ' in event.get('Output','') or 'ROBOT_EXPERIMENT ' in event.get('Output',''): experiment.append(event)
result={'exitCode':code,'elapsedSeconds':elapsed,'endedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'topLevel':counts,'failures':failures,'nonJSONLines':nonjson,'sourceStable':before['digest']==after['digest'],'changedSource':[p for p in set(before['files'])|set(after['files']) if before['files'].get(p)!=after['files'].get(p)],'experimentLogLines':experiment,'beforeDigest':before['digest'],'afterDigest':after['digest']}
(folder/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['exitCode','elapsedSeconds','topLevel','sourceStable','changedSource']}));sys.exit(code)
