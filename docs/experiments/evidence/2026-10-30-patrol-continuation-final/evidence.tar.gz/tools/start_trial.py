"""Start only the isolated patrol simulation; never print or persist credentials."""
import os
import secrets
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
repo = root.parents[2]
run = root / 'run'
token = run / 'gazebo/navigation-token'
token.parent.mkdir(parents=True, exist_ok=True)
if token.exists():
    info = token.lstat()
    if not token.is_file() or token.is_symlink() or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise SystemExit('Existing trial credential is not a private owned regular file')
else:
    fd = os.open(token, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, 'w') as f:
        f.write(secrets.token_urlsafe(32))
env = {k: v for k, v in os.environ.items() if not k.startswith(('TANGYING_', 'AGENT_', 'SIM_STACK_', 'ROBOT_AGENT_'))}
env.update({
    'ROBOT_AGENT_CONFIG_DIR': str(root / 'config'),
    'SIM_STACK_GAZEBO_ASSETS_ROOT': str(root / 'assets'),
    'SIM_STACK_GAZEBO_IMAGE': 'tangying-navigation:patrol-trial-20261030',
    'SIM_STACK_GAZEBO_NAVIGATION_PORT': '18942',
    'SIM_STACK_LOCAL_AGENT': str(root / 'local-agent'),
    'SIM_STACK_STARTUP_TIMEOUT': '600',
    'ROS_DOMAIN_ID': '92',
    'TANGYING_NAVIGATION_URL': 'http://127.0.0.1:18942',
    'TANGYING_NAVIGATION_TOKEN': token.read_text().strip(),
    'TANGYING_NAVIGATION_MODE': 'mapping',
})
command = [str(repo / 'scripts/sim-stack.sh'), 'start', '--engine', 'gazebo', '--scene',
           'home_furnished', '--perception', 'rgbd', '--sim-port', '50462', '--agent-port',
           '8898', '--seed', '1016', '--artifacts-dir', str(run)]
with (root / 'startup.log').open('w') as log:
    code = subprocess.run(command, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT, check=False).returncode
print('Isolated simulation startup exit:', code)
sys.exit(code)
