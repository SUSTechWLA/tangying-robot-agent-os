import json,pathlib,datetime,math
b=pathlib.Path('artifacts/acceptance/patrol-continuation-20261030-001')
read=lambda n:json.loads((b/n).read_text())
t=read('task-001-closure/api-final-after-backup.json'); c=read('task-001-closure/report.json'); a=read('task-001-patrol-audit/report.json'); ix=read('task-001-closure/observations.json')
def ms(v):return datetime.datetime.fromisoformat(v.replace('Z','+00:00')).timestamp()*1000
records={(r['stepId'],r['captureId']):r for r in ix['records']}; sends={(e.get('stepId'),(e.get('payload') or {}).get('commandId')):e for e in t['events'] if e['type']=='TOOL_ACTIVITY' and (e.get('payload') or {}).get('activityStatus')=='SENDING'}; events={e['sequence']:e for e in t['events']}; stations=[]
for s in a['stations']:
 obs=records[(s['stepId'],s['captureId'])]['observedAtUnixMs'];send=sends[(s['stepId'],s['commandId'])];confirm=events[s['eventSequence']]
 stations.append({k:s[k] for k in ('station','tool','eventSequence','stepId','commandId','captureId','positionErrorM','yawErrorRad')}|{'commandSentAt':send['occurredAt'],'observationUnixMs':obs,'observationAfterSendMs':round(obs-ms(send['occurredAt']),3),'confirmedAt':confirm['occurredAt'],'confirmationAfterObservationMs':round(ms(confirm['occurredAt'])-obs,3)})
start=ms(t['approvedAt']);end=ms(c['timing']['terminalTransitionAt']);rows=[]
for name in ('ros-observations-002.jsonl','ros-observations-003.jsonl'):
 for l in (b/name).open():
  d=json.loads(l);o=d.get('latest',{}).get('odom');at=d.get('atUnixMs')
  if d.get('event')=='sample' and o and isinstance(at,(int,float)) and start<=at<=end:
   rows.append((at,o.get('sensorStampNs'),o.get('pose'),name))
rows.sort(); rows=[x for x in rows if x[2] and (x[3]=='ros-observations-003.jsonl' or x[0]<1793294744971)]
# fixed cutover chooses one recorder, no interpolation across overlapping samples
path=sum(math.dist(x[2][:2],y[2][:2]) for x,y in zip(rows,rows[1:])); gaps=[(y[0]-x[0])/1000 for x,y in zip(rows,rows[1:])]
r={'schemaVersion':'patrol.metrics.v1','taskId':t['id'],'state':t['state'],'taskRevision':t['currentRevision'],'auditPassed':a['passed'],'apiAndSqliteEventCount':c['journal']['databaseEventCount'],'apiAndSqliteExactMatch':c['journal']['exactMatch'],'apiObservationMatch':c['apiObservationsMatchBackup'],'closure':c['apiClosure'],'timing':c['timing'],'stations':stations,'providerUsage':{k:c['modelUsage'][k] for k in ('uniqueModelCallRecords','providerUsageValidCalls','providerUsageUnknownCalls','providerReportedTotals','providerCachedInputFraction','usageBoundary')},'independentSampledOdom':{'sources':['ros-observations-002.jsonl','ros-observations-003.jsonl'],'sampleCount':len(rows),'firstSampleUnixMs':rows[0][0],'lastSampleUnixMs':rows[-1][0],'maxGapSeconds':max(gaps),'sampledPlanarPathM':path,'definition':'Sum of XY differences between ordered 2 Hz sample poses during approval-to-terminal; recorder 002 cut off at first 003 sample to avoid overlap; odometry estimate, not ground truth; start/end are sample bounds.'},'limitations':['Simulation only; recorded odometry is not independent ground-truth positioning.','RGB-D evidence confirms retained identity/timing, not visual interpretation or physical arrival certification.','No independent contact sensor stream; no assertion of zero collisions.','Provider-reported usage, not billing invoice; cached input is a subset of prompt tokens.']}
(b/'task-001-metrics.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'stations':stations,'timing':r['timing'],'usage':r['providerUsage'],'odom':r['independentSampledOdom']},ensure_ascii=False,indent=2))
