"""Passively sample simulation state at 2 Hz; never publish or issue motion."""
import json
import time
from pathlib import Path

import rclpy
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import JointState, PointCloud2
from std_msgs.msg import String

rclpy.init()
node = Node('patrol_independent_observer')
latest = {}
counts = dict.fromkeys(('odom', 'joints', 'suction', 'base_cloud', 'head_cloud'), 0)
stop = Path('/data/maps/patrol-monitor.stop')
started = time.monotonic()


def on_message(kind, message):
    counts[kind] += 1
    row = {'receiptUnixMs': int(time.time() * 1000), 'receiptMonotonicNs': time.monotonic_ns()}
    if kind == 'suction':
        row['value'] = json.loads(message.data)
    else:
        row['sensorStampNs'] = message.header.stamp.sec * 10**9 + message.header.stamp.nanosec
        row['frameId'] = message.header.frame_id
        if kind == 'odom':
            p, v = message.pose.pose, message.twist.twist
            row['pose'] = [p.position.x, p.position.y, p.position.z, p.orientation.w,
                           p.orientation.x, p.orientation.y, p.orientation.z]
            row['linear'] = [v.linear.x, v.linear.y, v.linear.z]
            row['angular'] = [v.angular.x, v.angular.y, v.angular.z]
        elif kind == 'joints':
            row.update(names=list(message.name), positions=list(message.position), velocities=list(message.velocity))
        else:
            row['width'], row['height'] = message.width, message.height
    latest[kind] = row


for kind, topic, message_type in (
    ('odom', '/odom', Odometry), ('joints', '/joint_states', JointState),
    ('suction', '/tangying/suction/state', String),
    ('base_cloud', '/camera/base/nav_points', PointCloud2),
    ('head_cloud', '/camera/head/nav_points', PointCloud2),
):
    node.create_subscription(message_type, topic, lambda m, k=kind: on_message(k, m), qos_profile_sensor_data)

last = -1.0
try:
    while time.monotonic() - started < 2100 and not stop.exists():
        rclpy.spin_once(node, timeout_sec=.05)
        now = time.monotonic()
        if now - last >= .5:
            print(json.dumps({'event': 'sample', 'atUnixMs': int(time.time() * 1000),
                              'elapsedSeconds': now-started, 'counts': counts, 'latest': latest}), flush=True)
            last = now
finally:
    print(json.dumps({'event': 'end', 'durationSeconds': time.monotonic()-started,
                      'counts': counts, 'scope': 'read-only, starts after survey has begun'}), flush=True)
    node.destroy_node()
    rclpy.shutdown()
