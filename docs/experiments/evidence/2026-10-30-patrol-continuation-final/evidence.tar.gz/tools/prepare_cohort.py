from pathlib import Path
import hashlib,json,tarfile,subprocess
repo=Path.cwd();out=repo/'artifacts/acceptance/patrol-continuation-20261030-001/cohort-002';container='tangying-gazebo-c482ffb4bd95-gazebo-house-1';remote='/tmp/tangying-patrol-continuation-20261030-001/cohort-002'
out.mkdir(parents=True,exist_ok=False)
packages=['robot/gateway/tangying_robot_gateway','robot/ros2_ws/src/tangying_navigation/tangying_navigation']
files=[]
for package in packages:
 files.extend(p for p in (repo/package).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
manifest={str(p.relative_to(repo)):{'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)}
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
tests=['robot/gateway/tests/test_operational_envelope.py','tests/install/test_gazebo_runtime_freshness.py','robot/gateway/tests/test_survey_continuation_bootstrap.py','robot/gateway/tests/test_semantic_cloud_services.py','robot/gateway/tests/test_robot_services.py','robot/gateway/tests/test_gazebo_workflow.py','robot/gateway/tests/test_survey.py','robot/gateway/tests/test_slam_semantics.py','tests/install/test_gazebo_runtime_freshness.py','robot/ros2_ws/src/tangying_navigation/test/test_navigation_node.py','robot/ros2_ws/src/tangying_navigation/test/conftest.py']
for p in list(files)+[repo/t for t in tests]:
 for parent in p.parents:
  if parent==repo:break
  init=parent/'__init__.py'
  if init.is_file() and init not in files:files.append(init)
files.extend(repo/t for t in tests)
files.append(repo/'robot/gateway/tests/test_gazebo_backend.py')
with tarfile.open(out/'source-and-tests.tar.gz','w:gz') as tar:
 for p in sorted(set(files)):tar.add(p,arcname=str(p.relative_to(repo)))
subprocess.run(['docker','exec',container,'mkdir','-p',remote+'/source'],check=True)
subprocess.run(['docker','cp',str(out/'source-and-tests.tar.gz'),container+':'+remote+'/source-and-tests.tar.gz'],check=True)
subprocess.run(['docker','cp',str(out/'source-manifest.json'),container+':'+remote+'/source-manifest.json'],check=True)
subprocess.run(['docker','exec',container,'tar','-xzf',remote+'/source-and-tests.tar.gz','-C',remote+'/source'],check=True)
print(json.dumps({'sourceFiles':len(manifest),'archiveSha256':hashlib.sha256((out/'source-and-tests.tar.gz').read_bytes()).hexdigest()}))
