"""Offline audit tests. The success fixture derives from historical captures but
rewrites the task/metadata and is synthetic, not a new robot execution."""
import hashlib
import importlib.util
import json
import sqlite3
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('patrol_audit', HERE/'audit_patrol.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
ROOT = HERE.parents[3]
OLD = ROOT/'artifacts/gazebo-xlerobot-tasks-trial-29'


def fixture(tmp_path, mutation=''):
    old = OLD/'patrol-1'
    task = json.loads((old/'final-task.json').read_text())
    index = json.loads((old/'observation-index.json').read_text())
    robot = 'gazebo-home_furnished'
    task['plan'] = {'capabilities': {'robotId': robot, 'calls': [{'tool':'robot.task',
        'legacyIntent': {'routeRooms':['卧室','卫生间','客厅']}}]}}
    if mutation in ('split_route', 'split_out_of_order', 'split_missing', 'split_duplicate', 'split_empty'):
        routes = [['bedroom'], ['卫生间'], ['客厅']]
        if mutation == 'split_out_of_order': routes[0], routes[1] = routes[1], routes[0]
        if mutation == 'split_missing': routes.pop(1)
        if mutation == 'split_duplicate': routes.insert(1, ['bedroom'])
        if mutation == 'split_empty': routes.insert(1, [])
        task['plan']['capabilities']['calls'] = [
            {'tool':'robot.task', 'legacyIntent':{'routeRooms': rooms}} for rooms in routes
        ]
    relevant = []
    for event in task['events']:
        payload = event.get('payload') or {}
        if event.get('type') == 'TOOL_ACTIVITY' and payload.get('toolName') in ('navigation.navigate','verify_arrival'):
            payload['robotId'] = robot
            if payload.get('activityStatus') == 'CONFIRMED':
                relevant.append((event['stepId'], payload['receiptObservationId']))
    if mutation == 'missing_verify':
        task['events'] = [e for e in task['events'] if not (e.get('type') == 'TOOL_ACTIVITY'
            and e.get('stepId') == relevant[1][0] and (e.get('payload') or {}).get('activityStatus') == 'CONFIRMED')]
    sequence = max(e['sequence'] for e in task['events'])
    for event_type, payload in [('state.transition', {'state':'SUCCEEDED'}),
                                ('LOCAL_RUN_SUCCEEDED', {'taskRevision':1}),
                                ('LOCAL_RUN_FINISHED', {'state':'SUCCEEDED','taskRevision':1})]:
        if mutation == 'missing_finish' and event_type == 'LOCAL_RUN_FINISHED':
            continue
        sequence += 1
        task['events'].append({'sequence':sequence,'type':event_type,'stepId':'','message':'',
                               'payload':payload,'occurredAt':'2026-09-27T00:00:00Z'})
    index['records'] = [r for r in index['records'] if (r.get('stepId'), r.get('captureId')) in relevant]
    if mutation == 'premature_observation': index['records'][0]['observedAtUnixMs'] = 1
    database = tmp_path/'journal.sqlite'
    with sqlite3.connect(database) as db:
        db.executescript('CREATE TABLE tasks(id TEXT, request TEXT, state TEXT, current_revision INT, approved INT, plan_json TEXT);'
                         'CREATE TABLE task_events(task_id TEXT, sequence INT, type TEXT, step_id TEXT, message TEXT, payload_json TEXT, occurred_at TEXT);'
                         'CREATE TABLE observation_evidence(task_id TEXT, record_index INT, metadata_json TEXT, snapshot_json BLOB, rgb BLOB, depth BLOB, expired INT);')
        db.execute('INSERT INTO tasks VALUES(?,?,?,?,?,?)',(task['id'],task['request'],task['state'],1,1,json.dumps(task['plan'])))
        for e in task['events']:
            db.execute('INSERT INTO task_events VALUES(?,?,?,?,?,?,?)',(task['id'],e['sequence'],e['type'],e.get('stepId',''),
                e.get('message',''),json.dumps(e.get('payload')),e['occurredAt']))
        for r in index['records']:
            data = json.loads((old/(r['id']+'.json')).read_text()); snapshot = json.dumps(data['snapshot'],ensure_ascii=False,separators=(',',':')).encode()
            r['snapshotSha256'] = hashlib.sha256(snapshot).hexdigest()
            meta = dict(r); record_index = meta.pop('recordIndex'); expired = meta.pop('expired')
            rgb = (old/(r['id']+'-rgb.png')).read_bytes(); depth = (old/(r['id']+'-depth.png')).read_bytes()
            if mutation == 'bad_image' and r['stepId'] == relevant[0][0]: rgb += b'tamper'
            db.execute('INSERT INTO observation_evidence VALUES(?,?,?,?,?,?,?)',(task['id'],record_index,json.dumps(meta),snapshot,rgb,depth,expired))
    closure = {'taskId':task['id'],'closureVerified':True,'taskSucceeded':True,'journal':{'backupSHA256':hashlib.sha256(database.read_bytes()).hexdigest()}}
    paths = [tmp_path/'task.json',tmp_path/'index.json',tmp_path/'telemetry.json',tmp_path/'closure.json']
    telemetry = json.loads((OLD/'initial-telemetry.json').read_text())
    if mutation == 'wrong_goal': telemetry['robotState']['semantic_navigation']['goals']['bathroom'][0] += 1
    if mutation == 'wrong_version': telemetry['robotState']['semantic_navigation']['mapRevision'] = 'wrong'
    for path, value in zip(paths,(task,index,telemetry,closure)): path.write_text(json.dumps(value,ensure_ascii=False))
    return (*paths,database,tmp_path/'out')


@pytest.mark.parametrize('mutation,expected', [('',True),('missing_verify',False),('bad_image',False),
    ('wrong_goal',False),('missing_finish',False),('premature_observation',False),
    ('split_route',True),('split_out_of_order',False),('split_missing',False),
    ('split_duplicate',False),('split_empty',False),('wrong_version',False)])
def test_offline_audit_requires_six_independent_matching_evidence_chains(tmp_path, mutation, expected):
    result = audit.audit(*fixture(tmp_path,mutation))
    assert result['passed'] is expected, result['errors']
    if expected:
        assert len(result['stations']) == 6
        assert len({x['commandId'] for x in result['stations']}) == 6
        assert len({x['captureId'] for x in result['stations']}) == 6
        assert len(list((tmp_path/'out').glob('*.png'))) == 12
