"""Read-only 5s ROS probe; nearest receipt pairs do not imply synchronization."""
import json
import time
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import PointCloud2
from nav_msgs.msg import Odometry
from rosgraph_msgs.msg import Clock

class Probe(Node):
    def __init__(self):
        super().__init__('guard_clock_probe')
        self.samples = {k: [] for k in ('base', 'head', 'odom', 'clock')}
        for name, topic, kind in [('base', '/camera/base/nav_points', PointCloud2),
                                  ('head', '/camera/head/nav_points', PointCloud2),
                                  ('odom', '/odom', Odometry), ('clock', '/clock', Clock)]:
            self.create_subscription(kind, topic, lambda msg, n=name: self.record(n, msg), qos_profile_sensor_data)
    def record(self, name, msg):
        ts = msg.clock if name == 'clock' else msg.header.stamp
        self.samples[name].append((time.monotonic_ns(), ts.sec * 1_000_000_000 + ts.nanosec))

rclpy.init()
probe = Probe()
end = time.monotonic() + 5
while time.monotonic() < end:
    rclpy.spin_once(probe, timeout_sec=.1)
out = {'scope': 'read-only; nearest callback receipt pairs, not synchronized exposures',
       'counts': {k: len(v) for k, v in probe.samples.items()}}
for camera in ('base', 'head'):
    out[camera] = {'distinctSensorStamps': len(set(stamp for _, stamp in probe.samples[camera]))}
    for other in ('odom', 'clock'):
        diffs = []
        for received, stamp in probe.samples[camera]:
            if probe.samples[other]:
                pair = min(probe.samples[other], key=lambda x: abs(x[0] - received))
                diffs.append((pair[1] - stamp) / 1e6)
        out[camera][other + 'MinusCloudMs'] = {'min': min(diffs), 'max': max(diffs)} if diffs else None
print(json.dumps(out))
probe.destroy_node()
rclpy.shutdown()
