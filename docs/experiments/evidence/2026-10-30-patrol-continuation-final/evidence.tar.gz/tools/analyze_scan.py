"""Summarize one operation's persisted bounded-step and sampled ROS evidence."""
import argparse
import json
import math
from collections import Counter
from itertools import pairwise
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--operation', required=True)
p.add_argument('--steps', required=True, type=Path)
p.add_argument('--ros', required=True, nargs='+', type=Path)
p.add_argument('--output', required=True, type=Path)
a = p.parse_args()
steps = [json.loads(line) for line in a.steps.read_text().splitlines() if line.strip()]
ended = [s for s in steps if s.get('operationId') == a.operation and s.get('event') == 'ended']
if not ended:
    raise SystemExit('no persisted end records for operation')
start = min(int(x['stepStartedMonotonicNs']) for x in ended)
finish = max(int(x['checkedAtMonotonicNs']) for x in ended)
samples = []
for path in a.ros:
    for line in path.read_text().splitlines():
        row = json.loads(line)
        odom = (row.get('latest') or {}).get('odom') or {}
        stamp = odom.get('receiptMonotonicNs')
        if isinstance(stamp, int) and start <= stamp <= finish:
            pose = odom['pose']
            if len(pose) == 7 and all(isinstance(x, (float, int)) and math.isfinite(x) for x in pose):
                samples.append((stamp, pose))
samples.sort(key=lambda x: x[0])
distance = sum(math.hypot(q[1][0]-p[1][0], q[1][1]-p[1][1]) for p, q in pairwise(samples))
gaps = [(q[0]-p[0])/1e9 for p, q in pairwise(samples)]
out = {'operationId': a.operation, 'endedSteps': len(ended),
       'outcomes': dict(Counter(x.get('outcomeCode', 'missing') for x in ended)),
       'nonzeroPublishedPulses': sum(x.get('nonzeroPublishedPulseCount', 0) for x in ended),
       'finalStopPublishedSteps': sum(x.get('finalZeroPublished') is True for x in ended),
       'observationHoldCount': sum(x.get('observationHoldCount', 0) for x in ended),
       'firstStepStartedMonotonicNs': str(start), 'lastStepEndedMonotonicNs': str(finish),
       'sampledOdomMessages': len(samples), 'sampledOdomPathM': distance if len(samples) >= 2 else None,
       'maxOdomSampleGapSeconds': max(gaps) if gaps else None,
       'scope': '2 Hz sampled odometry between first and last recorded bounded step; not ground truth or continuous collision proof'}
a.output.write_text(json.dumps(out, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(out, ensure_ascii=False))
