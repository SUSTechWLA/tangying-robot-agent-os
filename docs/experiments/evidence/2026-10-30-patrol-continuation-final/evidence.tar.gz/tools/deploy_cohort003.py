"""Explicitly deploy a complete frozen cohort to the isolated patrol container.

The caller MUST first independently establish that the prior operation is
terminal and the robot is stationary. Never targets Gazebo or RTABMap. Secrets
from process environments are used in memory only and are never recorded.
"""
import hashlib
import json
import os
import signal
import subprocess
import sys
import tarfile
import time
from pathlib import Path

OUT = Path('/tmp/tangying-patrol-continuation-20261030-001/cohort-003')
ROOTS = {
    'robot/gateway/tangying_robot_gateway': Path('/opt/tangying-gateway/tangying_robot_gateway'),
    'robot/ros2_ws/src/tangying_navigation/tangying_navigation': Path('/opt/tangying-nav/install/tangying_navigation/lib/python3.12/site-packages/tangying_navigation'),
}


def target(name):
    for prefix, path in ROOTS.items():
        if name.startswith(prefix+'/'):
            return path/name[len(prefix)+1:]
    raise ValueError('unexpected source path')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def process_birth(pid):
    try:
        stat = Path(f'/proc/{pid}/stat').read_text()
        fields = stat[stat.rfind(')')+2:].split()
        return None if fields[0] == 'Z' else fields[19]
    except FileNotFoundError:
        return None


def controlled_stop(processes, *, now, sleep, birth, kill, restart, competitors, timeout=15):
    """Never alter files unless every original consumer is stopped.

    If a stop fails, launch replacements only for original processes that really
    stopped. Do not signal a reused PID. The caller must record the result and
    separately verify replacement health; a successful spawn is not readiness.
    """
    failures = []
    for proc in processes:
        try:
            if birth(proc['pid']) != proc['birth']:
                raise RuntimeError('process identity changed before signal')
            kill(proc['pid'], signal.SIGINT)
        except (OSError, RuntimeError) as error:
            failures.append({'role':proc['role'], 'stage':'signal', 'errorType':type(error).__name__})
    deadline = now()+timeout
    while now() < deadline and any(birth(p['pid']) == p['birth'] for p in processes):
        sleep(.1)
    remaining = [p['role'] for p in processes if birth(p['pid']) == p['birth']]
    if remaining:
        failures.append({'role':','.join(remaining), 'stage':'stop_timeout', 'errorType':'TimeoutError'})
    restarted = []
    if failures:
        for proc in processes:
            current_birth = birth(proc['pid'])
            if current_birth == proc['birth']:
                continue
            if current_birth is not None or competitors(proc):
                failures.append({'role':proc['role'], 'stage':'restart_skipped_ambiguous_identity',
                                 'errorType':'IdentityAmbiguous'})
                continue
            try:
                child = restart(proc)
                restarted.append({'role':proc['role'], 'oldPid':proc['pid'], 'newPid':child.pid})
            except (OSError, RuntimeError) as error:
                failures.append({'role':proc['role'], 'stage':'restart', 'errorType':type(error).__name__})
    return {'allStopped': not failures, 'failures':failures, 'remainingRoles':remaining,
            'restarted':restarted, 'replacementHealthVerified':False}


def main():
    if sys.argv[1:] != ['--apply']:
        raise SystemExit('Verify terminal/stationary independently, then pass --apply; no changes made.')
    manifest = json.loads((OUT/'source-manifest.json').read_text())
    source = OUT/'source'
    if process_birth(27) is None or process_birth(35) is None:
        raise RuntimeError('original world/RTABMap not alive')
    entry = Path('/usr/local/bin/tangying-navigation')
    entry_sha = sha(entry)
    if entry_sha != 'c2711c239e25e9738b40d0c85668d9a25a308e22b89438c1d5494ada84a53466':
        raise RuntimeError('entrypoint identity changed')
    processes = []
    for role,pid in [('runtime',11036),('navigation',11037)]:
        birth = process_birth(pid)
        if birth is None:
            raise RuntimeError(role+' not running')
        # Never persist or print these variables; they can contain credentials.
        env = {k.decode():v.decode() for item in Path(f'/proc/{pid}/environ').read_bytes().split(b'\0') if item
               for k,v in [item.split(b'=',1)]}
        command = [x.decode() for x in Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0') if x]
        if not any(arg.endswith('/gazebo_runtime' if role=='runtime' else '/navigation_http') for arg in command):
            raise RuntimeError(role+' process identity mismatch')
        processes.append({'role':role,'pid':pid,'birth':birth,'env':env,'command':command})
    for name, entry_data in manifest.items():
        if sha(source/name) != entry_data['sha256']:
            raise RuntimeError('source manifest mismatch')
    before = {name:{'size':target(name).stat().st_size,'sha256':sha(target(name)),
                    'mode':target(name).stat().st_mode & 0o777} for name in manifest}
    (OUT/'installed-before-manifest.json').write_text(json.dumps(before,indent=2)+'\n')
    with tarfile.open(OUT/'installed-before.tar.gz','w:gz') as tar:
        for name in manifest:
            tar.add(target(name),arcname=name)

    def restart(proc):
        # Consumer output might contain secrets; it is deliberately not retained.
        return subprocess.Popen(proc['command'],env=proc['env'],cwd='/opt/tangying-nav',
                                stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)

    def competitors(proc):
        suffix = '/gazebo_runtime' if proc['role'] == 'runtime' else '/navigation_http'
        for directory in Path('/proc').iterdir():
            if not directory.name.isdecimal() or int(directory.name) == proc['pid']:
                continue
            try:
                command = (directory/'cmdline').read_bytes().split(b'\0')
            except (FileNotFoundError, PermissionError, ProcessLookupError):
                continue
            if any(arg.decode(errors='replace').endswith(suffix) for arg in command):
                return True
        return False

    stopped = controlled_stop(processes,now=time.monotonic,sleep=time.sleep,birth=process_birth,
                              kill=os.kill,restart=restart,competitors=competitors)
    (OUT/'stop-result.json').write_text(json.dumps(stopped,indent=2)+'\n')
    if not stopped['allStopped']:
        raise SystemExit('Stop incomplete; no package files changed. See stop-result.json; replacement health is unverified.')
    try:
        for name in manifest:
            dest = target(name); tmp = dest.with_name(dest.name+'.cohort003.tmp')
            tmp.write_bytes((source/name).read_bytes()); os.chmod(tmp,before[name]['mode']); os.replace(tmp,dest)
        for package in ROOTS.values():
            for path in package.rglob('*.pyc'):
                path.unlink()
        installed = {name:{'size':target(name).stat().st_size,'sha256':sha(target(name))} for name in manifest}
        if installed != manifest:
            raise RuntimeError('installed/source mismatch')
        (OUT/'installed-cohort-manifest.json').write_text(json.dumps(installed,indent=2)+'\n')
        check = 'from tangying_robot_gateway import robot_workflow,survey,gazebo_backend; from tangying_navigation import navigation_node,gazebo_runtime_node; print("imports ok")'
        result = subprocess.run(['/usr/bin/python3','-c',check],env=processes[0]['env'],
                                stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=20,check=False)
        if result.returncode:
            raise RuntimeError('coherent import check failed')
    except BaseException as error:
        rollback = {'failureType':type(error).__name__, 'restoredFilesVerified':False,
                    'restarted':[], 'restartFailures':[], 'replacementHealthVerified':False}
        try:
            with tarfile.open(OUT/'installed-before.tar.gz') as tar:
                for member in tar.getmembers():
                    dest = target(member.name); tmp = dest.with_name(dest.name+'.rollback.tmp')
                    tmp.write_bytes(tar.extractfile(member).read()); os.chmod(tmp,before[member.name]['mode']); os.replace(tmp,dest)
            rollback['restoredFilesVerified'] = all(sha(target(name)) == data['sha256'] for name,data in before.items())
        except BaseException as rollback_error:  # noqa: BLE001 - preserve failed rollback evidence.
            rollback['restoreFailureType'] = type(rollback_error).__name__
        if rollback['restoredFilesVerified']:
            for proc in processes:
                try:
                    child = restart(proc)
                    rollback['restarted'].append({'role':proc['role'],'newPid':child.pid})
                except OSError as restart_error:
                    rollback['restartFailures'].append({'role':proc['role'],'errorType':type(restart_error).__name__})
        (OUT/'rollback-result.json').write_text(json.dumps(rollback,indent=2)+'\n')
        raise
    started = []
    try:
        for proc in processes:
            child = restart(proc)
            started.append({'role':proc['role'],'oldPid':proc['pid'],'newPid':child.pid})
    finally:
        record = {'method':'consumer-level coherent installation','atomicDirectoryExchange':False,
                  'sourceFiles':len(manifest),'entrypointSha256':entry_sha,'gazeboPid':27,'rtabmapPid':35,
                  'gazeboAndRTABMapStayedAlive':process_birth(27) is not None and process_birth(35) is not None,
                  'manualPrecondition':'terminal scan and independent stationary verification',
                  'replacementHealthVerified':False,'processes':started}
        (OUT/'deployment.json').write_text(json.dumps(record,indent=2)+'\n')
    if sha(entry) != entry_sha:
        raise RuntimeError('entrypoint changed; verify runtime manually')
    print(json.dumps(record))


if __name__ == '__main__':
    main()
