"""No Docker or signals: check partial-stop and PID reuse handling."""
import importlib.util
from pathlib import Path
from types import SimpleNamespace

spec = importlib.util.spec_from_file_location('trial_deploy', Path(__file__).with_name('deploy_cohort_in_container.py'))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def run(behaviour, competitor=False):
    now = [0.]
    live = {42:'birth42', 41:'birth41'}
    calls, starts = [], []
    processes = [{'role':'runtime','pid':42,'birth':'birth42'}, {'role':'navigation','pid':41,'birth':'birth41'}]
    def signal_pid(pid, sig):
        calls.append(pid)
        if behaviour == 'timeout' and pid == 41:
            return
        if behaviour == 'signal_error' and pid == 41:
            raise PermissionError()
        live.pop(pid)
    if behaviour == 'reused':
        live[42] = 'another-process'
    def restart(proc):
        starts.append(proc['role'])
        return SimpleNamespace(pid=1000+proc['pid'])
    def sleep(_): now[0] += .2
    result = mod.controlled_stop(processes, now=lambda:now[0], sleep=sleep, birth=live.get,
                                 kill=signal_pid, restart=restart, competitors=lambda proc:competitor,
                                 timeout=.5)
    return result, calls, starts


def test_both_stop_allows_install_and_no_restart():
    result, calls, starts = run('success')
    assert result['allStopped'] and calls == [42,41] and starts == []


def test_partial_stop_restarts_only_stopped_role_without_files_change():
    result, calls, starts = run('timeout')
    assert not result['allStopped'] and result['remainingRoles'] == ['navigation']
    assert calls == [42,41] and starts == ['runtime'] and not result['replacementHealthVerified']


def test_signal_failure_recovers_stopped_peer_and_records_error():
    result, _, starts = run('signal_error')
    assert not result['allStopped'] and starts == ['runtime']
    assert any(e['stage'] == 'signal' for e in result['failures'])


def test_reused_pid_never_signalled_or_treated_as_safe_to_restart():
    result, calls, starts = run('reused')
    assert not result['allStopped'] and 42 not in calls and starts == ['navigation']
    assert any(e['stage'] == 'restart_skipped_ambiguous_identity' for e in result['failures'])


def test_existing_competitor_blocks_automatic_restart():
    result, _, starts = run('timeout', competitor=True)
    assert not result['allStopped'] and starts == []
    assert any(e['stage'] == 'restart_skipped_ambiguous_identity' for e in result['failures'])
