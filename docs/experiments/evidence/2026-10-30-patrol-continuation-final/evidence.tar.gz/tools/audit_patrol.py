#!/usr/bin/env python3
"""Offline audit of a three-stop robot.task against a consistent SQLite backup.

No network or robot control. Inputs: collector API task/index + its backup/report,
and a pre-execution telemetry snapshot with active_map and semantic_navigation.
Outputs retained raw evidence bytes/hashes and an explicit PASS/FAIL report.
"""
import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import math
import re
import sqlite3
from pathlib import Path

ROOT = next(parent for parent in Path(__file__).resolve().parents if (parent/'go.mod').is_file())
COLLECTOR = ROOT / 'docs/experiments/2026-10-28-user-workbench-e2e/metrics-audit/collect_task_closure.py'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pose_error(a, b):
    for p in (a, b):
        if not isinstance(p, list) or len(p) != 7 or any(type(v) not in (float, int) or not math.isfinite(v) for v in p):
            raise ValueError('pose must contain seven finite numbers')
        if abs(sum(v*v for v in p[3:])-1) > .001:
            raise ValueError('pose quaternion is not normalized')
    def yaw(p):
        w, x, y, z = p[3:]
        return math.atan2(2*(w*z+x*y), 1-2*(y*y+z*z))
    angle = yaw(a)-yaw(b)
    return math.hypot(a[0]-b[0], a[1]-b[1]), abs(math.atan2(math.sin(angle), math.cos(angle)))


def time_ms(s):
    return dt.datetime.fromisoformat(s).timestamp() * 1000


def audit(task_path, index_path, telemetry_path, report_path, db_path, output):
    output.mkdir(parents=True, exist_ok=False)
    task, index, telemetry, closure = [json.loads(p.read_text()) for p in (task_path, index_path, telemetry_path, report_path)]
    spec = importlib.util.spec_from_file_location('audit_closure', COLLECTOR)
    collector = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(collector)
    errors, stations = [], []
    def check(value, message):
        if not value:
            errors.append(message)
        return bool(value)
    tid, rev = task.get('id'), task.get('currentRevision')
    plan = (task.get('plan') or {}).get('capabilities') or {}
    robot = plan.get('robotId')
    calls = plan.get('calls') or []
    telemetry = telemetry.get('latest', telemetry)
    state = telemetry.get('robotState') or {}
    active = state.get('active_map') or {}
    semantic = state.get('semantic_navigation') or {}
    targets = semantic.get('goals') or {}
    keys = ('mapId', 'mapRevision', 'calibrationRevision')
    check(task.get('state') == 'SUCCEEDED', 'task is not SUCCEEDED')
    check(task.get('approved') is True, 'task was not approved')
    check(bool(robot) and telemetry.get('robotId') == robot, 'preflight robot identity mismatch or unavailable')
    check(index.get('taskId') == tid, 'observation index task identity mismatch')
    check(all(isinstance(active.get(k), str) and active[k] and semantic.get(k) == active[k] for k in keys), 'map/semantic version identity mismatch')
    check(semantic.get('frameId') == 'world', 'target frame is not world')
    expected = ['bedroom', 'bathroom', 'living_room']
    route_calls = [c for c in calls if isinstance(c, dict) and c.get('tool') == 'robot.task']
    route = []
    valid_route_calls = bool(route_calls)
    for call in route_calls:
        intent = call.get('legacyIntent')
        rooms = intent.get('routeRooms') if isinstance(intent, dict) else None
        if not isinstance(rooms, list) or not rooms or not all(isinstance(x, str) for x in rooms):
            valid_route_calls = False
            continue
        route.extend(rooms)
    aliases = {'卧室': 'bedroom', '卫生间': 'bathroom', '浴室': 'bathroom', '客厅': 'living_room'}
    check(valid_route_calls and [aliases.get(x, x) for x in route] == expected, 'frozen robot.task route is not the full required sequence')
    for name in expected:
        try:
            pose_error(targets[name], targets[name])
        except (KeyError, ValueError, TypeError):
            errors.append('missing/invalid preflight target: '+name)
    check(closure.get('taskId') == tid and closure.get('closureVerified') is True and closure.get('taskSucceeded') is True, 'collector did not verify successful closure')
    check(closure.get('journal', {}).get('backupSHA256') == sha(db_path.read_bytes()), 'SQLite snapshot hash differs from collector')
    check(collector.closure_status(task)['verified'], 'LOCAL_RUN_FINISHED/SUCCEEDED markers not verified for this revision')
    with sqlite3.connect(db_path.resolve().as_uri()+'?mode=ro&immutable=1', uri=True) as db:
        db.row_factory = sqlite3.Row
        row = db.execute('SELECT * FROM tasks WHERE id=?', (tid,)).fetchone()
        check(row is not None, 'task missing from SQLite snapshot')
        if row is not None:
            expected_fields = {'id':row['id'], 'request':row['request'], 'state':row['state'], 'currentRevision':row['current_revision'],
                               'approved':bool(row['approved']), 'plan':json.loads(row['plan_json'])}
            check(all(task.get(k) == v for k, v in expected_fields.items()), 'task/plan mismatch between API and SQLite')
        events = []
        for row in db.execute('SELECT sequence,type,step_id,message,payload_json,occurred_at FROM task_events WHERE task_id=? ORDER BY sequence', (tid,)):
            events.append({'sequence':row['sequence'],'type':row['type'],'stepId':row['step_id'],'message':row['message'],
                           'payload':json.loads(row['payload_json']),'occurredAt':row['occurred_at']})
        check([collector.event_projection(x) for x in task.get('events', [])] == [collector.event_projection(x) for x in events], 'API and SQLite event ledgers differ')
        records = {}
        for row in db.execute('SELECT record_index,metadata_json,snapshot_json,rgb,depth,expired FROM observation_evidence WHERE task_id=?', (tid,)):
            meta = json.loads(row['metadata_json']); meta['recordIndex'] = row['record_index']; meta['expired'] = bool(row['expired'])
            records[(meta.get('stepId'), meta.get('captureId'))] = (meta, row['snapshot_json'], row['rgb'], row['depth'])
    index_records = {(r.get('stepId'), r.get('captureId')):r for r in index.get('records', [])}
    sent = {}
    confirmed = []
    for e in task.get('events', []):
        p = e.get('payload') or {}
        if e.get('type') != 'TOOL_ACTIVITY':
            continue
        if p.get('activityStatus') == 'SENDING':
            sent[(e.get('stepId'), p.get('commandId'))] = time_ms(e['occurredAt'])
        if p.get('activityStatus') == 'CONFIRMED' and p.get('toolName') in ('navigation.navigate', 'verify_arrival'):
            confirmed.append(e)
    check(len(confirmed) == 6, f'expected exactly six navigation/verification confirmations, found {len(confirmed)}')
    used_commands, used_captures = set(), set()
    for position, e in enumerate(confirmed):
        p = e['payload']; name = expected[position//2] if position < 6 else 'unexpected'
        kind = 'navigation.navigate' if position % 2 == 0 else 'verify_arrival'
        item = {'station':name,'tool':p.get('toolName'),'eventSequence':e.get('sequence'),
                'stepId':e.get('stepId'),'commandId':p.get('commandId'),'captureId':p.get('receiptObservationId')}
        stations.append(item)
        check(p.get('toolName') == kind, f'{name}: expected {kind} in sequence')
        command, capture = item['commandId'], item['captureId']
        check(isinstance(command,str) and command.startswith(str(tid)+'/') and command not in used_commands, f'{name} {kind}: command identity missing/repeated')
        check(isinstance(capture,str) and capture and capture not in used_captures, f'{name} {kind}: capture identity missing/repeated')
        used_commands.add(command); used_captures.add(capture)
        check(p.get('robotId') == robot and p.get('taskRevision') == rev and p.get('evidenceSource') == 'command_observation', f'{name} {kind}: activity identity/evidence mismatch')
        rec = records.get((item['stepId'], capture)); indexed = index_records.get((item['stepId'], capture))
        if not check(rec is not None and indexed is not None, f'{name} {kind}: no matching database/index observation'):
            continue
        meta, snapshot_raw, rgb, depth = rec
        check(meta == indexed and meta.get('taskId') == tid and meta.get('robotId') == robot and meta.get('taskRevision') == rev and not meta.get('expired'), f'{name} {kind}: observation metadata mismatch/expired')
        start = sent.get((item['stepId'], command)); observed = meta.get('observedAtUnixMs')
        check(start is not None and isinstance(observed,(int,float)) and start <= observed <= time_ms(e['occurredAt']), f'{name} {kind}: capture is not after its own command and before confirmation')
        for label, raw, field in [('snapshot',snapshot_raw,'snapshotSha256'),('rgb',rgb,'rgbSha256'),('depth',depth,'depthSha256')]:
            valid = isinstance(raw, bytes) and bool(raw) and sha(raw) == meta.get(field)
            check(valid, f'{name} {kind}: missing/corrupt {label}')
            if valid and re.fullmatch(r'[0-9a-f]{64}', str(meta.get('id',''))):
                path = output/(meta['id']+'-'+label+('.json' if label == 'snapshot' else '.png'))
                path.write_bytes(raw); item[label+'Sha256'] = sha(raw); item[label+'File'] = path.name
        if not isinstance(snapshot_raw, bytes):
            continue
        try:
            snapshot = json.loads(snapshot_raw); state_at = snapshot['robotState']; actual = state_at['base_pose']; goal = targets[name]
            distance, angle = pose_error(actual, goal)
            item.update(positionErrorM=distance, yawErrorRad=angle)
            check(distance <= .08 and angle <= .15, f'{name} {kind}: observed pose outside existing acceptance limits')
            goal_arg = (p.get('arguments') or {}).get('goalPose')
            err, yaw = pose_error(goal_arg, goal)
            check(err < 1e-6 and yaw < 1e-6, f'{name} {kind}: argument goal differs from preflight semantic goal')
            route = state_at.get('map_route') or {}
            check(all(route.get(k) == active.get(k) for k in keys), f'{name} {kind}: map-route versions differ from preflight')
            err, yaw = pose_error(route.get('goalPose'), goal)
            check(err < 1e-6 and yaw < 1e-6, f'{name} {kind}: recorded route goal differs')
            nav_command = command if kind == 'navigation.navigate' else stations[-2]['commandId']
            check(route.get('commandId') == nav_command, f'{name} {kind}: map-route not bound to station navigation command')
        except (KeyError, ValueError, TypeError, IndexError, json.JSONDecodeError) as error:
            errors.append(f'{name} {kind}: cannot verify pose/route: {error}')
    result = {'schemaVersion':'patrol.offline-audit.v1','taskId':tid,'robotId':robot,'taskRevision':rev,
              'expectedStations':expected,'stations':stations,'passed':not errors,'errors':errors,
              'inputSHA256':{p.name:sha(p.read_bytes()) for p in (task_path,index_path,telemetry_path,report_path,db_path)},
              'limitations':['Uses recorded odometry/map-route and stored RGB-D identity; not an independent ground-truth or contact/collision measurement.',
                             'Collector is an independent closure check; event evidence is not proof of general hardware safety.']}
    (output/'report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('task','index','telemetry','closure','database','output'):
        p.add_argument('--'+name, type=Path, required=True)
    args = p.parse_args()
    r = audit(args.task,args.index,args.telemetry,args.closure,args.database,args.output)
    print(json.dumps({'passed':r['passed'],'taskId':r['taskId'],'stations':len(r['stations']),'errors':r['errors']},ensure_ascii=False))
    raise SystemExit(0 if r['passed'] else 2)


if __name__ == '__main__':
    main()
