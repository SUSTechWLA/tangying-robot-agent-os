# survey001 运动发布拒绝分析及软件重测

`survey-001-original-guard-receipt.json` 是按 operationId/结果筛选的原始 bounded-step 记录。末步前置检查 base RGB-D capture age 985.671ms，前置检查到 ended 26.263ms，74 次非零脉冲，最终零速成功。publisher 内部当时没有记录 blocker 或采样时间，中间可能有新帧；仅凭相邻时刻接近 1s 判定 RGB-D 过期是合理假设，**不能视为已证实**。

新代码保留 publisher 真实 blocker、检查时间和授权结果，只在 RGBD_NOT_READY 触发已发零速后受限等待，之后重新读取并复验机器人状态、点云和守卫。最长 8 秒预算跨 ready 抖动持续计算，包含在动作发布截止内；非视觉、来源时钟、取消和急停不被放宽。这里是离线 fixture 测试，不是重测后的真实物理成功。

`manifest.json`记录工作区源码与测试SHA、命令、日志sha和起止信息；HEAD不是未提交工作区源码身份。日志未包含环境配置和密钥，保留本机路径和仿真元数据，不保证匿名。
