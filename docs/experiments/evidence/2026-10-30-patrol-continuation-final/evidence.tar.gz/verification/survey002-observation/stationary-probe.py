"""Read-only, four-second ROS subscriber. Does not publish or control the robot."""
import json
import math
import time
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from sensor_msgs.msg import JointState
from std_msgs.msg import String
from rclpy.qos import qos_profile_sensor_data
rclpy.init(); node = Node('survey002_stationary_independent')
data = {'odom': [], 'joints': 0, 'suction': []}
def odom(m):
    v, p = m.twist.twist, m.pose.pose
    data['odom'].append({'receiptMonotonicNs': str(time.monotonic_ns()),
        'stampNs': str(m.header.stamp.sec*1000000000+m.header.stamp.nanosec),
        'pose': [p.position.x,p.position.y,p.position.z,p.orientation.w,p.orientation.x,p.orientation.y,p.orientation.z],
        'linear': [v.linear.x,v.linear.y,v.linear.z], 'angular': [v.angular.x,v.angular.y,v.angular.z]})
def joint(m): data['joints'] += 1
def suction(m): data['suction'].append(json.loads(m.data))
node.create_subscription(Odometry,'/odom',odom,qos_profile_sensor_data)
node.create_subscription(JointState,'/joint_states',joint,qos_profile_sensor_data)
node.create_subscription(String,'/tangying/suction/state',suction,qos_profile_sensor_data)
start = time.monotonic()
while time.monotonic()-start < 4: rclpy.spin_once(node,timeout_sec=.05)
out = {'scope':'post-terminal read-only sampling, not a continuous collision monitor',
       'durationSeconds':time.monotonic()-start,'odom':data['odom'],'jointCount':data['joints'],
       'suctionCount':len(data['suction']),
       'maxLinearSpeedMps':max((math.sqrt(sum(v*v for v in row['linear'])) for row in data['odom']),default=None),
       'maxAngularSpeedRps':max((math.sqrt(sum(v*v for v in row['angular'])) for row in data['odom']),default=None),
       'suctionAttached':sorted(set(bool(x.get('attached')) for x in data['suction'])),
       'heldObjects':sorted(set(x.get('held','') for x in data['suction']))}
print(json.dumps(out)); node.destroy_node(); rclpy.shutdown()
