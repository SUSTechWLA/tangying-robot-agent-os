import json,math,random
from types import SimpleNamespace
from tangying_robot_gateway.gazebo_workflow import GazeboWorkflowBindings,commissioned_survey_approach
from tangying_robot_gateway.service_registry import ServiceError
import tangying_robot_gateway.gazebo_commissioning as c
c.commissioning=lambda:{'cameras':{}}
b=GazeboWorkflowBindings(runtime=SimpleNamespace(),navigation=None,robot_id='audit',root='/tmp',survey_goals=[])
goals=b._goals; segments=list(zip([p[:2] for p in goals],[p[:2] for p in goals][1:])); rng=random.Random(341)
def on_edge(point,a,b):
 dx,dy=b[0]-a[0],b[1]-a[1];sq=dx*dx+dy*dy
 if sq==0:return False
 t=((point[0]-a[0])*dx+(point[1]-a[1])*dy)/sq
 return -1e-8<=t<=1+1e-8 and math.dist(point,[a[0]+t*dx,a[1]+t*dy])<1e-7
ok=ambiguous=0
for _ in range(1000):
 a,b=rng.choice(segments); dx,dy=b[0]-a[0],b[1]-a[1];length=math.hypot(dx,dy)
 if not length:continue
 t=rng.random();offset=rng.uniform(-.59,.59);start=[a[0]+t*dx-offset*dy/length,a[1]+t*dy+offset*dx/length,.035,1.,0.,0.,0.]
 try: route=commissioned_survey_approach(start,goals)
 except ServiceError as e:
  assert e.code in ('SURVEY_START_AMBIGUOUS','SURVEY_START_UNREGISTERED'),e.code
  ambiguous+=1;continue
 points=[p[:2] for p in route]+[goals[0][:2]]
 # first segment is the live-guarded connector; all following edges lie on a registered segment.
 for left,right in zip(points,points[1:]):
  assert any(on_edge(left,a,b) and on_edge(right,a,b) for a,b in segments),(start,points,left,right)
 ok+=1
print(json.dumps({'seed':341,'sampled':1000,'accepted':ok,'safelyRejected':ambiguous,'scope':'synthetic geometry; no collision or motion evidence'}))
