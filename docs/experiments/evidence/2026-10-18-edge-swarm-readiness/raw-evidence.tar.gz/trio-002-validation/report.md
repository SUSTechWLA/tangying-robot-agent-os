# 三种机器人联合陌生环境探索软件验收（2026-10-18）

同一全局任务中，UGV、UAV、legged 各自使用独立位置、机体约束和未知局部地图。生产 `SpatialMissionRunner` 调用 `SpatialExplorer`，共用 `TaskCoordinator` 与 `CoverageLedger`。复用原 benchmark 的仓库场景、理想传感器和独立路径安全检查；原算法、旧实验配置和旧证据未改。

这是单进程、顺序调度的软件 fixture。没有运行 ROS DDS、真实硬件、飞行/步态动力学、真实 SLAM、并发四维避碰；自然语言文本只描述固定任务意图，未经过 LLM 解释。实际 DDS/NL 验收是另一个独立实验，不能拼接为已验证异构真实机器人陌生环境端到端协作。

## 预设任务与预算

- seeds=3、7、19；每个 seed 正常和故障条件，共 6 episode、3 个独立占据地图。
- 每个任务最多 18 round、54 dispatch、200 m commanded path、600000 ms 虚拟时间。
- ROI 包含所有内部自由和占据体素，不删难以观察区域；完成阈值固定为 100%。
- 初始每个 robot 的 occupancy 都是 unknown。地面支撑来自观测到的 fixture 地板，假设其平坦且承重。
- 故障预先定义：legged 地图转发 round 2..4 中断；round 3 起第一条符合安全准入的 legged 命令被拒绝；round 5 起第一条符合安全准入的 UAV 命令返回 unknown。
- 通信中断仅影响 occupancy map relay；进程内共享 ledger/coordinator 和停止端口保持可用。接收恢复按原观测时间转发，不刷新采集时间。

## 结果

| Seed | 条件 | 观测体素 / 全 ROI | 覆盖率 | 命令数 | 状态 |
| --- | --- | --- | --- | --- | --- |
| 3 | 正常 | 858 / 1144 | 75.00% | 32 | partial |
| 3 | 故障 | 803 / 1144 | 70.19% | 32 | partial |
| 7 | 正常 | 766 / 819 | 93.53% | 33 | partial |
| 7 | 故障 | 774 / 819 | 94.51% | 30 | partial |
| 19 | 正常 | 827 / 1080 | 76.57% | 26 | partial |
| 19 | 故障 | 766 / 1080 | 70.93% | 26 | partial |

全部 6 个任务为 partial，0 软件错误，不能声称完成全场景覆盖。正常均值 81.70%，故障均值 78.54%；seed 7 故障条件略高源于启发式规划轨迹变化，这不是故障有益的证据。样本只有 3 张地图，不给显著性或泛化结论。

| 机器人 | 成功命令 | 已知拒绝 | unknown |
| --- | --- | --- | --- |
| ugv | 18 | 15 | 0 |
| uav | 105 | 0 | 3 |
| legged | 36 | 2 | 0 |

179 条命令中，159 成功，17 已知拒绝，3 unknown。UGV 的 15 次拒绝来自独立几何安全准入，未声称发生真实碰撞；legged 的 2 次拒绝为明确注入。三类机器人在每个 episode 都有成功移动与传感器贡献。

计划 9 个故障，实际应用 8 个：3 次地图转发中断、2 次 controller 拒绝、3 次 unknown。seed 19 的 legged 在 round 3 后没有符合注入条件的执行，driver_rejection 被记录为 skipped，没有移动故障时机或修改 ROI。

3 次 unknown 均先记录命令、取得绑定相同 task/robot 的正停止回执、写入 coordinator stopped，再允许后续成功 dispatch。停止是 fixture 的程序回执，physicalStopMeasured=false。地图链路恢复后共回放 58 条排队消息，任务结束无待发地图消息。

## 可回溯证据

- 每个 episode 包含 input.json、events.jsonl、coverage-ledger.jsonl、coordination.jsonl、summary.json。
- 事件 journal 使用生产哈希链；重放逐条核对观测和 evaluator 真值、sensor capture 与 ledger 字段、unknown 与 stop 的顺序及持久 coordinator 状态。
- manifest 包含所有冻结源代码 SHA-256 和产物哈希；preregistration 保存固定 ROI、种子、故障规则和预算；source/ 保留执行源代码。
- 命令完整 stdout、exit code 与 UTC 起止时间保存在本目录 1.log、2.log、commands.json。
- 开发 smoke：trio-exploration-development-smoke-20261018-001，仅 seed3/2round，未计入上述 6 episode。
- 新入口测试 21 passed in 1.99s；包含 stop ACK 丢失后全局执行 fence、软件异常留存、不可覆盖历史输出、哈希篡改检测与预算拒绝。ruff 与 diff-check 通过。此测试结果来自工具输出，非本目录命令日志。

复现命令：

```sh
.venv/bin/python scripts/run_heterogeneous_exploration_fixture.py --config examples/experiments/heterogeneous_trio_fixture.json --output artifacts/experiments/<新的目录>
.venv/bin/python scripts/run_heterogeneous_exploration_fixture.py --verify artifacts/experiments/heterogeneous-trio-runner-20261018-002
```

当前可验证的是生产任务状态机在有界理想端口下正确保留 partial、跨机器人未知执行阻断、观测证据与故障回溯。离实机群体协作仍有真实 SLAM/坐标标定、设备动态约束、相互运动预测、独立分布式调度分区、真实传感器与通讯延迟、最终整合验收等未验证环节。

## 最终版本复跑说明

001 是本轮开发验收，原始目录完整保留，不覆盖。002 在加强完整摘要重算、严格文件集合与 CLI 错误退出后复跑同一套 6 个任务。覆盖率、执行结果、故障应用等全部业务指标一致；事件链因真实测量的规划耗时重新采样而改变。本次统计使用 002，独立任务数仍为 6、独立地图数为 3，不能把 001 和 002 合并声称 N=12。详见 rerun-comparison.json。
