from pathlib import Path
from datetime import datetime,UTC
import hashlib,json,csv,math
ROOT=Path('/Users/wanglian/Projects/tangying-robot-agent-os')
OUT=ROOT/'artifacts/experiments/edge-agent-ros-campaign-20261018-001'
CAMPAIGN=OUT/'container-evidence-attempt03/campaign'
rows=[]
for trial in json.loads((CAMPAIGN/'summary.json').read_text())['trials']:
 if trial['type']!='natural_language_route':continue
 p=CAMPAIGN/trial['output']
 summary=json.loads((p/'summary.json').read_text())
 task=json.loads((p/'final-task.json').read_text())
 records=json.loads((p/'observations.json').read_text())['records']
 telemetry=json.loads((p/'final-telemetry.json').read_text())['latest']['robotState']
 health=telemetry['harnessHealth']
 confirmed=[e['payload'] for e in task['events'] if e['type']=='TOOL_ACTIVITY' and e['payload'].get('activityStatus')=='CONFIRMED' and e['payload'].get('toolName')=='verify_arrival']
 captures={r['captureId'] for r in records}
 bound=all(e['receiptObservationId'] in captures for e in confirmed)
 provenance=all(r.get('sourceId') and r.get('sourceFrameId') and r.get('transformRevision') and r.get('captureSequence',0)>0 and len(r.get('snapshotSha256',''))==64 for r in records)
 assert bound and provenance and len(confirmed)==11
 assert health['schemaVersion']=='ros2.harness.health.v1' and health['robotId']==summary['robotId']
 assert health['driver']['fresh'] and health['driver']['healthy'] and health['driver']['watchdogActive']
 assert health['sensors'] and all(s['state']=='fresh' and s['observationId'] and s['sequence']>0 and s['sourceId'] for s in health['sensors'])
 assert health['uncertainCommandId']=='' and not health['locallyStopped']
 ledger=[json.loads(line) for line in (p/'controller.jsonl').read_text().splitlines()]
 plans=[e['plan'] for e in ledger if e['type']=='SPATIAL_PLAN']
 length=sum(sum(math.dist(a,b) for a,b in zip(plan['waypoints'],plan['waypoints'][1:])) for plan in plans)
 row={'round':trial['round'],'kind':trial['kind'],'taskId':summary['taskId'],'state':summary['state'],'success':summary['success'],'mode':summary['navigationMode'],'navigationCommands':summary['navigationCommands'],'independentArrivalChecks':summary['independentArrivalChecks'],'recordedWaypoints':summary['recordedWaypoints'],'pathLengthM':length,'heightMinM':summary['heightRangeM'][0],'heightMaxM':summary['heightRangeM'][1],'captureRecords':len(records),'arrivalReceiptsBoundToCapture':bound,'captureProvenanceComplete':provenance,'sensorSources':len(health['sensors']),'sensorState':'fresh','rgbBytes':sum(r['rgbBytes'] for r in records),'depthBytes':sum(r['depthBytes'] for r in records),'modelCalls':summary['modelCalls'],'elapsedTaskSeconds':summary['elapsedTaskSeconds'],'sourceStable':not summary['sourceChangedDuringExperiment'],'evidencePath':str(p.relative_to(ROOT))}
 rows.append(row)
with (OUT/'dds-task-metrics.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
result={'schemaVersion':'edge.acceptance.observation-audit.v1','analyzedAt':datetime.now(UTC).isoformat(),'evidenceClass':'actual_DDS_recorded_controller','source':'container-evidence-attempt03/campaign','tasks':rows,'taskCount':len(rows),'allArrivalReceiptsBoundToRetainedCapture':all(r['arrivalReceiptsBoundToCapture'] for r in rows),'allCaptureProvenanceComplete':all(r['captureProvenanceComplete'] for r in rows),'actualImageBytes':sum(r['rgbBytes']+r['depthBytes'] for r in rows),'physicalValidation':False,'sensorAccuracyValidation':False,'note':'Capture metadata and recorded sensor_fusion poses only; example calibration revision is placeholder; image payloads zero; no real SLAM, camera, flight, gait or drive validation.'}
(OUT/'observation-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='tasks'}))
