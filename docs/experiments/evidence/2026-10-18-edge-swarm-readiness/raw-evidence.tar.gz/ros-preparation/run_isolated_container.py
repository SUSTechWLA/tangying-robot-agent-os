from pathlib import Path
import hashlib,json,os,shlex,subprocess,sys,time
ROOT=Path('/Users/wanglian/Projects/tangying-robot-agent-os')
OUT=ROOT/'artifacts/experiments/edge-agent-ros-campaign-20261018-001'
PREP=OUT/'preparation'
CONTAINER='tangying-gazebo-4d6962a6c3d7-gazebo-house-1'
REMOTE='/tmp/tangying-edge-agent-20261018-001'
commands=[]

def run(argv,name,check=True):
    start=time.monotonic()
    with (PREP/name).open('w') as log:
        p=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,check=False)
    commands.append({'argv':argv,'log':name,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-start})
    (PREP/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(name,p.returncode,flush=True)
    if check and p.returncode:raise RuntimeError(f'{name} failed: {p.returncode}')
    return p.returncode

initial=json.loads(subprocess.check_output(['docker','inspect',CONTAINER]))[0]
assert initial['State']['Status']=='exited'
expected=json.loads((PREP/'container-isolation-plan.json').read_text())
assert initial['Id']==expected['containerId']
replaced=False
started=False
try:
    run(['docker','cp',str(PREP/'idle-entrypoint'),CONTAINER+':/usr/local/bin/tangying-navigation'],'entrypoint-isolate.log')
    replaced=True
    run(['docker','start',CONTAINER],'container-start.log')
    started=True
    run(['docker','exec',CONTAINER,'mkdir','-p',REMOTE+'/source',REMOTE+'/evidence'],'directory-create.log')
    run(['docker','cp',str(PREP/'frozen-source.tar.gz'),CONTAINER+':'+REMOTE+'/source.tar.gz'],'source-copy.log')
    run(['docker','cp',str(PREP/'local-agent-linux-arm64'),CONTAINER+':'+REMOTE+'/local-agent'],'binary-copy.log')
    run(['docker','exec',CONTAINER,'tar','-xzf',REMOTE+'/source.tar.gz','-C',REMOTE+'/source'],'source-unpack.log')
    run(['docker','exec',CONTAINER,'chmod','755',REMOTE+'/local-agent'],'binary-mode.log')
    envargs=['-e','ROS_DOMAIN_ID=117','-e','ROS_LOCALHOST_ONLY=1','-e','RMW_IMPLEMENTATION=rmw_cyclonedds_cpp','-e','TANGYING_INCIDENT_DIR='+REMOTE+'/evidence/incidents']
    build='source /opt/ros/jazzy/setup.bash && cd '+REMOTE+'/source && colcon --log-base '+REMOTE+'/evidence/colcon-logs build --base-paths robot/ros2_ws/src --packages-select tangying_robot_msgs tangying_ros_gateway --build-base '+REMOTE+'/ros-build --install-base '+REMOTE+'/ros-install --cmake-args -DCMAKE_BUILD_TYPE=Release -DPython3_EXECUTABLE=/usr/bin/python3'
    run(['docker','exec',*envargs,CONTAINER,'bash','-lc',build],'ros-colcon-build.log')
    setup='source /opt/ros/jazzy/setup.bash && source '+REMOTE+'/ros-install/setup.bash && export PYTHONPATH='+REMOTE+'/source/python:'+REMOTE+'/source/robot/gateway:'+REMOTE+'/source/scripts:/opt/navigation-venv/lib/python3.12/site-packages:$PYTHONPATH && cd '+REMOTE+'/source && '
    inspect=setup+"python3 -c 'import sys,platform,grpc,rclpy;from tangying_ros_gateway import profiled_node;from tangying_robot_gateway import ros2_profile;print(platform.platform());print(sys.version);print(grpc.__version__);print(profiled_node.__file__);print(ros2_profile.__file__)'"
    run(['docker','exec',*envargs,CONTAINER,'bash','-lc',inspect],'environment-imports.log')
    command=setup+'python3 scripts/run_ros2_edge_campaign.py --binary '+REMOTE+'/local-agent --output '+REMOTE+'/evidence/campaign --rounds 3'
    code=run(['docker','exec',*envargs,CONTAINER,'bash','-lc',command],'ros-campaign.log',False)
    verify=setup+'python3 scripts/run_ros2_edge_campaign.py --output '+REMOTE+'/evidence/campaign --verify'
    run(['docker','exec',*envargs,CONTAINER,'bash','-lc',verify],'ros-campaign-verify.log',False)
    sys.exit(code)
finally:
    if started:
        run(['docker','cp',CONTAINER+':'+REMOTE+'/evidence',str(OUT/'container-evidence')],'evidence-copy.log',False)
        run(['docker','stop','--time','10',CONTAINER],'container-stop.log',False)
    if replaced:
        run(['docker','cp',str(PREP/'original-entrypoint'),CONTAINER+':/usr/local/bin/tangying-navigation'],'entrypoint-restore.log',False)
        run(['docker','cp',CONTAINER+':/usr/local/bin/tangying-navigation',str(PREP/'restored-entrypoint')],'entrypoint-readback.log',False)
        restored=PREP/'restored-entrypoint'
        state=json.loads(subprocess.check_output(['docker','inspect',CONTAINER]))[0]
        check={'containerId':state['Id'],'state':state['State']['Status'],'restoredEntrypointSha256':hashlib.sha256(restored.read_bytes()).hexdigest() if restored.exists() else None,'expectedEntrypointSha256':expected['entrypointSha256']}
        check['passed']=check['containerId']==expected['containerId'] and check['state']=='exited' and check['restoredEntrypointSha256']==check['expectedEntrypointSha256']
        (PREP/'container-restoration.json').write_text(json.dumps(check,indent=2)+'\n')
        print(json.dumps(check),flush=True)
        if not check['passed']:raise RuntimeError('container restoration verification failed')
