from pathlib import Path
import json, hashlib, io, gzip, tarfile, shutil
ROOT=Path.cwd()
OUT=ROOT/'docs/experiments/evidence/2026-10-18-edge-swarm-readiness'
OUT.mkdir(parents=True,exist_ok=False)
E=ROOT/'artifacts/experiments'
ROS=E/'edge-agent-ros-campaign-20261018-001'
selected={}; omissions=[]
def digest(data): return hashlib.sha256(data).hexdigest()
def addtree(path,label,predicate=None):
    if not path.exists():return
    for file in sorted(path.rglob('*')):
        if not file.is_file() or '__pycache__' in file.parts:continue
        relative=file.relative_to(path)
        if predicate and not predicate(relative):continue
        name=label+'/'+relative.as_posix()
        if file.name=='console-session':
            omissions.append({'archivePath':name,'sha256':digest(file.read_bytes()),'reason':'private temporary console credential'})
            continue
        selected[name]=file
addtree(E/'edge-swarm-readiness-20261018-001/validation','validation')
addtree(E/'ros2-harness-hardening-20261018-001','ros-harness-unit')
for n in ('001','002'):
    addtree(E/f'heterogeneous-trio-runner-20261018-{n}',f'trio-{n}')
    addtree(E/f'heterogeneous-trio-runner-20261018-{n}-validation',f'trio-{n}-validation')
for n in ('001','002','003','004','005'):
    addtree(E/f'edge-cooperation-20261018-{n}',f'peer-{n}')
addtree(E/'edge-cooperation-source-20261018-001','peer-build-source')
addtree(E/'edge-cooperation-validation-20261018-001','peer-validation')
addtree(ROS/'container-evidence-attempt03/campaign','ros-final')
addtree(ROS/'container-evidence-attempt02/campaign','ros-development',lambda p:p.name!='source-snapshot.tar.gz')
for n in ('01','02','03','04'):
    addtree(ROS/f'software-campaign-round-{n}',f'software-{n}')
addtree(ROS/'preparation','ros-preparation',lambda p:not any(v.startswith('frozen-source') for v in p.parts) and p.name!='local-agent-linux-arm64')
for p in ROS.iterdir():
    if p.is_file():selected['ros-index/'+p.name]=p
selected['export_public.py']=Path(__file__).resolve()
secrets=[p.read_bytes().strip() for p in ROS.rglob('console-session')]
files=[]
with (OUT/'raw-evidence.tar.gz').open('wb') as target:
    with gzip.GzipFile(fileobj=target,mode='wb',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for name,file in sorted(selected.items()):
                data=file.read_bytes()
                if any(secret and secret in data for secret in secrets):raise ValueError('credential found in '+name)
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
                archive.addfile(info,io.BytesIO(data))
                files.append({'path':name,'bytes':len(data),'sha256':digest(data)})
with tarfile.open(OUT/'raw-evidence.tar.gz','r:gz') as archive:
    members=archive.getmembers()
    assert [v.name for v in members]==[v['path'] for v in files]
    for item,record in zip(members,files,strict=True):
        assert digest(archive.extractfile(item).read())==record['sha256']
(OUT/'archive-members.json').write_text(json.dumps({'algorithm':'sha256','files':files},indent=2)+'\n')
(OUT/'redactions.json').write_text(json.dumps({'omissions':omissions,'otherCredentialMatches':0,'rosDevelopmentSourceArchiveOmitted':'same compiled source bytes as ros-final/source-snapshot.tar.gz; original archive and complete manifests retained locally','binaryOmitted':'80.6MB Linux binary retained locally; hash and actual full build source archived','originalManifestPolicy':'original hashes are untouched; private console-session files absent so use the public member manifest, not original ROS directory verify, on this export'},indent=2)+'\n')
readable={
 'ros-summary.json':ROS/'container-evidence-attempt03/campaign/summary.json',
 'ros-task-metrics.csv':ROS/'dds-task-metrics.csv',
 'ros-observation-audit.json':ROS/'observation-audit.json',
 'attempts.json':ROS/'attempts.json',
 'software-summary.json':ROS/'software-campaign-round-04/summary.json',
 'trio-summary.json':E/'heterogeneous-trio-runner-20261018-002/summary.json',
 'trio-rerun-comparison.json':E/'heterogeneous-trio-runner-20261018-002-validation/rerun-comparison.json',
 'container-restoration.json':ROS/'preparation/container-attempt03/container-restoration.json',
}
for name,path in readable.items():shutil.copyfile(path,OUT/name)
(OUT/'export-receipt.json').write_text(json.dumps({'archiveFiles':len(files),'uncompressedBytes':sum(v['bytes'] for v in files),'archiveBytes':(OUT/'raw-evidence.tar.gz').stat().st_size,'archiveReadbackVerified':True,'sessionFilesOmitted':len(omissions),'physicalValidation':False},indent=2)+'\n')
print(json.dumps({'files':len(files),'archiveBytes':(OUT/'raw-evidence.tar.gz').stat().st_size,'omittedCredentials':len(omissions)}))
