from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import re
import tarfile
from cryptography.hazmat.primitives.serialization import load_pem_private_key

ROOT = Path(__file__).resolve().parents[4]
PUBLIC = ROOT / 'docs/experiments/evidence/2026-10-18-edge-swarm-readiness'
OUTPUT = Path(__file__).resolve().parent
patterns = {
    'private_key_pem': re.compile(rb'-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----'),
    'github_token_shape': re.compile(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b'),
    'aws_access_key_shape': re.compile(rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'),
    'openai_key_shape': re.compile(rb'\bsk-(?:proj-)?[A-Za-z0-9_-]{30,}\b'),
    'google_api_key_shape': re.compile(rb'\bAIza[A-Za-z0-9_-]{35}\b'),
    'slack_token_shape': re.compile(rb'\bxox[baprs]-[A-Za-z0-9-]{20,}\b'),
}
findings = []
counts = {'outerFiles': 0, 'nestedArchiveFiles': 0, 'nestedArchives': 0}

def inspect(name, data, nested=False):
    counts['nestedArchiveFiles' if nested else 'outerFiles'] += 1
    base = PurePosixPath(name).name
    if (base == '.env' or (base.startswith('.env.') and not base.endswith(('.example', '.sample', '.template')))
        or base in {'console-session', 'id_rsa', 'id_ed25519', 'credentials', 'credentials.json'}
        or PurePosixPath(base).suffix.lower() in {'.pem', '.key', '.p12', '.pfx', '.jks'}):
        findings.append({'path': name, 'kind': 'sensitive_filename', 'count': 1})
    for kind, pattern in patterns.items():
        count = len(pattern.findall(data))
        if count:
            finding = {'path': name, 'kind': kind, 'count': count, 'classification': 'unreviewed'}
            if kind == 'private_key_pem' and name.split('::')[-1] in {
                'internal/pairing/protocol_test.go', 'robot/gateway/tests/test_pairing.py',
                'tests/contract/robot_pairing.json',
            }:
                blocks = re.findall(rb'-----BEGIN (?:\w+ )?PRIVATE KEY-----[\s\S]+?-----END (?:\w+ )?PRIVATE KEY-----', data)
                parseable = 0
                for block in blocks:
                    try:
                        load_pem_private_key(block.replace(b'\\n', b'\n'), password=None)
                        parseable += 1
                    except ValueError:
                        pass
                current = ROOT / name.split('::')[-1]
                if len(blocks) == count and parseable == 0 and current.read_bytes() == data:
                    finding['classification'] = 'nonparseable_placeholder_in_pairing_contract_test_fixture'
            if kind == 'openai_key_shape' and name.endswith('/test-events.jsonl'):
                per_test_output = {}
                reviewed = 0
                for line in data.splitlines():
                    row = json.loads(line)
                    key = (row.get('Package'), row.get('Test'))
                    prior = per_test_output.get(key, '')
                    output = row.get('Output', '')
                    matches = patterns[kind].finditer(output.encode())
                    for match in matches:
                        # go test output chunking split the leading 'ta' of task-*.
                        if match.start() == 0 and prior.endswith('ta'):
                            reviewed += 1
                    per_test_output[key] = prior + output
                if reviewed == count:
                    finding['classification'] = 'task_identifier_split_across_go_test_output_chunks'
            findings.append(finding)
    if name.endswith(('.tar.gz', '.tgz', '.tar')):
        counts['nestedArchives'] += 1
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:*') as archive:
            for member in archive.getmembers():
                if member.isfile():
                    inspect(name + '::' + member.name, archive.extractfile(member).read(), True)

with tarfile.open(PUBLIC / 'raw-evidence.tar.gz', mode='r:gz') as archive:
    for member in archive.getmembers():
        if member.isfile():
            inspect(member.name, archive.extractfile(member).read())
report = {
    'schemaVersion': 'evidence.credential-audit.v1',
    'archiveSha256': hashlib.sha256((PUBLIC / 'raw-evidence.tar.gz').read_bytes()).hexdigest(),
    'scope': 'all outer regular members and recursively all source tar members, in memory only',
    'checks': sorted(patterns) + ['sensitive_filename'],
    'counts': counts,
    'findings': findings,
    'unreviewedFindings': sum(1 for finding in findings if finding.get('classification', 'unreviewed') == 'unreviewed'),
    'note': 'Targeted filename and well-known key-shape scan; not a proof that every arbitrary secret encoding is absent. No candidate values are emitted.'
}
(OUTPUT / 'credential-audit.json').write_text(json.dumps(report, indent=2) + '\n')
(PUBLIC / 'credential-audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'counts': counts, 'findings': findings}))
