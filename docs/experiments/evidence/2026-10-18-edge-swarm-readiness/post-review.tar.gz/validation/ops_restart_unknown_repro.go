package main

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/SUSTechWLA/tangying-robot-agent-os/agentruntime"
	"github.com/SUSTechWLA/tangying-robot-agent-os/core/agentcontract"
	"github.com/SUSTechWLA/tangying-robot-agent-os/core/telemetry"
)

func main() {
	now := time.Unix(1000, 0).UTC()
	h := map[string]any{"schemaVersion": "ros2.harness.health.v1", "robotId": "r", "observedAtUnixMs": now.UnixMilli(), "uncertainCommandId": "lost-command",
		"lastExecution": map[string]any{"state": "unknown", "commandId": "lost-command"},
		"driver": map[string]any{"fresh": true, "healthy": true, "watchdogActive": true, "error": "", "faults": []any{}}, "sensors": []any{}}
	a := agentruntime.NewOpsAgent()
	a.Now = func() time.Time { return now }
	a.Telemetry = func(context.Context, string) (telemetry.Snapshot, error) {
		return telemetry.Snapshot{RobotID: "r", ObservedAt: now, RobotState: map[string]any{"harnessHealth": h}}, nil
	}
	clears := []agentcontract.Event{}
	a.Publish = func(_ context.Context, e agentcontract.Event) {
		if e.Topic == agentcontract.TopicOpsAnomalyCleared {
			clears = append(clears, e)
		}
	}
	before := a.Observe(context.Background())
	// These are the bridge's actual process-initial fields, with fresh state
	// arriving after restart but no execution reconciliation for lost-command.
	h["uncertainCommandId"] = ""
	h["lastExecution"] = map[string]any{"state": "idle", "commandId": ""}
	after := a.Observe(context.Background())
	raw, _ := json.Marshal(map[string]any{"findingsBefore": before, "findingsAfterRestart": after, "clearedWithoutCommandReconciliation": clears})
	fmt.Println(string(raw))
}
