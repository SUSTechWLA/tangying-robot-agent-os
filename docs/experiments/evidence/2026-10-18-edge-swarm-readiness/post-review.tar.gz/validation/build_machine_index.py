from pathlib import Path
from datetime import datetime, timezone
import collections
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parents[4]
PUBLIC = ROOT / 'docs/experiments/evidence/2026-10-18-edge-swarm-readiness'
OUTPUT = ROOT / 'docs/experiments/2026-10-18-edge-swarm-readiness.json'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(name):
    return json.loads((PUBLIC / name).read_text())

ros = load('ros-summary.json')
software = load('software-summary.json')
trio = load('trio-summary.json')
observations = load('ros-observation-audit.json')
with tarfile.open(PUBLIC / 'raw-evidence.tar.gz') as archive:
    peers = [json.load(archive.extractfile(f'peer-{i:03d}/summary.json')) for i in (2, 3, 4)]
    ros_source = json.load(archive.extractfile('ros-preparation/completed-build-provenance.json'))
    trio_manifest = json.load(archive.extractfile('trio-002/manifest.json'))
    peer_source = json.load(archive.extractfile('peer-build-source/frozen-build-source.json'))
    dds_public_archive = archive.extractfile('ros-final/source-snapshot.tar.gz').read()
    dds_public_archive_sha = hashlib.sha256(dds_public_archive).hexdigest()
    with tarfile.open(fileobj=io.BytesIO(dds_public_archive)) as source:
        actual = {member.name for member in source.getmembers() if member.isfile()}
        if actual != set(ros_source['files']):
            raise ValueError('DDS public source set differs from build provenance')
        if any(hashlib.sha256(source.extractfile(name).read()).hexdigest() != recorded
               for name, recorded in ros_source['files'].items()):
            raise ValueError('DDS public source bytes differ from build provenance')
    copy_bindings = {
        'ros-summary.json': 'ros-final/summary.json',
        'software-summary.json': 'software-04/summary.json',
        'trio-summary.json': 'trio-002/summary.json',
    }
    for public, frozen in copy_bindings.items():
        if (PUBLIC / public).read_bytes() != archive.extractfile(frozen).read():
            raise ValueError(f'public summary differs: {public}')

command_totals = collections.Counter()
per_robot = {kind: collections.Counter() for kind in ('ugv', 'uav', 'legged')}
for episode in trio['episodes']:
    for robot, counts in episode['perRobotCommands'].items():
        per_robot[robot].update(counts)
        command_totals.update(counts)
changed_frozen_paths = []
for name, recorded in ros_source['files'].items():
    path = ROOT / name
    if path.exists() and path.is_file():
        current = sha(path)
        if current != recorded:
            changed_frozen_paths.append({'path': name, 'frozenSha256': recorded, 'currentSha256': current})
    else:
        changed_frozen_paths.append({'path': name, 'frozenSha256': recorded, 'currentSha256': None})

result = {
    'schemaVersion': 'edge.swarm-readiness.index.v1',
    'generatedAt': datetime.now(timezone.utc).isoformat(),
    'experimentDate': '2026-10-18',
    'timezone': 'Asia/Shanghai',
    'assessment': 'field_integration_candidate_with_unverified_vendor_and_physical_layers',
    'requestedRobotFamilies': ['DJI_UAV_via_model_specific_ROS2_bridge', 'Unitree_legged_via_ROS2_bridge', 'generic_AGV_ROS2'],
    'hardwareValidation': False,
    'physicsValidation': False,
    'allSceneCoverageAchieved': False,
    'arbitraryNaturalLanguageDistributedTaskGraphValidated': False,
    'evidenceLevels': {
        'actualLocalAgentGrpcAndROS2DDS': {
            'archiveRoot': 'ros-final/',
            'evidenceClass': ros['evidenceClass'],
            'finalAttempt': '03',
            'completedRoutes': ros['completedRoutes'],
            'plannedRoutes': ros['plannedRoutes'],
            'rounds': ros['rounds'],
            'robotKinds': ['ugv', 'uav', 'legged'],
            'recordedNavigationCommands': ros['recordedNavigationCommands'],
            'independentArrivalChecks': ros['independentArrivalChecks'],
            'faultCasesPassed': ros['passedFaultCases'],
            'faultCasesPlanned': ros['plannedFaultCases'],
            'captureMetadataRecords': sum(task['captureRecords'] for task in observations['tasks']),
            'actualImageBytes': observations['actualImageBytes'],
            'modelCalls': sum(task['modelCalls'] for task in observations['tasks']),
            'hardwareValidation': False,
            'sensorAccuracyValidation': False,
            'calibrationIsPlaceholder': True,
            'sourceStable': ros['sourceStable'],
            'sampling': ros['sampling'],
            'limits': ['recording controller, not dynamics or flight/gait control', 'deterministic natural-language route parser', 'no real SLAM or image sensor payload', 'development attempt02 excluded from final denominator'],
        },
        'softwareLongHorizonRecovery': {
            'archiveRoot': 'software-04/',
            'passed': software['passed'],
            'taskRecords': software['taskRecords'],
            'allRecords': software['allRecords'],
            'scenarioCounts': software['scenarioCounts'],
            'physicalTasks': 0,
            'limits': ['scenario assertions include safe rejection and unknown outcomes; not 23 physical task completions', 'interrupted rounds01-03 are retained but excluded'],
        },
        'fourProcessPeerAndCloudExchange': {
            'archiveRoots': [f'peer-{i:03d}/' for i in (2,3,4)],
            'repeatedEngineeringRuns': len(peers),
            'passedRuns': sum(peer['passed'] for peer in peers),
            'processesPerRun': 4,
            'transport': 'explicit-loopback-http-development',
            'elapsedSeconds': [peer['elapsedSeconds'] for peer in peers],
            'advisoryOnly': True,
            'grantsExecution': False,
            'wirelessValidation': False,
            'limits': ['same scenario repeated, not independent environments', 'peer advice cannot mark local target observation complete', 'no distributed collision avoidance or leader consensus'],
        },
        'threeMorphologyUnknownMapProductionRunnerFixture': {
            'archiveRoot': 'trio-002/',
            'episodes': len(trio['episodes']),
            'uniqueGeometryN': trio['uniqueGeometryN'],
            'completed': trio['completed'],
            'partial': trio['partial'],
            'softwareErrors': trio['softwareErrors'],
            'commandCounts': dict(command_totals),
            'commands': sum(command_totals.values()),
            'perRobotCommandCounts': {kind: dict(counts) for kind,counts in per_robot.items()},
            'coverage': [{k: episode[k] for k in ('seed','faulted','status','stopReason','coverageObserved','coverageDenominator','coverageFraction')} for episode in trio['episodes']],
            'plannedFaults': 9,
            'appliedFaults': sum(len(episode['faultApplications']) for episode in trio['episodes']),
            'skippedFaults': sum(len(episode['faultSkips']) for episode in trio['episodes']),
            'unknownStopAcknowledgements': sum(len(episode['stopAcknowledgements']) for episode in trio['episodes']),
            'replayedMapMessages': sum(episode['replayedMapMessages'] for episode in trio['episodes']),
            'pendingMapMessages': sum(episode['pendingMapMessages'] for episode in trio['episodes']),
            'naturalLanguageInterpreted': False,
            'rosDDSTested': False,
            'physicalExecution': False,
            'limits': ['18-round budget produced partial outcomes for all six episodes', 'single-process shared coordinator and ledger', 'map relay partition only, not total autonomy-layer partition', 'run001 and run002 reuse the same inputs; only run002 counted'],
        },
    },
    'frozenSources': {
        'dds': {k:ros_source[k] for k in ('baseCommit','frozenAt','sourceArchiveSha256','binarySha256','binaryBytes','buildCommand','buildEnv')},
        'ddsSourceFiles': len(ros_source['files']),
        'ddsSourceArchive': 'ros-final/source-snapshot.tar.gz',
        'ddsOriginalBuildSourceArchiveSha256': ros_source['sourceArchiveSha256'],
        'ddsPublicRearchiveSha256': dds_public_archive_sha,
        'ddsPublicSourceFilesEqualBuildManifest': True,
        'ddsSourceArchiveRelationship': 'The campaign re-archived all 1105 frozen build files. Every path and file SHA matches the build provenance; gzip/archive bytes differ from the earlier build preparation archive. dds.sourceArchiveSha256 identifies the original build archive, not the public campaign archive.',
        'peerBinarySha256': peers[0]['binarySha256'],
        'peerBuildSourceSha256': peer_source['archiveSha256'],
        'peerBuildSourceFiles': len(peer_source['files']),
        'trioRecordedSources': trio_manifest['sources'],
    },
    'workingTreeDelta': {
        'observedAt': datetime.now(timezone.utc).isoformat(),
        'changedPathsWithinDDSFrozenSourceSet': changed_frozen_paths,
        'comparisonScope': 'only the 1105 named DDS frozen source files; new files outside that set are not covered by this diff',
        'postDDSChangesNotValidatedByOldBinary': ['final Ops missing-driver health classification repair', 'DJI/Unitree/AGV commissioning and interface-binding additions', 'documentation and public evidence index/verification additions'],
        'interpretation': 'The old DDS results bind exclusively to their frozen source and binary hashes. Current working-tree changes require separate regression or commissioning evidence and cannot be attributed retroactively to that binary.',
    },
    'failuresAndAmendments': {
        'rosAndSoftwareAttempts': load('attempts.json'),
        'peerAttempts': [
            {'id':'001','outcome':'failed','reason':'short TTL and negative-age injection sequence interfered; experiment sequencing/window fixed without relaxing admission'},
            {'id':'005','outcome':'preflight_failed_no_campaign_started','reason':'vendored go list module directory metadata absent; archive helper corrected and validated separately'},
        ],
        'validationFailures': [
            {'path':'validation/ops-before-fix.log','outcome':'expected_defect_reproduction'},
            {'path':'validation/ops-after-fix-01.log','outcome':'test_fixture_clock_and_assertion_failures_then_repaired'},
            {'path':'validation/ops-go-race-01.log','outcome':'10_minute_timeout_in_long_campaign_not_a_pass','laterEvidence':'targeted race checks passed; completed long software campaign ran without race instrumentation'},
        ],
    },
    'publicEvidence': {
        'directory': str(PUBLIC.relative_to(ROOT)),
        'archiveSha256': sha(PUBLIC/'raw-evidence.tar.gz'),
        'archiveBytes': (PUBLIC/'raw-evidence.tar.gz').stat().st_size,
        'archiveMembers': len(load('archive-members.json')['files']),
        'masterManifestSha256': sha(PUBLIC/'master-manifest.json'),
        'publicFileCountExcludingMasterManifest': len(load('master-manifest.json')['files']),
        'summaryCopiesEqualArchive': copy_bindings,
        'verification': json.loads((Path(__file__).parent/'public-verify.log').read_text()),
        'trioRecalculation': json.loads((Path(__file__).parent/'trio-public-replay.log').read_text()),
        'credentialAudit': {'file':'credential-audit.json','unreviewedFindings':load('credential-audit.json')['unreviewedFindings'],'sessionFilesOmitted':len(load('redactions.json')['omissions'])},
        'originalROSManifestVerificationOnPublicSubset': False,
        'reason': '18 private console-session files were intentionally omitted; original manifest bytes remain intact, so use the public manifest for the redacted export.',
    },
}
OUTPUT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'path':str(OUTPUT.relative_to(ROOT)), 'sha256':sha(OUTPUT), 'ddsFrozenPathsChangedNow':[r['path'] for r in changed_frozen_paths], 'commands':dict(command_totals), 'episodes':len(trio['episodes'])}))
