"""Plot retained sampled motion; not a continuous collision certificate."""
import argparse
import csv
import itertools
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--metrics', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
metrics = json.loads((args.metrics / 'metrics.json').read_text())
with (args.metrics / 'trajectory.csv').open() as stream:
    rows = list(csv.DictReader(stream))
robots = sorted({r['robot_id'] for r in rows})
colors = {'ground-a': '#0d6b86', 'ground-b': '#cd7628', 'uav-a': '#774ca2'}
start = min(float(r['simulation_s']) for r in rows)
fig, axes = plt.subplots(1, 3, figsize=(14, 4.2), layout='constrained')
for robot in robots:
    group = [r for r in rows if r['robot_id'] == robot]
    values = np.array([[float(r[k]) for k in ('simulation_s', 'x_m', 'y_m', 'z_m')] for r in group])
    axes[0].plot(values[:, 1], values[:, 2], color=colors[robot], label=robot, lw=1.1, alpha=.85)
    axes[0].scatter(*values[0, 1:3], c=colors[robot], s=30, marker='o')
    axes[0].scatter(*values[-1, 1:3], c=colors[robot], s=50, marker='x')
    axes[1].plot(values[:, 0]-start, values[:, 3], color=colors[robot], label=robot, lw=1)
frames = {}
for row in rows:
    frames.setdefault(row['source_sequence'], {})[row['robot_id']] = row
radii = {r: max(metrics['maximumAdvertisedRadiiM'][r], metrics['worldConservativeRadiiM'][r]) for r in robots}
curve = []
for frame in frames.values():
    if set(frame) != set(robots):
        continue
    positions = {r: np.array([float(frame[r][k]) for k in ('x_m', 'y_m', 'z_m')]) for r in robots}
    gap = min(np.linalg.norm(positions[a]-positions[b])-radii[a]-radii[b] for a, b in itertools.combinations(robots, 2))
    curve.append((float(next(iter(frame.values()))['simulation_s'])-start, gap))
curve = np.array(curve)
axes[2].plot(curve[:, 0], curve[:, 1], color='#225f40', lw=1)
axes[2].axhline(0, color='#9c322e', ls='--', lw=.8)
axes[2].set_title(f'Sampled inter-robot gap (min {curve[:, 1].min():.3f} m)')
axes[0].set(title='Measured XY paths; circle=start, x=end', xlabel='X (m)', ylabel='Y (m)', aspect='equal')
axes[0].legend(fontsize=8)
axes[1].set(title='Measured height', xlabel='Simulation time (s)', ylabel='Z (m)')
axes[2].set(xlabel='Simulation time (s)', ylabel='Conservative sphere gap (m)')
for ax in axes:
    ax.grid(alpha=.2)
fig.suptitle('Gazebo classical-control retest — measured data, ground-truth localization', fontsize=12)
fig.savefig(args.output, dpi=180)
