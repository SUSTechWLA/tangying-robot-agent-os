"""Turn a SLAM result into the artifacts a browser can actually load.

Scope of this module: given a point cloud and a trajectory, produce a map
directory and a manifest that ``map_manifest`` accepts and can verify. It does not
read RTAB-Map's database itself - that step is a thin adapter, deliberately kept
apart so the pipeline can be tested, and load-tested, without a robot or a
database anywhere in sight.

Why a bespoke binary format for the point cloud
-----------------------------------------------
COPC is the target (plan section D1: single file, built-in octree, HTTP Range),
but COPC means LAZ, and this environment has no LAS/LAZ tooling at all. Rather
than add a heavy dependency to the critical path, the MVP writes a header plus
raw float32 positions and uint8 colours per level: twenty-four bytes of header, no
compression, decodable in a worker with a ``DataView`` and no parser library.

The manifest is format-agnostic - it points at files and hashes them - so moving
to COPC later changes this writer and the browser's reader, and nothing else. The
file extension is what tells the client which reader to use, which is the format
adapter seam the plan calls for.

Colours are stored as uint8 rather than float32 on purpose: point colour is a
display concern and four bytes per point instead of twelve is 8 MB saved on a
million-point map.
"""

from __future__ import annotations

import hashlib
import json
import math
import struct
import time
import zlib
from pathlib import Path

import numpy as np

# Re-exported rather than defined here: the point cloud is vocabulary the mapping,
# SLAM and exploration layers share, so it lives in ``geometry`` and this module is
# one of its users.
from tangying_robot_gateway.geometry import PointCloud, voxel_downsample
from tangying_robot_gateway.map_manifest import (
    build_manifest,
    save_manifest,
    validate_manifest,
    verify_artifacts,
)
from tangying_robot_gateway.navigation_map import MAX_GRID_CELLS, nav2_artifacts, validate_grid

MAGIC = b"TYPC"
FORMAT_VERSION = 1
HEADER_BYTES = 20

#: Height below which a point is treated as floor rather than obstacle.
FLOOR_HEIGHT_M = 0.15
#: Bounds of the synthetic test house, matching the commissioned home scene.
SYNTHETIC_BOUNDS = {"min": [-3.0, -2.0, -0.2], "max": [3.0, 8.0, 2.6]}



def synthetic_home_cloud(point_count: int = 1_000_000, *, seed: int = 7) -> PointCloud:
    """A cloud shaped like a scanned house interior, for load testing.

    Walls, a floor, and furniture blobs, with noise and a fraction of duplicate
    points - because a real RGB-D scan has both, and a downsampler that only looks
    good on uniform random points is not evidence of anything. Deterministic for a
    given seed so a load test can be repeated exactly.
    """
    rng = np.random.default_rng(seed)
    low, high = SYNTHETIC_BOUNDS["min"], SYNTHETIC_BOUNDS["max"]

    shares = {"floor": 0.42, "walls": 0.34, "furniture": 0.18, "noise": 0.06}
    counts = {name: int(point_count * share) for name, share in shares.items()}
    counts["floor"] += point_count - sum(counts.values())

    floor = np.column_stack([
        rng.uniform(low[0], high[0], counts["floor"]),
        rng.uniform(low[1], high[1], counts["floor"]),
        np.full(counts["floor"], low[2]) + rng.normal(0, 0.01, counts["floor"]),
    ])

    # Walls: four sides plus two interior partitions, sampled thinner than the floor.
    wall_points = []
    per_wall = max(counts["walls"] // 6, 1)
    for axis, value in ((0, low[0]), (0, high[0]), (1, low[1]), (1, high[1])):
        other = rng.uniform(low[1 - axis], high[1 - axis], per_wall)
        height = rng.uniform(low[2], high[2], per_wall)
        column = np.full(per_wall, value)
        wall_points.append(np.column_stack([column, other, height]) if axis == 0
                           else np.column_stack([other, column, height]))
    for value in (low[1] + 3.0, low[1] + 6.0):
        other = rng.uniform(low[0], high[0], per_wall)
        height = rng.uniform(low[2], high[2], per_wall)
        wall_points.append(np.column_stack([other, np.full(per_wall, value), height]))
    walls = np.concatenate(wall_points)[: counts["walls"]]

    # Furniture: blocks the robot would have to walk around.
    furniture = []
    centres = rng.uniform([low[0] + 1, low[1] + 1, low[2]], [high[0] - 1, high[1] - 1, low[2] + 0.3],
                          (max(counts["furniture"] // 400, 1), 3))
    per_block = max(counts["furniture"] // max(len(centres), 1), 1)
    for centre in centres:
        furniture.append(centre + rng.uniform([-0.4, -0.4, 0], [0.4, 0.4, 0.75], (per_block, 3)))
    furniture = np.concatenate(furniture)[: counts["furniture"]]

    noise = np.column_stack([
        rng.uniform(low[0], high[0], counts["noise"]),
        rng.uniform(low[1], high[1], counts["noise"]),
        rng.uniform(low[2], high[2], counts["noise"]),
    ])

    xyz = np.concatenate([floor, walls, furniture, noise]).astype(np.float32)
    # A tenth of the points are duplicates, as a real scan produces when the robot
    # lingers. Downsampling has to cope with them.
    duplicates = xyz[rng.choice(xyz.shape[0], xyz.shape[0] // 10, replace=False)]
    xyz = np.concatenate([xyz, duplicates])

    # Height-graded colour: floor bluish, walls neutral, furniture warm.
    height = xyz[:, 2]
    rgb = np.empty((xyz.shape[0], 3), dtype=np.uint8)
    rgb[:, 0] = np.clip(120 + height * 40, 0, 255)
    rgb[:, 1] = np.clip(140 + height * 30, 0, 255)
    rgb[:, 2] = np.clip(220 - height * 50, 0, 255)
    return PointCloud(xyz=xyz, rgb=rgb)



def build_lod(cloud: PointCloud, *, levels: int = 5, base_voxel_m: float = 0.04) -> list[PointCloud]:
    """Coarsest first, so ``lod0`` is what a distant camera draws.

    Voxel size doubles per level, which is the cheapest octree approximation that
    still guarantees a bounded point count at every level.
    """
    if levels < 1:
        raise ValueError("levels must be at least 1")
    result: list[PointCloud] = []
    for level in range(levels):
        voxel = base_voxel_m * (2 ** (levels - 1 - level))
        result.append(voxel_downsample(cloud, voxel))
    return result


def encode_lod(cloud: PointCloud, *, level: int) -> bytes:
    """Header plus raw positions, plus colours when present."""
    header = struct.pack("<4sIIII", MAGIC, FORMAT_VERSION, cloud.count, level,
                         1 if cloud.rgb is not None else 0)
    positions = np.ascontiguousarray(cloud.xyz, dtype="<f4").tobytes()
    colours = b"" if cloud.rgb is None else np.ascontiguousarray(cloud.rgb, dtype=np.uint8).tobytes()
    return header + positions + colours


def decode_lod(payload: bytes) -> tuple[PointCloud, int]:
    """Inverse of :func:`encode_lod`, so the format is testable in-process."""
    if len(payload) < HEADER_BYTES:
        raise ValueError("truncated point cloud chunk")
    magic, version, count, level, has_colour = struct.unpack("<4sIIII", payload[:HEADER_BYTES])
    if magic != MAGIC:
        raise ValueError("not a TYPC chunk")
    if version != FORMAT_VERSION:
        raise ValueError(f"unsupported chunk version {version}")
    body = payload[HEADER_BYTES:]
    expected = count * 12 + (count * 3 if has_colour else 0)
    if len(body) != expected:
        raise ValueError(f"chunk declares {count} points but carries {len(body)} bytes")
    xyz = np.frombuffer(body[: count * 12], dtype="<f4").reshape(count, 3).astype(np.float32)
    rgb = None
    if has_colour:
        rgb = np.frombuffer(body[count * 12:], dtype=np.uint8).reshape(count, 3)
    return PointCloud(xyz=xyz, rgb=rgb), level


#: Distinct observations a cell needs before its points count as an obstacle.
#:
#: One viewpoint is not evidence of an obstacle. A single depth frame can put a
#: mixed pixel at a depth discontinuity - the classic flying pixel - tens of
#: centimetres away from any real surface, and one badly registered pose moves a
#: whole frame's points somewhere nothing exists. Both land in free space and both
#: come from exactly one frame, so requiring a second, independent viewpoint
#: removes them without touching surfaces that are really there: a wall, a table
#: or a chair leg is seen by many consecutive keyframes while the robot drives
#: past it. This is the same rule a real occupancy mapper applies by counting
#: hits over time, and it is deliberately conservative - an object glimpsed from
#: a single frame stays unmodelled rather than becoming an obstacle that blocks a
#: goal the robot can actually reach.
MIN_OBSTACLE_OBSERVATIONS = 2


def corroborated_obstacle_cells(flat: np.ndarray, sources: np.ndarray, *,
                                minimum: int = MIN_OBSTACLE_OBSERVATIONS) -> np.ndarray:
    """Which of these candidate obstacle points are backed by enough viewpoints.

    ``sources`` holds one observation id per candidate point. An id of ``-1``
    marks evidence this session did not produce - geometry inherited from a base
    map - and is exempt: a claim the earlier survey already made is not
    re-litigated here, or continuing a map would erase it.
    """
    if flat.shape != sources.shape:
        raise ValueError("one observation id is required per candidate point")
    exempt = sources < 0
    observed = ~exempt
    if not observed.any():
        return exempt.copy()
    span = int(sources[observed].max()) + 1
    # One integer key per distinct (cell, observation) pair; counting the cells
    # that survive that reduction counts distinct viewpoints, not points.
    pairs = np.unique(flat[observed].astype(np.int64) * span + sources[observed])
    cells, counts = np.unique(pairs // span, return_counts=True)
    enough = cells[counts >= minimum]
    return np.isin(flat, enough) | exempt


#: Longest ray a single return is allowed to clear, in cells.
#:
#: Beyond this the interpolation is both slow and unreliable - the bearing error of
#: a distant point spreads over many cells - and a depth camera stops being useful
#: well before it anyway.
MAX_RAY_CELLS = 120


def _ray_free_cells(rows, columns, sources, sensor_origins, width, height,
                    resolution, low) -> np.ndarray:
    """Cells a measured return proves were empty, by walking sensor to return.

    Vectorised in chunks: a merged cloud is hundreds of thousands of points and a
    Python loop over them turns a map build into a stall. The endpoint itself is
    deliberately not marked - it is where the surface is, and the caller decides
    whether that makes the cell floor or obstacle.
    """
    origins = {}
    for key, value in sensor_origins.items():
        point = np.asarray(value, dtype=float)
        if point.shape != (3,) or not np.isfinite(point).all():
            raise ValueError("sensor origin must be a finite 3-D world point")
        origins[int(key)] = (int(np.floor((point[1] - low[1]) / resolution)),
                             int(np.floor((point[0] - low[0]) / resolution)))
    free = np.zeros((height, width), dtype=bool)
    if sources.size == 0:
        return free
    highest = int(sources.max())
    if highest < 0:
        return free  # Inherited geometry has no origin in the current session.
    origin_rows = np.full(highest + 1, -(10 ** 9), dtype=np.int64)
    origin_columns = np.full(highest + 1, -(10 ** 9), dtype=np.int64)
    for key, (row, column) in origins.items():
        if 0 <= key <= highest:
            origin_rows[key], origin_columns[key] = row, column
    chunk = 10_000
    for start in range(0, rows.size, chunk):
        r = rows[start:start + chunk]
        c = columns[start:start + chunk]
        s = sources[start:start + chunk]
        keep = (s >= 0) & (s <= highest)
        if not keep.any():
            continue
        r, c, s = r[keep], c[keep], s[keep]
        r0, c0 = origin_rows[s], origin_columns[s]
        dr, dc = r - r0, c - c0
        steps = np.maximum(np.abs(dr), np.abs(dc))
        usable = (r0 > -(10 ** 8)) & (steps > 1) & (steps <= MAX_RAY_CELLS)
        if not usable.any():
            continue
        r0, c0, dr, dc, steps = (r0[usable], c0[usable], dr[usable], dc[usable],
                                 steps[usable])
        fractions = np.arange(1, int(steps.max()))[None, :]
        walk = fractions < steps[:, None]
        rr = np.rint(r0[:, None] + (dr[:, None] * fractions) / steps[:, None]).astype(np.int64)
        cc = np.rint(c0[:, None] + (dc[:, None] * fractions) / steps[:, None]).astype(np.int64)
        rr, cc = rr[walk], cc[walk]
        inside = (rr >= 0) & (rr < height) & (cc >= 0) & (cc < width)
        free[rr[inside], cc[inside]] = True
    return free


def occupancy_from_points(cloud: PointCloud, *, resolution: float = 0.05,
                          bounds: dict | None = None, floor_z: float = 0.0,
                          obstacle_min_height: float = 0.04,
                          obstacle_max_height: float = 2.0,
                          sources: np.ndarray | None = None,
                          sensor_origins: dict[int, tuple[float, float, float]] | None = None) -> dict:
    """A 2-D occupancy grid derived from the cloud.

    Nav2 publishes the authoritative grid; this is the fallback for a map that has
    only a point cloud, and it is honest about ignorance: a cell with no points at
    all stays unknown rather than being called free.

    ``sources`` optionally names the observation each point came from; see
    :func:`corroborated_obstacle_cells`. Without it every point is treated as
    corroborated, which is what a caller holding a single merged cloud means.

    ``sensor_origins`` optionally gives the world position each observation was
    taken from, keyed by its id in ``sources``. With it, the space between a sensor
    and each of its returns is marked free, because a return is evidence that
    nothing was in the way; without it, only the cells a point landed in are known.

    This is the difference between a map that stops where the points stop and one a
    person would recognise. Measured on a real survey of the furnished house: 44% of
    the cells still marked unknown were visible from poses the robot had already
    driven through, and 6511 of them - 16.8% of the whole grid - were only unknown
    because no point happened to land in them. Point splatting alone cannot close
    that gap, and no amount of exploring will either: the robot had already been
    there.
    """
    if not math.isfinite(resolution) or resolution <= 0:
        raise ValueError("resolution must be positive")
    if (not all(math.isfinite(v) for v in (floor_z, obstacle_min_height, obstacle_max_height))
            or not 0 < obstacle_min_height < obstacle_max_height):
        raise ValueError("invalid commissioned floor or obstacle height interval")
    extent = bounds or cloud.bounds()
    low, high = extent["min"], extent["max"]
    if not np.isfinite([low, high]).all() or np.any(np.asarray(high) < low):
        raise ValueError("invalid point cloud bounds")
    width = max(int(np.ceil((high[0] - low[0]) / resolution)), 1)
    height = max(int(np.ceil((high[1] - low[1]) / resolution)), 1)
    if bounds is None:
        # Include points on the maximum extent; floor(max/resolution) may be
        # the next cell when a wall lies on an exact grid boundary.
        width = max(width, int(np.floor((high[0] - low[0]) / resolution)) + 1)
        height = max(height, int(np.floor((high[1] - low[1]) / resolution)) + 1)
    if width * height > MAX_GRID_CELLS:
        raise ValueError("occupancy projection exceeds cell budget; increase resolution or crop")

    columns = np.floor((cloud.xyz[:, 0] - low[0]) / resolution).astype(np.int64)
    rows = np.floor((cloud.xyz[:, 1] - low[1]) / resolution).astype(np.int64)
    inside = (columns >= 0) & (columns < width) & (rows >= 0) & (rows < height)
    columns, rows = columns[inside], rows[inside]
    heights = cloud.xyz[inside, 2]
    if sources is not None:
        sources = np.asarray(sources, dtype=np.int64)
        if sources.shape != (len(cloud.xyz),):
            raise ValueError("sources must hold one observation id per cloud point")
        sources = sources[inside]

    cells = np.full((height, width), -1, dtype=np.int16)
    if columns.size:
        flat = rows * width + columns
        relative = heights - floor_z
        obstacle_here = (relative >= obstacle_min_height) & (relative <= obstacle_max_height)
        floor = flat[np.abs(relative) < obstacle_min_height]
        obstacle = flat[obstacle_here]
        if sources is not None and obstacle.size:
            obstacle = obstacle[corroborated_obstacle_cells(obstacle, sources[obstacle_here])]
        # Obstacles win: a cell holding both floor and wall is not somewhere to drive.
        cells.reshape(-1)[floor] = 0
        cells.reshape(-1)[obstacle] = 100
    if sensor_origins is not None:
        if sources is None:
            raise ValueError(
                "sensor_origins is keyed by observation id and needs sources to "
                "say which observation each point came from")
        cleared = _ray_free_cells(rows, columns, sources, sensor_origins,
                                  width, height, resolution, low)
        # Only cells nothing else has claimed: a ray passing over a measured
        # obstacle does not make it free, and floor evidence already said so.
        cells[cleared & (cells < 0)] = 0
    return {
        "width": width, "height": height, "resolution": float(resolution),
        "origin": [float(low[0]), float(low[1]), 0.0],
        "cells": cells,
    }


def reconcile_grid_with_cloud(grid: dict, cloud: PointCloud, *, floor_z: float = 0.0,
                              obstacle_min_height: float = 0.04,
                              obstacle_max_height: float = 2.0) -> dict:
    """Drop occupied cells the published cloud cannot show.

    A map is only inspectable if its occupancy grid and its point cloud tell the
    same story. They stopped agreeing on a real survey: every continuation leg
    re-downsamples the cloud it inherited, so points are averaged and re-binned
    each generation, while the merged grid keeps every obstacle cell it was ever
    told about - obstacles win over free space and over nothing at all. After
    four legs, 23% of the occupied cells had no obstacle-height point left in the
    published cloud, and both cells that vetoed the commissioned kitchen waypoint
    were among them: the cloud showed measured floor there, the router saw a
    wall. An operator looking at the map could not have found the obstacle the
    robot refused to approach.

    A demoted cell becomes free only when the cloud measured floor in it, which
    is positive evidence; a cell with no points at all goes back to unknown,
    because the honest answer to "what is here" is then "nothing has looked".
    """
    cells = np.asarray(grid["cells"])
    if cells.ndim != 2 or cells.size == 0:
        raise ValueError("occupancy cells must be a non-empty 2-D array")
    resolution = float(grid["resolution"])
    if not math.isfinite(resolution) or resolution <= 0:
        raise ValueError("resolution must be positive")
    origin = [float(value) for value in grid["origin"]]
    xyz = np.asarray(cloud.xyz)
    reconciled = cells.copy()
    if xyz.size and (cells == 100).any():
        columns = np.floor((xyz[:, 0] - origin[0]) / resolution).astype(np.int64)
        rows = np.floor((xyz[:, 1] - origin[1]) / resolution).astype(np.int64)
        inside = (columns >= 0) & (columns < cells.shape[1]) & (rows >= 0) & (rows < cells.shape[0])
        columns, rows, heights = columns[inside], rows[inside], xyz[inside, 2]
        relative = heights - floor_z
        support = np.zeros_like(cells, dtype=bool)
        floor = np.zeros_like(cells, dtype=bool)
        obstacle = (relative >= obstacle_min_height) & (relative <= obstacle_max_height)
        support[rows[obstacle], columns[obstacle]] = True
        measured_floor = np.abs(relative) < obstacle_min_height
        floor[rows[measured_floor], columns[measured_floor]] = True
        unsupported = (cells == 100) & ~support
        reconciled[unsupported & floor] = 0
        reconciled[unsupported & ~floor] = -1
    return {**grid, "cells": reconciled}


def encode_png_gray(cells: np.ndarray) -> bytes:
    """Greyscale PNG: unknown light, free near-white, occupied dark.

    The same reading as the console's canvas - unknown must not look like free
    space - so a thumbnail and the live view agree.
    """
    height, width = cells.shape
    mapped = np.where(cells < 0, 232, np.where(cells == 0, 252, np.clip(200 - cells, 0, 200)))
    scanlines = b"".join(b"\x00" + mapped[row].astype(np.uint8).tobytes() for row in range(height))
    # The eight-byte signature is part of the format, not decoration: without it
    # every decoder rejects the file.
    return (b"\x89PNG\r\n\x1a\n"
            + _png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 0, 0, 0, 0))
            + _png_chunk(b"IDAT", zlib.compress(scanlines, 6))
            + _png_chunk(b"IEND", b""))


def _png_chunk(kind: bytes, payload: bytes) -> bytes:
    return (struct.pack(">I", len(payload)) + kind + payload
            + struct.pack(">I", zlib.crc32(kind + payload)))


def trajectory_geojson(poses: list[tuple[float, float, float]], *,
                       times_unix_ms: list[int | None] | None = None) -> dict:
    """One coordinate per pose, with optional paired capture times.

    A null timestamp explicitly preserves an inherited pose whose capture time
    was not recorded. Missing historical evidence is never synthesized.
    """
    coordinates = [[float(x), float(y)] for x, y, _z in poses]
    feature: dict = {
        "type": "Feature",
        "properties": {"pointCount": len(coordinates)},
        "geometry": {"type": "LineString", "coordinates": coordinates},
    }
    if times_unix_ms is not None:
        if len(times_unix_ms) != len(coordinates):
            raise ValueError("trajectory timestamps must match its coordinate count")
        if any(value is not None and (isinstance(value, (bool, np.bool_))
                or not isinstance(value, (int, np.integer)) or value <= 0) for value in times_unix_ms):
            raise ValueError("trajectory timestamps must be positive integers or explicit null")
        feature["properties"]["timesUnixMs"] = [None if value is None else int(value) for value in times_unix_ms]
    return {"type": "FeatureCollection", "features": [feature]}


def _write(path: Path, payload: bytes, *, root: Path) -> dict:
    """Write one artifact and describe it relative to the map directory.

    The href has to be relative to the manifest's own directory: an absolute path
    would be machine-specific, and a path outside the directory is the traversal
    the manifest contract refuses.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload)
    return {"href": path.relative_to(root).as_posix(),
            "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()}


def build_map(
    output_dir: str | Path,
    *,
    map_id: str,
    robot_id: str,
    cloud: PointCloud,
    poses: list[tuple[float, float, float]] | None = None,
    times_unix_ms: list[int | None] | None = None,
    source: str = "rtabmap",
    mode: str = "mapping",
    lod_levels: int = 5,
    base_voxel_m: float = 0.04,
    resolution: float = 0.05,
    calibration_revision: str | None = None,
    created_at_unix_ms: int | None = None,
    occupancy_grid: dict | None = None,
    floor_z: float = 0.0,
    semantic_workspaces: list[dict] | None = None,
    semantic_objects: dict | None = None,
    slam_metadata: dict | None = None,
    slam_keyframes: dict | None = None,
) -> dict:
    """Write every artifact and a manifest that verifies against them.

    Returns the manifest. The caller gets a directory that ``verify_artifacts``
    accepts, which is what makes the map safe to hand to a browser.
    """
    directory = Path(output_dir)
    if (directory / "manifest.json").exists():
        raise FileExistsError("map revisions are immutable; build into a new map directory")
    if cloud.count == 0:
        raise ValueError("cannot build a map from an empty cloud")
    directory.mkdir(parents=True, exist_ok=True)

    levels = build_lod(cloud, levels=lod_levels, base_voxel_m=base_voxel_m)
    # The manifest carries one cloud artifact; the finest level is the canonical
    # entry point and the coarser ones are addressed by name from the client.
    lod_artifacts = {}
    for level, points in enumerate(levels):
        lod_artifacts[f"cloud_lod_{level}"] = _write(
            directory / "cloud" / f"lod{level}.bin", encode_lod(points, level=level), root=directory)
    finest = levels[-1]

    # Navigation uses original measurements, never display downsampling, which
    # can average a thin obstacle into the ground band.
    grid = (validate_grid(occupancy_grid) if occupancy_grid is not None
            else occupancy_from_points(cloud, resolution=resolution, floor_z=floor_z))
    # Any grid - derived here or handed in by a survey that certified its own
    # trail - has to be answerable from the cloud this map publishes.
    grid = reconcile_grid_with_cloud(grid, finest, floor_z=floor_z)
    png = _write(directory / "grid" / "occupancy.png", encode_png_gray(grid["cells"]), root=directory)
    np.save(directory / "grid" / "occupancy.npy", grid["cells"])
    _write(directory / "grid" / "occupancy.json", json.dumps({
        "width": grid["width"], "height": grid["height"],
        "resolution": grid["resolution"], "origin": grid["origin"],
    }, ensure_ascii=False, indent=2).encode(), root=directory)

    artifacts = {"cloud": _write(directory / "cloud" / f"lod{lod_levels - 1}.bin",
                                 encode_lod(finest, level=lod_levels - 1), root=directory),
                 "grid": png, **lod_artifacts}
    pgm, nav_yaml = nav2_artifacts(grid)
    artifacts["navigation"] = _write(directory / "navigation/map.yaml", nav_yaml, root=directory)
    artifacts["navigation_grid"] = _write(directory / "navigation/map.pgm", pgm, root=directory)
    artifacts["navigation_metadata"] = _write(directory / "navigation/source.json", json.dumps({
        "frameId": "map", "source": "slam_occupancy" if occupancy_grid is not None else "pointcloud_projection",
        "requiresCommissioning": True, "floorZ": floor_z,
        "calibrationRevision": calibration_revision,
    }, sort_keys=True).encode(), root=directory)
    if semantic_objects is not None:
        # Objects the robot actually saw, in this map's frame, with the age of
        # each sighting. Published next to the places layer because a task needs
        # both: "the cup" is a category, "the kitchen" is a place, and "where was
        # the cup when I last looked" is neither.
        document = dict(semantic_objects)
        if (document.get("schemaVersion") != "map.objects.v1" or document.get("mapId") != map_id
                or document.get("frameId") != "map"
                or document.get("calibrationRevision") != calibration_revision):
            raise ValueError("object layer does not belong to this map")
        artifacts["objects"] = _write(
            directory / "objects.json",
            json.dumps(document, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8"),
            root=directory)
    if semantic_workspaces is not None:
        artifacts["semantics"] = _write(directory / "semantics.json", json.dumps({
            "schemaVersion": "map.semantics.v1", "mapId": map_id, "frameId": "map",
            "calibrationRevision": calibration_revision, "workspaces": semantic_workspaces,
        }, ensure_ascii=False, allow_nan=False).encode(), root=directory)
    if slam_metadata is not None:
        artifacts["slam_session"] = _write(directory / "slam-session.json", json.dumps(
            slam_metadata, ensure_ascii=False, allow_nan=False).encode(), root=directory)
    if slam_keyframes is not None:
        from .slam_keyframes import MAX_ARTIFACT_BYTES
        if (slam_keyframes.get("mapId") != map_id or slam_keyframes.get("frameId") != "map"
                or slam_keyframes.get("robotId") != robot_id
                or slam_keyframes.get("calibrationRevision") != calibration_revision):
            raise ValueError("keyframe previews do not belong to this map")
        payload = json.dumps(slam_keyframes, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode()
        if len(payload) > MAX_ARTIFACT_BYTES:
            raise ValueError("keyframe artifact exceeds bounded preview budget")
        artifacts["slam_keyframes"] = _write(directory / "slam-keyframes.json", payload, root=directory)
    path = poses or []
    if path:
        trail = trajectory_geojson(path, times_unix_ms=times_unix_ms)
        artifacts["trajectory"] = _write(directory / "trajectory.geojson",
                                         json.dumps(trail, ensure_ascii=False).encode(), root=directory)

    manifest = build_manifest(
        map_id=map_id, robot_id=robot_id, source=source, mode=mode,
        artifacts=artifacts,
        bounds=finest.bounds(),
        point_count=finest.count,
        lod_levels=lod_levels,
        floors=[{"id": "ground", "zMin": finest.bounds()["min"][2] - 0.1,
                 "zMax": finest.bounds()["max"][2] + 0.1}],
        created_at_unix_ms=int(created_at_unix_ms if created_at_unix_ms is not None
                              else time.time() * 1000),
        calibration_revision=calibration_revision,
    )
    return save_manifest(directory, manifest)


def verify_map(directory: str | Path) -> list:
    """Load a built map and check every declared artifact against its hash."""
    from tangying_robot_gateway.map_manifest import load_manifest

    manifest: dict = load_manifest(directory)
    validate_manifest(manifest)
    return verify_artifacts(manifest, directory)
