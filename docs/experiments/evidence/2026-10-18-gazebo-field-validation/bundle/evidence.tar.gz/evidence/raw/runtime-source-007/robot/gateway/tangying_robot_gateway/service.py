from __future__ import annotations

import argparse
import copy
import hashlib
import json
import threading
import time
from concurrent import futures
from dataclasses import replace
from pathlib import Path

import grpc
from google.protobuf.json_format import MessageToDict, ParseDict
from tangying_robot_proto.robot.v1 import robot_pb2, robot_pb2_grpc

from .backend import BackendResult, RobotBackend, semantic_state
from .contracts import PHYSICAL_TOOLS, RobotProfile, validate_reconstruction
from .journal import RuntimeJournal
from .plugin_backend import ReconstructionTracker, project_entities
from .runtime import (
    Command,
    InvalidToolResult,
    Observation,
    ObservationRequest,
    Result,
    RuntimeInfo,
    SemanticState,
    validate_result,
)
from .safety import PHYSICAL_SKILLS, SafetySupervisor


def command_from_proto(value: robot_pb2.SkillCommand) -> Command:
    return Command(
        schema_version=value.schema_version,
        command_id=value.command_id,
        task_id=value.task_id,
        capability=value.skill,
        target_ref=value.target_ref,
        parameters=MessageToDict(value.parameters) if value.parameters else {},
        deadline_unix_ms=value.deadline_unix_ms,
        lease_ms=value.lease_ms,
        idempotency_key=value.idempotency_key,
        safety_profile=value.safety_profile,
        approval_id=value.approval_id,
        robot_id=value.robot_id,
        catalog_revision=value.catalog_revision,
        world_revision_basis=value.world_revision_basis,
        resource_id=value.resource_id,
        fencing_token=value.fencing_token,
    )


def runtime_info_to_proto(value: RuntimeInfo) -> robot_pb2.RuntimeInfo:
    result = robot_pb2.RuntimeInfo(
        robot_id=value.robot_id,
        adapter=value.adapter,
        skills=value.skills,
        manipulation_ready=value.manipulation_ready,
        blockers=value.blockers,
        software_version=value.software_version,
        protocol_version=value.protocol_version,
        runtime_version=value.runtime_version,
        adapter_version=value.adapter_version,
        catalog_revision=value.catalog_revision,
    )
    for source in value.capabilities:
        target = result.capabilities.add()
        target.name = source.name
        target.description = source.description
        target.available = source.available
        target.blockers.extend(source.blockers)
        target.cancellable = source.cancellable
        target.recoverable = source.recoverable
        target.default_timeout_ms = source.default_timeout_ms
        target.safety_level = source.safety_level
        target.input_parameters.extend(source.input_parameters)
        target.output_parameters.extend(source.output_parameters)
        target.mutates_world = source.mutates_world
    if value.robot_profile is not None:
        ParseDict(value.robot_profile, result.robot_profile)
    return result


def observation_from_proto(value: robot_pb2.ObserveRequest) -> ObservationRequest:
    return ObservationRequest(streams=tuple(value.streams), max_rate_hz=value.max_rate_hz, source_id=value.source_id)


def semantic_state_to_proto(value: SemanticState) -> robot_pb2.SemanticState:
    return robot_pb2.SemanticState(
        activity=value.activity,
        mode=value.mode,
        emergency_stopped=value.emergency_stopped,
        anomalies=value.anomalies,
        last_error=value.last_error,
    )


def observation_to_proto(value: Observation) -> robot_pb2.Observation:
    from .rgbd_images import validate_observation_images

    images = validate_observation_images(value)
    result = robot_pb2.Observation(
        observation_id=value.observation_id,
        wall_time_unix_ms=value.wall_time_unix_ms,
        monotonic_time_ns=value.monotonic_time_ns,
        semantic_state=semantic_state_to_proto(value.semantic_state),
        **images,
    )
    if value.robot_state:
        ParseDict(value.robot_state, result.robot_state)
    for source in value.entities:
        target = result.entities.add()
        target.entity_id = source.entity_id
        target.category = source.category
        target.attributes.update(source.attributes)
        target.pose_xyz_quat.extend(source.pose_xyz_quat)
        target.confidence = source.confidence
        target.relation = source.relation
    if value.reconstruction:
        ParseDict(value.reconstruction, result.reconstruction)
    return result


class RobotRuntimeService(robot_pb2_grpc.RobotRuntimeServicer):
    def __init__(self, backend: RobotBackend, journal: RuntimeJournal | None = None, *, services=(), max_lease_ms=60_000):
        self.backend = backend
        self.journal = journal or RuntimeJournal(None)
        if not isinstance(max_lease_ms, int) or isinstance(max_lease_ms, bool) or not 0 < max_lease_ms <= 600_000:
            raise ValueError("max_lease_ms must be an integer in 1..600000")
        self.safety = SafetySupervisor(backend=backend, journal=self.journal, max_lease_ms=max_lease_ms)
        self._results: dict[str, tuple[str, list[robot_pb2.SkillEvent]]] = {}
        self._results_lock = threading.Lock()
        self._execution_lock = threading.Lock()
        self._inflight: tuple[str, str] | None = None
        self._cancelled: set[str] = set()
        self._resource_grants: dict[str, tuple[str, int]] = dict(
            self.journal.resource_grants
        )
        info = self.backend.capabilities()
        from .service_registry import ServiceRegistry
        self.services = ServiceRegistry(info.robot_id)
        for service in services:
            self.services.register(service)
        self._profile = self._validate_profile(info)
        self._reconstruction_tracker = ReconstructionTracker()
        self._observation_lock = threading.Lock()
        from .grounded.runtime import GroundedRuntime
        contracts = getattr(backend, "grounded_contracts", None)
        self.grounded = GroundedRuntime.from_environment(contracts=contracts() if callable(contracts) else None)

    def ListServices(self, request, context):
        return self.services.catalogue()

    def CallService(self, request, context):
        return self.services.call(request)

    @staticmethod
    def _validate_profile(info: RuntimeInfo) -> RobotProfile | None:
        if info.robot_profile is None:
            return None
        profile = RobotProfile.model_validate(info.robot_profile)
        if (profile.robot_id != info.robot_id or profile.adapter_id != info.adapter
                or profile.adapter_version != info.adapter_version):
            raise ValueError("robot profile identity does not match runtime")
        names = [item.name for item in info.capabilities]
        if len(set(names)) != len(names) or set(names) != set(profile.tools):
            raise ValueError("runtime capabilities do not match the declared profile tools")
        for item in info.capabilities:
            expected_safety = "physical_motion" if item.name in PHYSICAL_TOOLS else "read_only"
            if item.safety_level != expected_safety:
                raise ValueError("runtime capability safety level conflicts with canonical tool")
        return profile

    def _validate_current_profile(self, info: RuntimeInfo) -> None:
        current = self._validate_profile(info)
        if current != self._profile:
            raise ValueError("robot profile changed; restart and enroll the new adapter configuration")

    def register_resource(self, resource_id: str, *, owner: str, token: int) -> None:
        if not resource_id or not owner or token <= 0:
            raise ValueError("resource id, owner and positive fencing token are required")
        with self._results_lock:
            current = self._resource_grants.get(resource_id)
            if current is not None and (
                token < current[1] or (token == current[1] and owner != current[0])
            ):
                raise ValueError("resource fencing token must be monotonic")
            self.journal.set_resource_grant(resource_id, owner, token)
            self._resource_grants[resource_id] = (owner, token)

    def GetRuntimeInfo(self, request, context):
        info = self.backend.capabilities()
        self._validate_current_profile(info)
        info.protocol_version = "1.0"
        if not info.runtime_version:
            info.runtime_version = info.software_version
        if not info.adapter_version:
            info.adapter_version = info.runtime_version or info.software_version or "v1"
        if self.safety.estop_latched:
            info.manipulation_ready = False
            info.blockers.append("EMERGENCY_STOP_LATCHED")
            for item in info.capabilities:
                if item.safety_level == "physical_motion" or item.name in PHYSICAL_SKILLS:
                    item.available = False
                    item.blockers.append("EMERGENCY_STOP_LATCHED")
        info.catalog_revision = self._catalog_revision(info)
        return runtime_info_to_proto(info)

    @staticmethod
    def _catalog_revision(info: RuntimeInfo) -> str:
        tools = []
        for item in sorted(info.capabilities, key=lambda value: value.name):
            side_effect = "read_only"
            if item.name == "emergency_stop":
                side_effect = "emergency"
            elif item.safety_level == "physical_motion":
                side_effect = "physical_atomic"
            tool = {"name": item.name}
            if item.description:
                tool["description"] = item.description
            if item.input_parameters:
                tool["inputParameters"] = sorted(item.input_parameters)
            if item.output_parameters:
                tool["outputParameters"] = sorted(item.output_parameters)
            tool["sideEffectClass"] = side_effect
            if item.safety_level:
                tool["safetyLevel"] = item.safety_level
            # A catalogue revision identifies the execution contract. Sensor age,
            # estop and other live availability are checked again by Safety;
            # including them here makes an unchanged plan spuriously stale.
            tools.append(tool)
        if info.robot_profile is None:
            # Preserve the legacy unprofiled catalogue format.
            wire = json.dumps(tools, ensure_ascii=False, separators=(",", ":")).encode()
        else:
            # Limits, calibration, mobility and stop procedures are part of an
            # approved plan's meaning. Reusing tool names after a restart must
            # never reuse approval for a different robot execution contract.
            profile = RobotProfile.model_validate(info.robot_profile).to_wire()
            wire = json.dumps({"schemaVersion": "robot.execution-catalog.v2", "tools": tools,
                               "robotProfile": profile}, sort_keys=True, ensure_ascii=False,
                              separators=(",", ":"), allow_nan=False).encode()
        return hashlib.sha256(wire).hexdigest()

    def _validated_observation(self, request: ObservationRequest) -> Observation:
        # Concurrent camera viewers must not validate a newer capture before an
        # earlier, slower reconstruction. Keep acquisition and tracker acceptance
        # in one ordered transaction; the tracker still rejects real regressions.
        with self._observation_lock:
            return self._acquire_validated_observation(request)

    def _acquire_validated_observation(self, request: ObservationRequest) -> Observation:
        self._validate_current_profile(self.backend.capabilities())
        observation = self.backend.observe(request)
        from .rgbd_images import validate_observation_images

        validate_observation_images(observation)
        if self._profile is not None:
            reconstruction = validate_reconstruction(observation.reconstruction, self._profile)
            if (observation.observation_id != reconstruction.observation_id
                    or observation.wall_time_unix_ms != reconstruction.observed_at_unix_ms):
                raise ValueError("observation identity or capture time disagrees with reconstruction")
            projected = project_entities(reconstruction)
            if observation.entities != projected:
                raise ValueError("legacy entities disagree with validated reconstruction")
            self._reconstruction_tracker.accept(reconstruction)
            observation.reconstruction = reconstruction.to_wire()
        return observation

    def Observe(self, request, context):
        try:
            observation = self._validated_observation(observation_from_proto(request))
        except (ValueError, TypeError) as exc:
            if context is not None:
                context.abort(grpc.StatusCode.FAILED_PRECONDITION, f"RECONSTRUCTION_INVALID: {exc}")
            raise
        runtime_state = self._semantic_state()
        backend_state = observation.semantic_state
        for anomaly in backend_state.anomalies:
            if anomaly not in runtime_state.anomalies:
                runtime_state.anomalies.append(anomaly)
        if runtime_state.last_error == "" and backend_state.last_error:
            runtime_state.last_error = backend_state.last_error
        observation.semantic_state = runtime_state
        yield observation_to_proto(observation)

    def ExecuteSkill(self, request, context):
        yield from self.execute_for_test(request, rpc_context=context)

    def invoke(self, command: Command) -> Result:
        """In-process port using the exact RPC admission and journal path.

        Tool adapters share this service instance with the RPC server. Creating
        another supervisor around the same hardware would split ownership.
        """
        request = robot_pb2.SkillCommand(
            schema_version=command.schema_version, command_id=command.command_id,
            task_id=command.task_id, skill=command.capability, target_ref=command.target_ref,
            deadline_unix_ms=command.deadline_unix_ms, lease_ms=command.lease_ms,
            idempotency_key=command.idempotency_key, safety_profile=command.safety_profile,
            approval_id=command.approval_id, robot_id=command.robot_id,
            catalog_revision=command.catalog_revision, world_revision_basis=command.world_revision_basis,
            resource_id=command.resource_id, fencing_token=command.fencing_token,
        )
        ParseDict(command.parameters, request.parameters)
        events = list(self.execute_for_test(request))
        if not events:
            return Result(False, "EXECUTION_OUTCOME_UNKNOWN", confidence=0.0)
        terminal = events[-1]
        if command.capability == "emergency_stop":
            return Result(self.safety.estop_latched, terminal.code, terminal.message,
                          payload={"latched": self.safety.estop_latched})
        return Result(
            terminal.type == robot_pb2.SKILL_EVENT_SUCCEEDED, terminal.code, terminal.message,
            terminal.observation_id, terminal.verification_confidence,
            {key: value for key, value in MessageToDict(terminal.details).items()
             if key in {"state_report_json", "state_report_nl"}},
        )

    def observe_once(self, request: ObservationRequest) -> Observation:
        observation = self._validated_observation(request)
        if self.safety.estop_latched:
            observation.semantic_state = self._semantic_state()
        return observation

    def cancel_command(self, command_id: str, reason: str) -> bool:
        return self.Cancel(robot_pb2.CancelRequest(command_id=command_id, reason=reason), None).accepted

    def execute_for_test(self, request: robot_pb2.SkillCommand, *, rpc_context=None):
        try:
            command = command_from_proto(request)
            fingerprint = self._fingerprint(command)
        except (ValueError, TypeError):
            yield self._event(request, 1, robot_pb2.SKILL_EVENT_FAILED,
                              "COMMAND_PARAMETERS_INVALID")
            return
        if command.capability == "emergency_stop":
            # Same authority as the dedicated mTLS EmergencyStop RPC: a stop
            # must preempt motion even while that motion owns admission.
            self.safety.emergency_stop("EMERGENCY_STOP_REQUESTED")
            yield self._event(command, 1, robot_pb2.SKILL_EVENT_SAFETY_STOPPED,
                              self.safety.last_stop_reason)
            return
        # Admission is per robot, including requests that reuse command_id with
        # a different key. Stop/observe RPCs never acquire this execution lock.
        if not self._execution_lock.acquire(blocking=False):
            code = "ROBOT_BUSY"
            if self._inflight and self._inflight[0] == command.idempotency_key:
                code = ("EXECUTION_OUTCOME_UNKNOWN" if self._inflight[1] == fingerprint
                        else "IDEMPOTENCY_CONFLICT")
            yield self._event(command, 1, robot_pb2.SKILL_EVENT_FAILED, code)
            return
        self._inflight = (command.idempotency_key, fingerprint)
        try:
            yield from self._execute_command(command, fingerprint, rpc_context)
        except OSError:
            # If the write-ahead record or terminal flush fails, success is not
            # durable. Keep motion disabled and report an inspectable failure.
            self.safety.emergency_stop("RUNTIME_JOURNAL_UNAVAILABLE")
            yield self._event(command, 1, robot_pb2.SKILL_EVENT_SAFETY_STOPPED,
                              "RUNTIME_JOURNAL_UNAVAILABLE")
        finally:
            self.safety.complete(command.command_id)
            self._inflight = None
            self._execution_lock.release()

    def _execute_command(self, command: Command, fingerprint: str, rpc_context=None):
        if command.idempotency_key:
            persisted = self.journal.lookup(command.idempotency_key, fingerprint)
            if persisted.status == "conflict":
                yield self._event(command, 1, robot_pb2.SKILL_EVENT_FAILED, "IDEMPOTENCY_CONFLICT")
                return
            if persisted.status in ("pending", "reconciled"):
                yield self._event(command, 1, robot_pb2.SKILL_EVENT_FAILED,
                                  "EXECUTION_OUTCOME_UNKNOWN")
                return
            if persisted.status == "replay":
                for encoded in persisted.events:
                    event = robot_pb2.SkillEvent()
                    event.ParseFromString(bytes.fromhex(encoded))
                    yield event
                return
        with self._results_lock:
            cached = self._results.get(command.idempotency_key)
        if cached is not None:
            fingerprint, events = cached
            if fingerprint != self._fingerprint(command):
                yield self._event(command, 1, robot_pb2.SKILL_EVENT_FAILED, "IDEMPOTENCY_CONFLICT")
                return
            yield from (copy.deepcopy(event) for event in events)
            return

        identity_error = self._validate_identity(command)
        if identity_error:
            events = [self._event(command, 1, robot_pb2.SKILL_EVENT_FAILED, identity_error)]
            with self._results_lock:
                self._results[command.idempotency_key] = (fingerprint, events)
            if command.idempotency_key:
                self.journal.record(
                    command.idempotency_key,
                    fingerprint,
                    [event.SerializeToString(deterministic=True).hex() for event in events],
                )
            yield copy.deepcopy(events[0])
            return

        if rpc_context is not None and not rpc_context.is_active():
            yield self._event(command, 1, robot_pb2.SKILL_EVENT_CANCELLED, "CLIENT_DISCONNECTED")
            return
        decision = self._admit_when_sensors_ready(command, rpc_context)
        if not decision.allowed:
            events = [self._event(command, 1, robot_pb2.SKILL_EVENT_FAILED, decision.code, message=decision.message)]
        else:
            self.journal.begin(command.idempotency_key, fingerprint)
            events = [
                self._event(command, 1, robot_pb2.SKILL_EVENT_ACCEPTED, "ACCEPTED", 0.0),
                self._event(command, 2, robot_pb2.SKILL_EVENT_RUNNING, "RUNNING", 0.25),
            ]
            watchdog_stop = threading.Event()
            watchdog = threading.Thread(
                target=self._watch_command,
                args=(watchdog_stop, command.lease_ms, command.command_id, rpc_context),
                name=f"lease-watchdog-{command.command_id}",
                daemon=True,
            )
            watchdog.start()
            command_evidence = None
            try:
                try:
                    # fsync and admission may outlast the original lease or
                    # deadline; check again immediately before side effects.
                    self.safety.tick()
                    if self.safety.estop_latched:
                        result = BackendResult(False, self.safety.last_stop_reason)
                    elif command.command_id in self._cancelled:
                        result = BackendResult(False, "CANCELLED")
                    else:
                        result = self._execute_backend(command)
                        waiter = getattr(self.backend, "wait_command_capture", None)
                        if result.success and callable(waiter):
                            completed_ns, completed_ms = time.monotonic_ns(), int(time.time() * 1000)
                            if not waiter(command, completed_ns, completed_ms):
                                result = BackendResult(False, "POSTCONDITION_OBSERVATION_TIMEOUT",
                                    "Command ended without a newer capture; reconcile before retrying motion")
                            else:
                                captured = self._validated_observation(ObservationRequest())
                                if captured.wall_time_unix_ms <= completed_ms:
                                    result = BackendResult(False, "POSTCONDITION_OBSERVATION_TIMEOUT")
                                else:
                                    command_evidence = observation_to_proto(captured)
                                    result = replace(result, observation_id=captured.observation_id)
                except Exception as exc:  # noqa: BLE001 - fail closed on any backend fault
                    result = BackendResult(False, "BACKEND_ERROR", str(exc))
            finally:
                watchdog_stop.set()
                watchdog.join(timeout=0.2)
            # Completion and cancellation admission share one decision point.
            # A cancel accepted before completion cannot turn into success.
            with self._results_lock:
                if self.safety.estop_latched:
                    event_type = robot_pb2.SKILL_EVENT_SAFETY_STOPPED
                    code = self.safety.last_stop_reason or "SAFETY_STOPPED"
                elif command.command_id in self._cancelled:
                    event_type = robot_pb2.SKILL_EVENT_CANCELLED
                    code = "CANCELLED"
                elif result.success:
                    event_type = robot_pb2.SKILL_EVENT_SUCCEEDED
                    code = result.code
                else:
                    event_type = robot_pb2.SKILL_EVENT_FAILED
                    code = result.code
                self._cancelled.discard(command.command_id)
                self.safety.complete(command.command_id)
            events.append(
                self._event(
                    command,
                    3,
                    event_type,
                    code,
                    1.0,
                    result.confidence,
                    result.message or code,
                    result.observation_id,
                )
            )
            if command_evidence is not None:
                events[-1].evidence_observation.CopyFrom(command_evidence)
            if result.payload.get("state_report_json"):
                events[-1].details.update({key: result.payload[key] for key in
                                          ("state_report_json", "state_report_nl")})
        if command.idempotency_key:
            self.journal.record(
                command.idempotency_key,
                fingerprint,
                [event.SerializeToString(deterministic=True).hex() for event in events],
            )
        with self._results_lock:
            self._results[command.idempotency_key] = (fingerprint, events)
        yield from (copy.deepcopy(event) for event in events)

    def _admit_when_sensors_ready(self, command: Command, rpc_context=None):
        """Bound a transient sensor freshness gap before durable admission.

        No command is journaled or sent to hardware while waiting. Every retry
        rechecks the complete safety policy, including deadline and estop.
        """
        decision = self.safety.start(command)
        transient = {"IMU_NOT_READY", "RGBD_NOT_READY", "JOINT_FEEDBACK_STALE",
                     "SUCTION_FEEDBACK_STALE"}
        # Sample the authoritative deadline clock before anchoring its remaining
        # duration. A preemption between monotonic -> wall samples would shorten
        # the wait and could report sensor unavailability just before expiry.
        remaining = max(0., (command.deadline_unix_ms - self.safety.clock_ms()) / 1000.)
        limit = time.monotonic() + min(5.0, remaining)
        while (not decision.allowed and decision.code == "CAPABILITY_UNAVAILABLE"
               and set(filter(None, (part.strip() for part in decision.message.split(",")))).issubset(transient)
               and decision.message and command.approval_id and time.monotonic() < limit):
            if rpc_context is not None and not rpc_context.is_active():
                return type(decision)(False, "CLIENT_DISCONNECTED")
            delay = min(.05, max(0., limit - time.monotonic()),
                        max(0., (command.deadline_unix_ms - self.safety.clock_ms()) / 1000.))
            if delay <= 0:
                break
            time.sleep(delay)
            decision = self.safety.start(command)
        # Capability inspection may cross the deadline after Safety.start's
        # initial check. Resolve that stale rejection through the same policy,
        # preserving estop/busy precedence without another wait or dispatch.
        if (not decision.allowed and decision.code == "CAPABILITY_UNAVAILABLE"
                and command.deadline_unix_ms <= self.safety.clock_ms()):
            decision = self.safety.start(command)
        return decision

    def _execute_backend(self, command: Command) -> BackendResult:
        if self._profile is not None:
            try:
                self._validated_observation(ObservationRequest())
            except Exception as exc:  # noqa: BLE001 - custom adapter faults must not bypass admission
                return BackendResult(False, "RECONSTRUCTION_INVALID", str(exc), confidence=0.0)
            # Perception may block beyond a lease or be cancelled. Never enter
            # the handler merely because the earlier admission was valid.
            self.safety.tick()
            if self.safety.estop_latched:
                return BackendResult(False, self.safety.last_stop_reason, confidence=0.0)
            if command.command_id in self._cancelled:
                return BackendResult(False, "CANCELLED", confidence=0.0)
        try:
            invoke = lambda: validate_result(self.backend.execute(command))
            if self.grounded is not None:
                physical = command.capability in PHYSICAL_TOOLS or any(
                    item.name == command.capability and getattr(item, "mutates_world", False)
                    for item in self.backend.capabilities().capabilities)
                return self.grounded.execute(self.backend, command, invoke, physical=physical)
            return invoke()
        except Exception as exc:  # noqa: BLE001 - dispatch may already have moved hardware
            if command.capability in PHYSICAL_TOOLS:
                self.safety.emergency_stop("EXECUTION_OUTCOME_UNKNOWN")
                return BackendResult(False, "EXECUTION_OUTCOME_UNKNOWN", str(exc), confidence=0.0)
            code = "TOOL_RESULT_INVALID" if isinstance(exc, InvalidToolResult) else "BACKEND_ERROR"
            return BackendResult(False, code, str(exc), confidence=0.0)

    def _validate_identity(self, command: Command) -> str:
        info = self.backend.capabilities()
        try:
            self._validate_current_profile(info)
        except ValueError:
            return "ROBOT_PROFILE_INVALID"
        if self._profile is not None:
            if not command.robot_id:
                return "ROBOT_ID_REQUIRED"
            if not command.catalog_revision:
                return "TOOL_CATALOG_REVISION_REQUIRED"
        current_revision = self._catalog_revision(info)
        if command.robot_id and command.robot_id != info.robot_id:
            return "ROBOT_ID_MISMATCH"
        if command.catalog_revision and command.catalog_revision != current_revision:
            return "TOOL_CATALOG_STALE"
        if command.resource_id:
            if not command.catalog_revision:
                return "TOOL_CATALOG_REVISION_REQUIRED"
            if command.world_revision_basis == 0:
                return "WORLD_REVISION_REQUIRED"
            if command.fencing_token == 0:
                return "FENCING_TOKEN_REQUIRED"
            with self._results_lock:
                grant = self._resource_grants.get(command.resource_id)
                owner = command.robot_id or info.robot_id
                if grant is None:
                    return "RESOURCE_GRANT_REQUIRED"
                if grant[0] != owner or command.fencing_token != grant[1]:
                    return "FENCING_TOKEN_STALE"
        return ""

    def _watch_command(self, stop: threading.Event, lease_ms: int, command_id="", rpc_context=None) -> None:
        interval = max(0.005, min(0.05, lease_ms / 10_000))
        while not stop.wait(interval):
            if rpc_context is not None and not rpc_context.is_active():
                # Repeat until the handler unwinds: stop may race handler entry.
                self.cancel_command(command_id, "CLIENT_DISCONNECTED")
            self.safety.tick()
            if self.safety.estop_latched:
                return

    def Cancel(self, request, context):
        # Publish cancellation before stop() can unblock execute(). Otherwise
        # a cooperative backend can finish before the terminal path sees it.
        with self._results_lock:
            if self.safety.active_command_id != request.command_id:
                return robot_pb2.CancelResult(accepted=False, state="UNKNOWN")
            self._cancelled.add(request.command_id)
        # If execution completes after admission, it sees the cancellation and
        # releases safety ownership itself. The request was still accepted.
        self.safety.cancel(request.command_id, request.reason)
        return robot_pb2.CancelResult(accepted=True, state="CANCELLED")

    def EmergencyStop(self, request, context):
        self.safety.emergency_stop(request.reason or "REMOTE_EMERGENCY_STOP")
        return robot_pb2.EStopResult(latched=True, stopped_unix_ms=int(time.time() * 1000))

    def _semantic_state(self) -> SemanticState:
        if self.safety.estop_latched:
            return semantic_state(
                activity="EMERGENCY_STOPPED",
                emergency_stopped=True,
                anomalies=[self.safety.last_stop_reason or "EMERGENCY_STOP_LATCHED"],
                last_error=self.safety.last_stop_reason,
            )
        if self.safety.active_command_id:
            return semantic_state(activity="EXECUTING")
        return semantic_state(activity="IDLE")

    @staticmethod
    def _event(
        command,
        sequence,
        event_type,
        code,
        progress=0.0,
        confidence=0.0,
        message="",
        observation_id="",
    ):
        return robot_pb2.SkillEvent(
            command_id=command.command_id,
            sequence=sequence,
            type=event_type,
            code=code,
            message=message or code,
            progress=progress,
            verification_confidence=confidence,
            observation_id=observation_id,
            monotonic_time_ns=time.monotonic_ns(),
        )

    @staticmethod
    def _fingerprint(command):
        digest = hashlib.sha256()
        for value in (
            command.schema_version,
            command.task_id,
            command.capability,
            command.target_ref,
            command.safety_profile,
            command.robot_id,
            command.catalog_revision,
            str(command.world_revision_basis),
            command.resource_id,
            str(command.fencing_token),
        ):
            digest.update(value.encode())
            digest.update(b"\0")
        digest.update(
            json.dumps(
                command.parameters,
                sort_keys=True,
                separators=(",", ":"),
                allow_nan=False,
            ).encode()
        )
        return digest.hexdigest()


def start_server(
    backend: RobotBackend,
    address: str,
    *,
    journal: RuntimeJournal | None = None,
    server_key: Path | None = None,
    server_cert: Path | None = None,
    client_ca: Path | None = None,
    allow_insecure: bool = False,
):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=8))
    robot_pb2_grpc.add_RobotRuntimeServicer_to_server(
        RobotRuntimeService(backend, journal=journal), server
    )
    if allow_insecure:
        server.add_insecure_port(address)
    elif server_key and server_cert and client_ca:
        credentials = grpc.ssl_server_credentials(
            [(server_key.read_bytes(), server_cert.read_bytes())],
            root_certificates=client_ca.read_bytes(),
            require_client_auth=True,
        )
        server.add_secure_port(address, credentials)
    else:
        raise ValueError("mTLS credentials are required unless allow_insecure is explicit")
    server.start()
    return server


def serve(backend: RobotBackend, address: str, **security) -> None:
    server = start_server(backend, address, **security)
    server.wait_for_termination()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--listen", default="0.0.0.0:50051")
    parser.parse_args()
    raise SystemExit("start the gateway through the ROS 2 xlerobot adapter launch file")


if __name__ == "__main__":
    main()
