"""Known-scene calibration from surveyed static CAD and actual lidar returns.

Only static collision geometry is read from SDF. Robot poses, sensor poses,
simulator world hits and dynamic model state are deliberately excluded. This is
known-scene registration, not calibration in an unknown environment. A separate
surveyed stationary base pose is needed to interpret the estimate as extrinsics.
"""
from __future__ import annotations

import hashlib
import json
import math
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation

from tangying_robot_gateway.registered_alignment import (
    register_point_clouds,
    transform_points,
)


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


def _numbers(text, count, name):
    result = [float(value) for value in (text or "").split()]
    if len(result) != count or not all(math.isfinite(value) for value in result):
        raise ValueError(f"invalid static CAD {name}")
    return np.asarray(result)


def _pose(element):
    node = element.find("pose")
    if node is not None and (node.get("relative_to") or node.get("degrees") == "true"):
        raise ValueError("surveyed CAD accepts only local radian poses")
    values = np.zeros(6) if node is None else _numbers(node.text, 6, "pose")
    matrix = np.eye(4)
    matrix[:3, :3] = Rotation.from_euler("xyz", values[3:]).as_matrix()
    matrix[:3, 3] = values[:3]
    return matrix


def load_surveyed_scene(sdf_path):
    """Read bounded static box/plane geometry; ignore every non-static model."""
    path = Path(sdf_path)
    if path.stat().st_size > 4 * 1024 * 1024:
        raise ValueError("surveyed scene exceeds 4 MiB")
    root = ET.fromstring(path.read_text())
    world = root.find("world")
    if world is None:
        raise ValueError("surveyed CAD requires one SDF world")
    surfaces = []
    for model in world.findall("model"):
        if (model.findtext("static") or "").strip().lower() != "true":
            continue
        model_pose = _pose(model)
        for link in model.findall("link"):
            link_pose = model_pose @ _pose(link)
            for collision in link.findall("collision"):
                transform = link_pose @ _pose(collision)
                geometry = collision.find("geometry")
                box = geometry.find("box") if geometry is not None else None
                plane = geometry.find("plane") if geometry is not None else None
                if box is not None:
                    size = _numbers(box.findtext("size"), 3, "box size")
                    kind = "box"
                elif plane is not None:
                    normal = _numbers(plane.findtext("normal"), 3, "plane normal")
                    if not np.allclose(normal, [0., 0., 1.], atol=1e-9, rtol=0):
                        raise ValueError("surveyed plane normal must be local +Z")
                    size = _numbers(plane.findtext("size"), 2, "plane size")
                    kind = "plane"
                else:
                    raise ValueError("unsupported surveyed static collision geometry")
                if np.any(size <= 0) or np.any(size > 1000):
                    raise ValueError("static CAD dimensions must be positive bounded metres")
                surfaces.append({"name": "/".join([model.get("name", ""), link.get("name", ""),
                                                   collision.get("name", "")]),
                                 "kind": kind, "size": size.tolist(),
                                 "localToWorld": transform.tolist()})
    if not surfaces or len(surfaces) > 128:
        raise ValueError("survey requires 1..128 static collision geometries")
    return {"schemaVersion": "simulation.surveyed-cad.v1", "frameId": "world",
            "surfaces": surfaces, "revision": _hash(surfaces),
            "robotOrSensorPosesRead": False}


def sample_surveyed_scene(scene, *, spacing_m=.22, maximum_points=4096,
                          bounds=((-5., -5., 0.), (5., 5., 3.)), seed=0):
    """Sample fixed CAD faces inside an a priori ROI, independent of any scan."""
    if (type(maximum_points) is not int or not 12 <= maximum_points <= 4096
            or type(seed) is not int or not 0 <= seed < 2**32
            or not isinstance(spacing_m, (int, float)) or isinstance(spacing_m, bool)
            or not .05 <= spacing_m <= 1.):
        raise ValueError("invalid bounded CAD sampling settings")
    limits = np.asarray(bounds, dtype=float)
    if limits.shape != (2, 3) or not np.isfinite(limits).all() or np.any(limits[1] <= limits[0]):
        raise ValueError("CAD sampling bounds must be finite lower/upper xyz")
    points = []
    generated_count = 0
    for surface in scene["surfaces"]:
        size = np.asarray(surface["size"])
        transform = np.asarray(surface["localToWorld"])
        axes = range(3) if surface["kind"] == "box" else (2,)
        for axis in axes:
            tangent = [index for index in range(3) if index != axis]
            dimensions = size[tangent] if surface["kind"] == "box" else size
            coordinates = [np.linspace(-extent / 2, extent / 2,
                                       max(2, int(math.ceil(extent / spacing_m)) + 1))
                           for extent in dimensions]
            generated_count += len(coordinates[0]) * len(coordinates[1]) * (2 if surface["kind"] == "box" else 1)
            if generated_count > 250_000:
                raise ValueError("CAD surface sampling exceeds bounded point budget")
            grid = np.stack(np.meshgrid(*coordinates, indexing="ij"), axis=-1).reshape(-1, 2)
            sides = (-1., 1.) if surface["kind"] == "box" else (0.,)
            for side in sides:
                local = np.zeros((len(grid), 3))
                local[:, tangent] = grid
                if surface["kind"] == "box":
                    local[:, axis] = side * size[axis] / 2
                world = local @ transform[:3, :3].T + transform[:3, 3]
                mask = np.all(world >= limits[0] - 1e-8, axis=1) & np.all(world <= limits[1] + 1e-8, axis=1)
                points.extend(world[mask])
    result = np.unique(np.round(np.asarray(points), decimals=10), axis=0)
    if len(result) < 12:
        raise ValueError("CAD ROI contains fewer than 12 sampled points")
    if len(result) > maximum_points:
        selected = np.random.default_rng(seed).choice(len(result), maximum_points, replace=False)
        result = result[np.sort(selected)]
    return {"schemaVersion": "simulation.surveyed-cloud.v1", "sceneRevision": scene["revision"],
            "sampling": {"spacingM": spacing_m, "maximumPoints": maximum_points,
                         "bounds": limits.tolist(), "seed": seed},
            "points": result.tolist(), "pointsSha256": _hash(result.tolist())}


def nearest_surface_distances(points_world, scene):
    """Analytic distance to static CAD surfaces, without sampled-cloud aliasing."""
    points = np.asarray(points_world, dtype=float)
    if (points.ndim != 2 or points.shape[1] != 3 or not 1 <= len(points) <= 100_000
            or not np.isfinite(points).all()):
        raise ValueError("surface distance requires bounded finite Nx3 points")
    minimum = np.full(len(points), np.inf)
    for surface in scene["surfaces"]:
        transform, size = np.asarray(surface["localToWorld"]), np.asarray(surface["size"])
        local = (points - transform[:3, 3]) @ transform[:3, :3]
        if surface["kind"] == "box":
            offset = np.abs(local) - size / 2
            distance = np.linalg.norm(np.maximum(offset, 0.), axis=1)
            inside = np.all(offset < 0., axis=1)
            distance[inside] = np.min(-offset[inside], axis=1)
        else:
            tangent = np.maximum(np.abs(local[:, :2]) - size / 2, 0.)
            distance = np.sqrt(np.sum(tangent**2, axis=1) + local[:, 2]**2)
        minimum = np.minimum(minimum, distance)
    return minimum


def calibrate_in_known_scene(sensor_points, scene, reference_cloud, *, source_evidence,
                             target_evidence, surveyed_base_to_world=None, seed=0,
                             max_correspondence_m=.4, max_rmse_m=.16, min_overlap=.35,
                             holdout_residual_m=.08, min_holdout_inlier_ratio=.85):
    """Fit 80% of actual returns against CAD, evaluate remaining 20% analytically.

    Defaults are declared coarse commissioning gates for this sparse lidar
    fixture; they do not demonstrate fine sensor accuracy. Dynamic returns are
    retained in the holdout denominator. No true sensor pose is an input.
    """
    points = np.asarray(sensor_points, dtype=float)
    if (points.ndim != 2 or points.shape[1] != 3 or not 30 <= len(points) <= 100_000
            or not np.isfinite(points).all() or type(seed) is not int or not 0 <= seed < 2**32):
        raise ValueError("known-scene calibration requires bounded finite measured Nx3 points")
    if (not isinstance(holdout_residual_m, (int, float)) or not 0 < holdout_residual_m <= 1.
            or not isinstance(min_holdout_inlier_ratio, (int, float))
            or not 0 < min_holdout_inlier_ratio <= 1.):
        raise ValueError("invalid holdout gates")
    if reference_cloud.get("sceneRevision") != scene["revision"]:
        raise ValueError("reference cloud belongs to a different surveyed scene")
    if reference_cloud.get("pointsSha256") != _hash(reference_cloud["points"]):
        raise ValueError("surveyed reference points do not match their digest")
    if target_evidence.get("mapRevision") != scene["revision"] or target_evidence.get("frameId") != "world":
        raise ValueError("target evidence must name the surveyed CAD revision and world frame")
    rng = np.random.default_rng(seed)
    shuffled = rng.permutation(len(points))
    holdout_indices = shuffled[:max(6, len(points) // 5)]
    fit_indices = shuffled[len(holdout_indices):][:4096]
    result = register_point_clouds(points[fit_indices], reference_cloud["points"],
                                   source_evidence=source_evidence, target_evidence=target_evidence,
                                   max_correspondence_m=max_correspondence_m,
                                   max_rmse_m=max_rmse_m, min_overlap=min_overlap)
    output = {"schemaVersion": "simulation.known-scene-calibration.v1",
              "method": "measured-lidar-to-independent-static-cad",
              "accepted": False, "registration": result, "sceneRevision": scene["revision"],
              "referencePointsSha256": reference_cloud["pointsSha256"],
              "measuredPointsSha256": _hash(points.tolist()), "seed": seed,
              "fitIndices": fit_indices.tolist(), "holdoutIndices": holdout_indices.tolist(),
              "unusedIndices": shuffled[len(holdout_indices) + len(fit_indices):].tolist(),
              "holdoutResidualLimitM": holdout_residual_m,
              "minimumHoldoutInlierRatio": min_holdout_inlier_ratio,
              "estimatedSensorToWorld": None, "estimatedSensorToBase": None,
              "truthTransformUsedForEstimation": False}
    if not result["accepted"]:
        output["code"] = result["code"]
        return output
    estimate = np.asarray(result["sourceToTarget"])
    held_points = np.vstack([transform_points(points[holdout_indices[start:start + 4096]], estimate)
                             for start in range(0, len(holdout_indices), 4096)])
    residuals = nearest_surface_distances(held_points, scene)
    output["holdout"] = {"count": len(residuals), "rmseM": float(np.sqrt(np.mean(residuals**2))),
                         "medianM": float(np.median(residuals)),
                         "p95M": float(np.quantile(residuals, .95)),
                         "inlierRatio": float(np.mean(residuals <= holdout_residual_m))}
    if output["holdout"]["inlierRatio"] < min_holdout_inlier_ratio:
        output["code"] = "HELD_OUT_CAD_RESIDUAL_REJECTED"
        return output
    output.update(accepted=True, code="ACCEPTED", estimatedSensorToWorld=estimate.tolist())
    if surveyed_base_to_world is not None:
        # Validate the independently surveyed station transform through the same
        # SE3 check, then derive sensor extrinsics; never read dynamic SDF poses.
        transform_points([[0., 0., 0.]], surveyed_base_to_world)
        output["estimatedSensorToBase"] = (np.linalg.inv(surveyed_base_to_world) @ estimate).tolist()
        output["surveyedBaseToWorld"] = np.asarray(surveyed_base_to_world).tolist()
    return output
