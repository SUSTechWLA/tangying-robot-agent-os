"""Robot gateway contract tests."""
