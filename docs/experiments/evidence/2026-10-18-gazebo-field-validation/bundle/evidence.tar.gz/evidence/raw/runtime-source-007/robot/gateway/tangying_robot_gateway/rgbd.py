"""Sensor-only RGB-D reconstruction. Optical coordinates: right, down, forward.

No simulator, robot driver or object-position registry is available here. A
detector identifies pixels; metric geometry comes exclusively from valid depth.
"""

from __future__ import annotations

import math
import time
from collections.abc import Callable
from dataclasses import dataclass, field

import numpy as np

from .contracts import Entity, Reconstruction


@dataclass(frozen=True)
class RgbdFrame:
    robot_id: str
    source_id: str
    frame_id: str
    transform_revision: str
    captured_at_unix_ms: int
    sequence: int
    rgb: np.ndarray
    depth_m: np.ndarray
    intrinsics: np.ndarray
    world_from_camera: np.ndarray


@dataclass(frozen=True)
class PixelDetection:
    entity_id: str
    category: str
    mask: np.ndarray
    confidence: float
    attributes: dict[str, str] = field(default_factory=dict)


#: How old a capture may be at the moment the driver hands it over, in ms.
#:
#: This answers one sensor-health question - *was this frame already old when the
#: camera produced it* - and that is the only question it may be used for.
#:
#: Measured on the reference stack, acquisition (render plus frame assembly) runs
#: at p50 38 ms, p90 51 ms, p99 1040 ms, so 2000 ms is about twice the worst
#: acquisition observed. The margin is deliberately thin: it is a staleness bound,
#: not a processing budget.
#:
#: Using it as a processing budget is what broke every bounded pulse longer than
#: 0.10 m. The driver sleeps ``step / 0.05 m/s`` while a pulse executes (0.10 m ->
#: 2.0 s, 0.50 m -> 10.0 s) and then re-checked the frame it had taken *before*
#: the sleep against this same 2000 ms, so the check failed by construction at
#: every step above 0.10 m - on an idle machine as much as a loaded one.
DEFAULT_MAX_AGE_MS = 2000


def validate_frame(frame: RgbdFrame, now_ms: int | None = None,
                   max_age_ms: int | None = DEFAULT_MAX_AGE_MS) -> None:
    """Check a frame's shape, identity and - optionally - its age.

    ``max_age_ms=None`` checks everything except age. That is the right call for a
    consumer holding a frame the driver already accepted at acquisition: turning
    depth into points, or acting on a pulse that was collision-checked against this
    very observation, are not new opportunities to re-litigate how long the
    pipeline has been running. Age belongs where the frame enters the system, and
    that is where it is now checked.
    """
    now_ms = int(time.time() * 1000) if now_ms is None else now_ms
    if not all(
        isinstance(x, str) and x and not any(c.isspace() for c in x)
        for x in (
            frame.robot_id,
            frame.source_id,
            frame.frame_id,
            frame.transform_revision,
        )
    ):
        raise ValueError("RGB-D identity and calibration revision are required")
    if type(frame.sequence) is not int or not 0 < frame.sequence <= 9_007_199_254_740_991:
        raise ValueError("RGB-D sequence must be a positive safe integer")
    age_ms = now_ms - frame.captured_at_unix_ms if type(frame.captured_at_unix_ms) is int else None
    if age_ms is None:
        # Always required, whatever the age policy: a frame with no integer capture
        # time cannot be placed in time by anyone downstream either.
        raise ValueError("RGB-D capture has no integer capture time")
    if max_age_ms is not None and not 0 <= age_ms <= max_age_ms:
        # The age is part of the message: "stale" and "future dated" need
        # different investigations, and how stale tells you which.
        raise ValueError(f"RGB-D capture is stale or future dated (age {age_ms} ms)")
    rgb, depth = frame.rgb, frame.depth_m
    if (
        not isinstance(rgb, np.ndarray)
        or rgb.dtype != np.uint8
        or rgb.ndim != 3
        or rgb.shape[2] != 3
    ):
        raise ValueError("RGB must be uint8 HxWx3")
    if not 0 < rgb.shape[0] <= 2160 or not 0 < rgb.shape[1] <= 3840:
        raise ValueError("RGB dimensions exceed bounded capture size")
    if not isinstance(depth, np.ndarray) or depth.shape != rgb.shape[:2] or depth.dtype.kind != "f":
        raise ValueError("aligned depth must be floating-point metres with RGB dimensions")
    k, transform = np.asarray(frame.intrinsics), np.asarray(frame.world_from_camera)
    if k.shape != (3, 3) or not np.isfinite(k).all() or k[0, 0] <= 0 or k[1, 1] <= 0:
        raise ValueError("valid camera intrinsics are required")
    if not np.allclose(k[2], [0, 0, 1]) or abs(k[0, 1]) + abs(k[1, 0]) > 1e-6:
        raise ValueError("intrinsics must describe a rectified pinhole camera")
    if not (0 <= k[0, 2] < rgb.shape[1] and 0 <= k[1, 2] < rgb.shape[0]):
        raise ValueError("principal point lies outside image")
    if transform.shape != (4, 4) or not np.isfinite(transform).all():
        raise ValueError("world_from_camera must be a finite 4x4 rigid transform")
    rotation = transform[:3, :3]
    if (
        not np.allclose(transform[3], [0, 0, 0, 1])
        or not np.allclose(rotation.T @ rotation, np.eye(3), atol=1e-5)
        or not math.isclose(float(np.linalg.det(rotation)), 1.0, abs_tol=1e-5)
    ):
        raise ValueError("world_from_camera must be a proper rigid transform")


def deproject(frame: RgbdFrame, *, max_depth_m: float = 5.0) -> tuple[np.ndarray, np.ndarray]:
    """Return HxWx3 world points and a validity mask; missing depth stays missing.

    Structure only, no age check: this runs in the perception consumers, which is
    by definition later than acquisition, and re-asking "is this frame stale" here
    measures the consumer's own runtime rather than the camera's health.
    """
    validate_frame(frame, max_age_ms=None)
    depth = frame.depth_m
    valid = np.isfinite(depth) & (depth > 0.02) & (depth <= max_depth_m)
    v, u = np.indices(depth.shape)
    k = frame.intrinsics
    safe_depth = np.where(valid, depth, 0.0)
    optical = np.stack(
        ((u - k[0, 2]) * safe_depth / k[0, 0], (v - k[1, 2]) * safe_depth / k[1, 1], safe_depth),
        axis=-1,
    )
    points = optical @ frame.world_from_camera[:3, :3].T + frame.world_from_camera[:3, 3]
    return points, valid


def _cloud_pixel_indices(valid: np.ndarray, masks: list[np.ndarray], limit: int) -> np.ndarray:
    """Keep small detected surfaces and scene context using measured pixels only.

    Half the budget is shared by accepted detection masks. The remainder covers
    all other valid pixels. Indices are unique and select both XYZ and RGB, so
    changing sampling density never separates color from its depth measurement.
    """
    available = valid.ravel().copy()
    all_indices = np.flatnonzero(available)
    if len(all_indices) <= limit:
        return all_indices
    selected = []
    quota = limit // (2 * len(masks)) if masks else 0
    if quota:
        for mask in masks:
            candidates = np.flatnonzero(available & mask.ravel())
            chosen = candidates[
                np.linspace(0, len(candidates) - 1, min(quota, len(candidates)), dtype=int)
            ]
            selected.extend(chosen)
            available[chosen] = False
    remaining = np.flatnonzero(available)
    count = min(limit - len(selected), len(remaining))
    selected.extend(remaining[np.linspace(0, len(remaining) - 1, count, dtype=int)])
    return np.sort(np.asarray(selected, dtype=int))


class RgbdPerception:
    def __init__(
        self,
        detector: Callable[[RgbdFrame], list[PixelDetection]],
        *,
        min_pixels: int = 12,
        max_points: int = 2048,
    ):
        if not callable(detector) or min_pixels < 1 or not 1 <= max_points <= 4096:
            raise ValueError("detector and bounded perception limits are required")
        self.detector = detector
        self.min_pixels = min_pixels
        self.max_points = max_points

    def reconstruct(self, frame: RgbdFrame) -> Reconstruction:
        # Age *is* checked here, and the asymmetry with `deproject` is deliberate.
        #
        # `deproject` is structure: it turns depth into points, and a caller that has
        # already accepted a frame at acquisition should not have its own runtime
        # re-litigated by a second age test. `reconstruct` is a **certificate** - the
        # entities it returns are what a placement or a grasp is proved against - and
        # a certificate issued from a frame that is already old is exactly how a
        # frozen capture ends up proving a placement that never happened. The two
        # callers want different answers, so the policy lives at the two boundaries
        # rather than in the shared helper.
        validate_frame(frame)
        points, valid = deproject(frame)
        entities = []
        masks = []
        for detection in self.detector(frame):
            if detection.mask.shape != valid.shape or detection.mask.dtype != np.bool_:
                raise ValueError("detector must return a boolean mask aligned to RGB-D")
            selected = points[detection.mask & valid]
            if len(selected) < self.min_pixels:
                continue
            masks.append(detection.mask)
            center = np.median(selected, axis=0)
            entities.append(
                Entity(
                    entity_id=detection.entity_id,
                    category=detection.category,
                    attributes=detection.attributes,
                    pose=[*center.tolist(), 1.0, 0.0, 0.0, 0.0],
                    confidence=detection.confidence,
                )
            )
        indices = _cloud_pixel_indices(valid, masks, self.max_points)
        cloud = points.reshape(-1, 3)[indices]
        colors = frame.rgb.reshape(-1, 3)[indices]
        return Reconstruction(
            schema_version="scene.reconstruction.v1",
            robot_id=frame.robot_id,
            observation_id=f"{frame.source_id}-{frame.sequence}-{frame.captured_at_unix_ms}",
            source_id=frame.source_id,
            source_type="rgbd_camera",
            source_frame_id=frame.frame_id,
            frame_id="world",
            transform_revision=frame.transform_revision,
            observed_at_unix_ms=frame.captured_at_unix_ms,
            sequence=frame.sequence,
            units="m",
            entities=entities,
            points=cloud.tolist(),
            point_colors=colors.tolist(),
        )
