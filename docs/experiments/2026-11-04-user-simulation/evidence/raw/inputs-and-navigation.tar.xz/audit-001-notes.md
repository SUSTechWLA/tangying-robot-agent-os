# 首轮失败记录（不可作为成功样本）

任务 `task-3b03351306d5b7df4835f7be6e69d577`，revision 1。原始输入：

> 先检查标定，再依次到厨房、卧室、卫生间巡检，每到一处都确认到位，最后返回客厅并确认任务完成。

UI 批准记录为 `2026-11-04T05:05:44.282795Z`；终态 `RECOVERABLE_FAILURE` 为 `05:05:50.598953Z`；`LOCAL_RUN_FINISHED` 为 `05:05:50.674668Z`。首站导航返回 `NAV2_ACTION_ENDED`，未取得任何房间的导航和独立到位确认，四站巡检没有完成。

审计原始记录在 `audit-001/`。64 条事件、3 个捕获身份均与 API/SQLite 一致；两次 API 快照稳定；执行终态与明确收尾匹配。Trace 为 `incomplete`：三个原子步骤的工具效果 `mutatesWorld` 未声明，另有父 `robot.task` 的显式结果未知标记。故 `recordAuditPassed=false` 和 `acceptancePassed=false`。成功读取执行历史的运维动作只证明诊断已执行，不证明导航故障修复或巡检完成。

捕获核查：`grounded` 快照 SHA-256 有效且声明 RGB/深度字节均为 0；两个执行捕获 (`observe_scene`、`navigation.pre_position`) 的快照、RGB 和深度 SHA-256 全部有效。初版采集器的 `allCaptureHashesValid=false` 包含“未声明图片”，不能解释为字节损坏。后续采集器将“无图片”独立记为 `null`，仍要求巡检确认记录具备完整 RGB-D 证据。原始 audit-001 未重写；对应采集代码保存于 `tools/collect_task_audit-001.py`，其 SHA-256 与该批 manifest 中 collectorSHA256 完全一致。

6 个唯一模型调用均有有效供应商 usage：输入 70,451，输出 4,695，总计 75,146 tokens；其中缓存输入 40,576，属于输入总量的子集。一次返回为 `invalid_decision` 也计入实际消耗。以上为供应商报告，非账单；没有把输出上限当成消耗。

独立 ROS 订阅采样 `ros-observations-001.jsonl` 首样本 `1793768751724` 毫秒，晚于本任务终态约 1.125 秒。本采样无法测量本任务执行中的路径长度、速度峰值或运动过程，不能把缺失覆盖解释为零运动、无碰撞或零路径。后续任务可继续使用该只读采样器，但应按任务实际批准和终态时间切片并报告边界缺口。
