# 第二轮失败记录

任务 `task-a0fc09863e3a4be4f14ef61945b72877`，revision 1，使用与第一轮相同原始自然语言和四站次序，world 未重置。预执行来源为 `preflight-telemetry-002.json`，批准前冻结计划为 `pre-approval-task-002.json`。前三站中文别名规范化后严格等于 kitchen → bedroom → bathroom → living_room；没有放宽次序或到位判据。

本轮终态仍为 `RECOVERABLE_FAILURE`，首导航返回 `NAVIGATION_OBSERVATION_LOST`，0/8 个导航/独立到位确认。`audit-002` 保存失败原始响应与当时采集器，原始文件不因后续对账、取消或修复重写。

记录检查结果：64 条任务事件 API/SQLite 一致；前后 API 快照稳定；原始请求 SHA-256 有效；明确失败终态与 LOCAL_RUN_FINISHED 一致；标定读取已确认；3 个捕获已声明内容的哈希全部有效，其中 2 个完整 RGB-D，grounded 快照无声明图像。Trace 已没有 STEP_EFFECT_UNKNOWN；仍保留父 robot.task 的真实 STEP_OUTCOME_UNKNOWN。因此 recordAuditPassed 和 acceptancePassed 均为 false。新 trace 对账来源可用，当前任务对账列表为空。

新增底层诊断在事件 42 中保留：rtabmap 输入年龄 2124 ms，base/head 为 600 ms，odometry/mapPose 为 37 ms；localizationState=UNAVAILABLE，mode=unknown；阻塞项包括 LOCALIZATION_UNAVAILABLE、RTABMAP_MODE_UNAVAILABLE，以及 Nav2 controller/planner/bt_navigator INACTIVE。此处是失败发生时的记录，不将后续设备恢复等同于本任务已完成。

独立 ROS 采样冻结在 `odom-window-002.jsonl`，来源字节前缀和摘要在 `odom-window-002-source.json`，分析在 `odom-audit-002.json`。批准到明确收尾约 39.559 秒，76 个有效不同里程计样本，覆盖首尾且最大消息间隔 0.648 秒；采样平面折线距离 3.4943 m，最大报告线速度 0.200 m/s。机器人确实移动，当前停止位置约 (0.249, 2.229)，不能将本轮失败说成零运动。上述为里程计采样估计，不是连续轨迹真值或无碰撞证明。

供后续操作判断的 `stationary-window-002.jsonl` / `stationary-window-002-summary.json` 记录 UTC 05:32:54.766–05:33:04.555，9.789 秒、20 个不同传感器时间样本；该窗口报告的线角速度和位姿变化均为零，最大采样间隔 0.544 秒、最大消息年龄 78 ms。它只描述失败后的当前采样窗口，不抹除历史运动或未知物理结果，也不构成自动对账/重放许可。

7 个唯一模型调用都有有效供应商 usage：输入 85,653、输出 5,352、总计 91,005 tokens，其中缓存输入 47,744 属于输入子集。未知未当作零；这些数字不是账单。
