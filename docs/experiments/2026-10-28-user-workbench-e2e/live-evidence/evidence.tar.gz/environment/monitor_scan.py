"""Read-only bounded scan monitor; records live provider responses, with grid snapshots every 30s."""
from pathlib import Path
import json,time,urllib.request,grpc
from google.protobuf.json_format import MessageToDict
from tangying_robot_proto.robot.v1 import robot_pb2,robot_pb2_grpc
root=Path(__file__).resolve().parent;out=root/'scan-2d595bdf6982';out.mkdir(exist_ok=False)
token=Path('artifacts/experiments/single-robot-robustness-20261015-gazebo-002/gazebo/navigation-token').read_text().strip()
start=time.monotonic();last_grid=-30.;sequence=0
with grpc.insecure_channel('127.0.0.1:50461') as channel,(out/'monitor.jsonl').open('w') as log:
 client=robot_pb2_grpc.RobotRuntimeStub(channel)
 while time.monotonic()-start<1200 and not (out/'stop').exists():
  row={'sequence':sequence,'capturedAtUnixMs':int(time.time()*1000)}
  for name in ['runtime.readiness','navigation.status','mapping.status']:
   try:
    value=MessageToDict(client.CallService(robot_pb2.ServiceRequest(robot_id='gazebo-home_furnished',name=name,request_id='scan-observer-'+str(sequence)+'-'+name),timeout=5))
    if name=='mapping.status':
     value['result']={k:v for k,v in value.get('result',{}).items() if k not in ['preview','trajectory']}
     value['projectionNote']='Only preview and trajectory arrays omitted; scan evidence, exploration, counters, state retained.'
    row[name]=value
   except Exception as e:row[name]={'error':type(e).__name__}
  grid=time.monotonic()-start-last_grid>=30
  try:
   request=urllib.request.Request('http://127.0.0.1:18941/v1/navigation/map'+('?includeGrid=1' if grid else ''),headers={'Authorization':'Bearer '+token})
   value=json.load(urllib.request.urlopen(request,timeout=5))
   if grid:
    name='grid-'+str(sequence).zfill(5)+'.json';(out/name).write_text(json.dumps(value));last_grid=time.monotonic()-start;row['gridFile']=name
   row['navigationHTTP']={k:v for k,v in value.items() if k!='cells'}
  except Exception as e:row['navigationHTTP']={'error':type(e).__name__}
  log.write(json.dumps(row,ensure_ascii=False)+'\n');log.flush();sequence+=1;time.sleep(2)
(out/'summary.json').write_text(json.dumps({'samples':sequence,'durationSeconds':time.monotonic()-start,'readOnly':True,'maxDurationSeconds':1200},indent=2));print(sequence)
