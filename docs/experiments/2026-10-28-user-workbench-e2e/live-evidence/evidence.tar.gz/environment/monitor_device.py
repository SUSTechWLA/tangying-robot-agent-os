"""Bounded read-only device monitor; interval and calls are part of evidence."""
from pathlib import Path
import json,time,grpc
from google.protobuf.json_format import MessageToDict
from tangying_robot_proto.robot.v1 import robot_pb2,robot_pb2_grpc
r=Path(__file__).resolve().parent; start=time.monotonic(); robot='gazebo-home_furnished'; count=0
with grpc.insecure_channel('127.0.0.1:50461') as c,(r/'device-monitor.jsonl').open('x') as out:
 s=robot_pb2_grpc.RobotRuntimeStub(c)
 while time.monotonic()-start<1200 and not (r/'monitor.stop').exists():
  at=time.monotonic(); row={'capturedAtUnixMs':int(time.time()*1000),'sequence':count,'services':{}}
  for name in ['runtime.readiness','navigation.status']:
   try:row['services'][name]=MessageToDict(s.CallService(robot_pb2.ServiceRequest(robot_id=robot,name=name,request_id=f'read-observer-{count}-{name}'),timeout=3))
   except grpc.RpcError as e:row['services'][name]={'rpcError':e.code().name,'details':e.details()}
  row['finishedAtUnixMs']=int(time.time()*1000);out.write(json.dumps(row,ensure_ascii=False)+'\n');out.flush();count+=1
  time.sleep(max(0,2-(time.monotonic()-at)))
(r/'device-monitor-summary.json').write_text(json.dumps({'samples':count,'elapsedSeconds':time.monotonic()-start,'intervalSeconds':2,'budgetSeconds':1200,'stoppedByFile':(r/'monitor.stop').exists(),'readOnlyServices':['runtime.readiness','navigation.status']},indent=2)+'\n')
print('Device monitor closed:',count,'samples')
