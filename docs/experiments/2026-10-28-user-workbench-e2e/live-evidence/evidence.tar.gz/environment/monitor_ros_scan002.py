"""Read-only 2Hz ROS sample monitor, bounded to 20 minutes; no publishers/actions."""
import json,time
from pathlib import Path
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from nav_msgs.msg import Odometry
from sensor_msgs.msg import JointState
from std_msgs.msg import String
rclpy.init();node=Node('e2e_scan002_passive_sensor_monitor');latest={};out=Path('/tmp/tangying-user-e2e-20261028-001');start=time.monotonic();seq=0

def save(kind,m):
 row={'receivedAtUnixMs':int(time.time()*1000)}
 if kind=='suction':row['value']=json.loads(m.data)
 elif kind=='odom':
  p=m.pose.pose;t=m.twist.twist;row.update(sensorStampNs=m.header.stamp.sec*10**9+m.header.stamp.nanosec,frameId=m.header.frame_id,position=[p.position.x,p.position.y,p.position.z],quaternion=[p.orientation.w,p.orientation.x,p.orientation.y,p.orientation.z],linearVelocity=[t.linear.x,t.linear.y,t.linear.z],angularVelocity=[t.angular.x,t.angular.y,t.angular.z])
 else:row.update(sensorStampNs=m.header.stamp.sec*10**9+m.header.stamp.nanosec,names=list(m.name),positions=list(m.position),velocities=list(m.velocity))
 latest[kind]=row
node.create_subscription(Odometry,'/odom',lambda m:save('odom',m),qos_profile_sensor_data)
node.create_subscription(JointState,'/joint_states',lambda m:save('joints',m),qos_profile_sensor_data)
node.create_subscription(String,'/tangying/suction/state',lambda m:save('suction',m),qos_profile_sensor_data)
with (out/'ros-scan002.jsonl').open('w') as f:
 last=-1.
 while time.monotonic()-start<1200 and not (out/'ros-scan002.stop').exists():
  rclpy.spin_once(node,timeout_sec=.05)
  now=time.monotonic()
  if now-last>=.5:
   f.write(json.dumps({'sequence':seq,'capturedAtUnixMs':int(time.time()*1000),**latest})+'\n');f.flush();last=now;seq+=1
node.destroy_node();rclpy.shutdown();(out/'ros-scan002-summary.json').write_text(json.dumps({'samples':seq,'durationSeconds':time.monotonic()-start,'readOnly':True},indent=2));print(seq)
