"""Subscribe only: physical stop and frame evidence, never publish or call actions."""
import json,time,math
from pathlib import Path
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from nav_msgs.msg import Odometry
from sensor_msgs.msg import JointState
from std_msgs.msg import String
from tf2_ros import Buffer,TransformListener
from rclpy.time import Time

rclpy.init();node=Node('user_e2e_readonly_stop_observer');rows=[];start=time.monotonic()
def record(kind,msg):
 base={'kind':kind,'receivedAtUnixMs':int(time.time()*1000),'receivedMonotonicNs':time.monotonic_ns()}
 if kind=='suction':
  base['state']=json.loads(msg.data)
 elif kind=='odom':
  pose=msg.pose.pose;twist=msg.twist.twist;base.update(sensorStampNs=msg.header.stamp.sec*10**9+msg.header.stamp.nanosec,frameId=msg.header.frame_id,position=[pose.position.x,pose.position.y,pose.position.z],quaternion=[pose.orientation.w,pose.orientation.x,pose.orientation.y,pose.orientation.z],linearVelocity=[twist.linear.x,twist.linear.y,twist.linear.z],angularVelocity=[twist.angular.x,twist.angular.y,twist.angular.z])
 else:base.update(sensorStampNs=msg.header.stamp.sec*10**9+msg.header.stamp.nanosec,names=list(msg.name),positions=list(msg.position),velocities=list(msg.velocity))
 rows.append(base)
node.create_subscription(Odometry,'/odom',lambda m:record('odom',m),qos_profile_sensor_data)
node.create_subscription(JointState,'/joint_states',lambda m:record('joints',m),qos_profile_sensor_data)
node.create_subscription(String,'/tangying/suction/state',lambda m:record('suction',m),qos_profile_sensor_data)
buf=Buffer();listener=TransformListener(buf,node)
while time.monotonic()-start<5.:rclpy.spin_once(node,timeout_sec=.05)
frames={}
for source in ['odom','base_link']:
 try:
  tf=buf.lookup_transform('map',source,Time());t=tf.transform.translation;q=tf.transform.rotation;frames[source]={'translation':[t.x,t.y,t.z],'quaternion':[q.w,q.x,q.y,q.z],'sensorStampNs':tf.header.stamp.sec*10**9+tf.header.stamp.nanosec}
 except Exception as e:frames[source]={'error':type(e).__name__}
node.destroy_node();rclpy.shutdown()
odom=[r for r in rows if r['kind']=='odom'];suction=[r for r in rows if r['kind']=='suction'];summary={'readOnly':True,'durationSeconds':time.monotonic()-start,'samples':{kind:sum(r['kind']==kind for r in rows) for kind in ['odom','joints','suction']},'transformsMapFrom':frames,'maxLinearSpeedMps':max((math.sqrt(sum(v*v for v in r['linearVelocity'])) for r in odom),default=None),'maxAngularSpeedRps':max((math.sqrt(sum(v*v for v in r['angularVelocity'])) for r in odom),default=None),'firstOdomReceivedAtUnixMs':odom[0]['receivedAtUnixMs'] if odom else None,'lastOdomReceivedAtUnixMs':odom[-1]['receivedAtUnixMs'] if odom else None,'lastSuction':suction[-1]['state'] if suction else None}
p=Path('/tmp/tangying-user-e2e-20261028-001/deployment004');(p/'final-stationary.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows));(p/'final-stationary-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
