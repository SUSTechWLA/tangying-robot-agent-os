"""Subscribe-only reconstruction of the current depth guard; no command publication."""
import json,time,math,os,xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np,rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from nav_msgs.msg import Odometry
from sensor_msgs.msg import PointCloud2,JointState
from sensor_msgs_py.point_cloud2 import read_points_numpy
from tangying_navigation.gazebo_runtime_node import camera_mount
from tangying_robot_gateway.gazebo_bridge import base_from_camera
from tangying_robot_gateway.gazebo_workflow import remove_chassis_returns,chassis_points
rclpy.init();n=Node('read_only_nav_envelope_inspector');clouds={};samples={};start=time.monotonic()
def cloud(name,m):
 points=read_points_numpy(m,field_names=('x','y','z'),skip_nans=True).reshape(-1,3);t=base_from_camera(np.eye(4),camera_mount(name));local=(t[:3,:3]@points.T).T+t[:3,3];clouds[name]=(local,{'frameId':m.header.frame_id,'stampNs':m.header.stamp.sec*10**9+m.header.stamp.nanosec,'receivedAtUnixMs':int(time.time()*1000)})
n.create_subscription(PointCloud2,'/camera/base/nav_points',lambda m:cloud('base-rgbd',m),qos_profile_sensor_data)
n.create_subscription(PointCloud2,'/camera/head/nav_points',lambda m:cloud('head-rgbd',m),qos_profile_sensor_data)
n.create_subscription(Odometry,'/odom',lambda m:samples.update(odom=m),qos_profile_sensor_data)
n.create_subscription(JointState,'/joint_states',lambda m:samples.update(joints=m),qos_profile_sensor_data)
while time.monotonic()-start<3.:rclpy.spin_once(n,timeout_sec=.05)
out=Path('/tmp/tangying-user-e2e-20261028-001/deployment004');report={'scope':'Fresh stationary cloud after cohort004 deployment; no movement requested; not the historical refusal frame.','capturedAtUnixMs':int(time.time()*1000),'cameras':{}};arrays={}
odom=samples['odom'].pose.pose;q=odom.orientation;yaw=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z));xy=np.array([odom.position.x,odom.position.y]);rot=np.array([[math.cos(yaw),-math.sin(yaw)],[math.sin(yaw),math.cos(yaw)]])
for name,(local,meta) in clouds.items():
 filtered=remove_chassis_returns(local);band=chassis_points(filtered,height_band=(.02,.40));inside=band[np.hypot(band[:,0],band[:,1])<=.355];arrays[name+'-raw-base-points']=local;arrays[name+'-guard-inside']=inside;nearest=inside[np.argsort(np.hypot(inside[:,0],inside[:,1]))[:16]]
 report['cameras'][name]={**meta,'rawCount':len(local),'postChassisMaskCount':len(filtered),'heightBandCount':len(band),'inside355mmCount':len(inside),'nearestBasePoints':nearest.tolist(),'nearestWorldPoints':np.column_stack(((rot@nearest[:,:2].T).T+xy,nearest[:,2]+odom.position.z)).tolist(),'minimumHorizontalDistanceM':float(np.hypot(band[:,0],band[:,1]).min()) if len(band) else None}
j=samples['joints'];report['jointPositions']=dict(zip(j.name,j.position));report['basePose']=[*xy,float(odom.position.z),q.w,q.x,q.y,q.z];models=[]
for model in ET.parse(os.environ['TANGYING_GAZEBO_WORLD']).getroot().findall('./world/model'):
 pose=[float(x) for x in (model.findtext('pose') or '0 0 0 0 0 0').split()]
 if math.hypot(pose[0]-xy[0],pose[1]-xy[1])<=2.:
  models.append({'name':model.get('name'),'pose':pose,'collisions':[{'name':c.get('name'),'pose':c.findtext('pose'),'boxSize':c.findtext('geometry/box/size'),'cylinderRadius':c.findtext('geometry/cylinder/radius'),'mesh':c.findtext('geometry/mesh/uri')} for c in model.findall('.//collision')]})
report['nearbySDFModels']=models;np.savez_compressed(out/'final-current-guard-clouds.npz',**arrays);(out/'final-current-guard.json').write_text(json.dumps(report,indent=2));print(json.dumps(report));n.destroy_node();rclpy.shutdown()
