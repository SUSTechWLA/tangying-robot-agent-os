from pathlib import Path
import hashlib,json,os,signal,subprocess,tarfile,time
out=Path('/tmp/tangying-user-e2e-20261028-001/deployment004');source=out/'source'
manifest=json.loads((out/'source-manifest.json').read_text())
roots={'robot/gateway/tangying_robot_gateway':Path('/opt/tangying-gateway/tangying_robot_gateway'),'robot/ros2_ws/src/tangying_navigation/tangying_navigation':Path('/opt/tangying-nav/install/tangying_navigation/lib/python3.12/site-packages/tangying_navigation')}
def target(name):
 for prefix,path in roots.items():
  if name.startswith(prefix+'/'):return path/name[len(prefix)+1:]
 raise ValueError('unexpected source path')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def alive(pid):
 p=Path(f'/proc/{pid}/stat');return p.exists() and p.read_text().split()[2]!='Z'
assert alive(27) and alive(15098),'world or RTABMap changed'
entry=Path('/usr/local/bin/tangying-navigation');entry_sha=sha(entry)
assert entry_sha=='c2711c239e25e9738b40d0c85668d9a25a308e22b89438c1d5494ada84a53466'
processes=[]
for role,pid in [('runtime',14219),('navigation',14220)]:
 assert alive(pid),role+' pid changed'
 env={k.decode():v.decode() for item in Path(f'/proc/{pid}/environ').read_bytes().split(b'\0') if item for k,v in [item.split(b'=',1)]}
 command=[p.decode() for p in Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0') if p]
 assert any('/tangying_navigation/' in arg for arg in command)
 processes.append((role,pid,env,command))
for name,entry in manifest.items():assert sha(source/name)==entry['sha256'],name
before={name:{'size':target(name).stat().st_size,'sha256':sha(target(name))} for name in manifest}
(out/'installed-before-manifest.json').write_text(json.dumps(before,indent=2))
with tarfile.open(out/'installed-before.tar.gz','w:gz') as tar:
 for name in manifest:tar.add(target(name),arcname=name)
for role,pid,env,command in processes:os.kill(pid,signal.SIGINT)
deadline=time.monotonic()+15
while any(alive(p[1]) for p in processes) and time.monotonic()<deadline:time.sleep(.1)
assert not any(alive(p[1]) for p in processes),'consumer did not stop; no file changed'
try:
 for name in manifest:
  dest=target(name);tmp=dest.with_name(dest.name+'.deployment004.tmp');tmp.write_bytes((source/name).read_bytes());os.chmod(tmp,dest.stat().st_mode&0o777);os.replace(tmp,dest)
 for package in roots.values():
  for p in package.rglob('*.pyc'):p.unlink()
 installed={name:{'size':target(name).stat().st_size,'sha256':sha(target(name))} for name in manifest}
 assert installed==manifest,'installed/source mismatch'
 (out/'installed-cohort-manifest.json').write_text(json.dumps(installed,indent=2))
 check="from tangying_robot_gateway.home_commissioning import HOME_OPERATIONAL_RADIUS_M; from tangying_robot_gateway import robot_workflow,survey,gazebo_backend,semantic_cloud_services; from tangying_navigation import navigation_node,gazebo_runtime_node; assert HOME_OPERATIONAL_RADIUS_M==.355; assert survey.EXPLORATION['minStepM']>0; print('coherent imports and commissioned radius verified')"
 result=subprocess.run(['/usr/bin/python3','-c',check],env=processes[0][2],capture_output=True,text=True,timeout=20)
 (out/'import-check.log').write_text(result.stdout+result.stderr);assert result.returncode==0,'import failed'
except BaseException:
 with tarfile.open(out/'installed-before.tar.gz') as tar:
  for member in tar.getmembers():target(member.name).write_bytes(tar.extractfile(member).read())
 for role,pid,env,command in processes:
  with (out/(role+'-rollback.log')).open('w') as log:subprocess.Popen(command,env=env,cwd='/opt/tangying-nav',stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 raise
record={'method':'Runtime and Navigation HTTP consumers stopped; full package files atomic-replaced, SHA-verified before restart','atomicDirectoryExchange':False,'sourceFiles':len(manifest),'entrypointSha256':entry_sha,'gazeboPid':27,'rtabmapPid':15098,'worldRestarted':False,'startedAtUnixMs':int(time.time()*1000),'processes':[]}
for role,pid,env,command in processes:
 with (out/(role+'-deployed.log')).open('w') as log:p=subprocess.Popen(command,env=env,cwd='/opt/tangying-nav',stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 record['processes'].append({'role':role,'oldPid':pid,'newPid':p.pid,'command':command})
assert sha(Path('/usr/local/bin/tangying-navigation'))==entry_sha
(out/'deployment.json').write_text(json.dumps(record,indent=2));print(json.dumps(record))
