from pathlib import Path
import os,subprocess,json
out=Path('/tmp/tangying-user-e2e-20261028-001/deployment004');root=out/'source'
env={k.decode():v.decode() for item in Path('/proc/14219/environ').read_bytes().split(b'\0') if item for k,v in [item.split(b'=',1)]}
env['PYTHONPATH']=f'{root}/robot/gateway:{root}/robot/ros2_ws/src/tangying_navigation:{root}:'+env.get('PYTHONPATH','')
env['ROS_DOMAIN_ID']='113';env.pop('TANGYING_HOME_COMMISSIONING',None)
tests=['robot/gateway/tests/test_operational_envelope.py','robot/gateway/tests/test_survey_continuation_bootstrap.py','robot/gateway/tests/test_semantic_cloud_services.py','robot/gateway/tests/test_robot_services.py','robot/gateway/tests/test_gazebo_workflow.py','robot/gateway/tests/test_survey.py','robot/gateway/tests/test_slam_semantics.py','tests/install/test_gazebo_runtime_freshness.py','robot/ros2_ws/src/tangying_navigation/test/test_navigation_node.py']
with (out/'pytest-staged.log').open('w') as log:
 result=subprocess.run(['/usr/bin/python3','-m','pytest',*tests,'-q'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
print(json.dumps({'exitCode':result.returncode,'testSource':'frozen coherent package','rosDomainId':113}));raise SystemExit(result.returncode)
