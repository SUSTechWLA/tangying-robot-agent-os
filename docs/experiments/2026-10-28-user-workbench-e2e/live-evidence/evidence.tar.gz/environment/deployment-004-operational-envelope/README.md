# Final coherent device deployment and read-only verification

This deployment does not complete the requested bedroom → bathroom → living-room task. The existing world remains at the scan002 protected stop beside `living_table`. No third scan, retreat, reset, reduced radius, or new physical task was dispatched during this deployment.

## Changes and limits

- `HOME_OPERATIONAL_RADIUS_M = 0.355` is shared by the commissioned home bounded-step disc guard and workflow planning/semantic admission. The previously planned 0.32 m radius could choose a place that the 0.355 m execution guard refused.
- Physical occupied-pose evidence remains 0.32 m. The existing Nav2 swept-path certificate remains at its original inscribed radius, 0.33 m. Neither is widened by changing the operational margin. `_observed_travel` retains valid narrow travel evidence but pads its grid for the larger operating envelope; unknown cells in that margin remain unknown.
- Saved semantic goals are re-certified at the current planning radius on map load. Both Gazebo `world_route` admission and semantic-cloud candidate/binding checks use that radius. Old map package bytes/revision and stored historical footprint metadata remain unchanged; an old `navigationReady` flag cannot authorize the new envelope.
- Nav2's own costmap footprint and controller geometry have **not** been unified with this bounded-step envelope. The change supplies no new escape controller. A larger margin does not certify stopping distance or correct the already-executed historical trajectory.
- The cohort also includes live Nav2 lifecycle readiness, conservative request-start freshness, discovery/service-future error handling, bounded first-frame continuation recovery, and late-provider-return deadline checks.

The next design step, not implemented here, is to commission endpoint/turning clearance using the operational envelope plus independently justified localization/grid error and stopping distance `v * latency + v² / (2 * deceleration)`. It must be versioned with the harness and map admission policy, not implemented by shrinking the execution guard.

## Deployment evidence

114 source files were frozen in `source-manifest.json` and `source-and-tests.tar.gz`. Both consumers stopped normally; all package source files were atomic-replaced, complete SHA identity was checked, imports verified, then the consumers restarted. This is a service-level coherent switch, not an atomic directory-exchange claim. `installed-before.tar.gz` preserves the preceding installation. Generated protocol stubs, container entrypoint, world, and RTABMap process were not replaced.

- Runtime: 14219 → **38930**.
- Navigation HTTP: 14220 → **38931**.
- Gazebo remains **27**; RTABMap remains **15098**.
- Entrypoint SHA256 remains `c2711c239e25e9738b40d0c85668d9a25a308e22b89438c1d5494ada84a53466`.
- This experiment began with the container running and leaves it running, with host LocalAgent/frontend available.
- Installed and frozen repository package manifests match exactly. No environment/credential values are serialized by the deployment scripts.

## Verification results

- Host targeted regression: **259 passed**, 3.97 s (`pytest-final.log`). This includes the new package/old-map/unknown-margin/backend-route/semantic-binding tests and the real bounded-step method returning `NAV_ENVELOPE` with zero nonzero pulses.
- Frozen coherent package inside ROS container, isolated domain 113: **264 passed**, 15.26 s (`pytest-staged.log`). Production home commissioning environment is removed only for the isolated generic-geometry test process.
- Ruff: passed (`ruff-final.log`).
- Intermediate failures are preserved. An early new map test compared serialized occupancy against its input representation; it now compares the loaded before/after grid and every immutable package hash. The container's older pytest treated the new bootstrap test helper named `setup` as an xunit hook: 246 tests passed and 18 setup errors. The helper alone was renamed to `bootstrap_fixture`, with unchanged production functions and assertions; final 264 tests pass. Original candidate manifests/archives and failed logs are retained.

## Final physical observations

`final-stationary.jsonl` records 5.244 seconds: 95 odometry, 95 joint-state, 65 suction messages; maximum base linear and angular speeds are zero. Suction is detached. Pose remains `[0.4324074238340021, -1.5948434062934234, 0.035, ...]`.

`final-current-guard.json` and its NPZ contain fresh post-deployment sensor observations, **not** the historical refusal cloud. The base camera has 5 points inside 0.355 m; minimum horizontal distance is 0.352189989659263 m. The head camera's closest height-filtered point is 0.48300487651124546 m. No same-envelope validated retreat exists: the swept-disc guard includes the initial circle, so the current overlap blocks nonzero motion in every direction. Arm recovery only stows/holds and does not retreat the base.

`final-navigation-http.json` shows fresh ACTIVE controller, planner, and BT navigator. This is driver health, not proof of a usable route. The Nav2 map has 40,186 known cells with bounds approximately x[-5.4061,5.4189], y[-3.4764,4.5736]; the reference bathroom center y=6.55 remains outside the observed map.

The immutable active map remains `scan-1ba72d23a2f7`, revision `8f89d0e9f6bedd3a384ec85e2313e2f62590aefc6004903e4660db739a09c338`. Reloading under 0.355 m now marks **bedroom, bathroom, and kitchen_work_area** as `SEMANTIC_GOAL_NOT_CLEAR`. Other room endpoint certifications do not prove complete paths. The command journal hash remains exactly the draft004-after hash; canonical command count did not increase during this maintenance.

The original corrupt RTABMap DB was preserved and a separate real-observation epoch was previously promoted to the default persistent DB path. That is not recovery of the old map or autonomous recovery. Task001 was explicitly abandoned/cancelled by the operator, scan001 failed from our earlier mixed-package deployment, and scan002 remained a real partial-scan failure. All those outcomes remain unchanged.
