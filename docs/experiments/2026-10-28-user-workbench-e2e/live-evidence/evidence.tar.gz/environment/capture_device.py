"""Read-only device capture; no skill execution or mutating service is allowed."""
from pathlib import Path
import argparse,datetime,hashlib,json,subprocess,time
import grpc
from google.protobuf.json_format import MessageToDict
from tangying_robot_proto.robot.v1 import robot_pb2,robot_pb2_grpc

p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('--task-id',default='');args=p.parse_args()
if not args.label or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for c in args.label):raise SystemExit('invalid label')
root=Path(__file__).resolve().parent;out=root/'captures'/args.label;out.mkdir(parents=True,exist_ok=False)
started=int(time.time()*1000); errors=[]; summary={'label':args.label,'taskId':args.task_id,'startedAtUnixMs':started,'readOnly':True,'services':{}}
def save(name,value):
 (out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
with grpc.insecure_channel('127.0.0.1:50461') as channel:
 client=robot_pb2_grpc.RobotRuntimeStub(channel)
 info=client.GetRuntimeInfo(robot_pb2.GetRuntimeInfoRequest(),timeout=5);save('runtime-info.json',MessageToDict(info));robot=info.robot_id
 catalog=client.ListServices(robot_pb2.GetRuntimeInfoRequest(),timeout=5);save('service-catalog.json',MessageToDict(catalog))
 allowed={s.name for s in catalog.services if s.available and not s.mutates_world}
 for name in ['calibration.get','mapping.status','runtime.readiness','navigation.status','semantic.locations']:
  if name not in allowed:errors.append(name+': not declared read-only');continue
  try:
   response=MessageToDict(client.CallService(robot_pb2.ServiceRequest(robot_id=robot,name=name,request_id='read-'+args.label+'-'+name),timeout=10));save(name+'.json',response);result=response.get('result',{})
   summary['services'][name]={k:result[k] for k in ['ready','state','blockers','mapId','mapRevision','revision','activeMap'] if k in result}
  except grpc.RpcError as e:errors.append(name+': '+e.code().name)
 for source in ['base-rgbd','head-rgbd']:
  stream=client.Observe(robot_pb2.ObserveRequest(streams=['robot_state','reconstruction','rgbd_raw'],source_id=robot+'/'+source,max_rate_hz=1),timeout=10)
  try:
   message=next(stream);(out/(source+'.pb')).write_bytes(message.SerializeToString())
   record=MessageToDict(message);save(source+'.json',record)
   summary[source]={'observationId':message.observation_id,'wallTimeUnixMs':message.wall_time_unix_ms,'monotonicTimeNs':message.monotonic_time_ns,'bytes':message.ByteSize()}
  except (grpc.RpcError,StopIteration) as e:errors.append(source+': '+str(e))
  finally:stream.cancel()
container='tangying-gazebo-4d6962a6c3d7-gazebo-house-1'
start=json.loads((root/'before.json').read_text())['capturedAtUnixMs']//1000
logs=subprocess.run(['docker','logs','--since',str(start),container],capture_output=True,text=True,timeout=15)
text=logs.stdout+logs.stderr
# Known navigation credential is read only for exact redaction; never serialized.
secret=Path('artifacts/experiments/single-robot-robustness-20261015-gazebo-002/gazebo/navigation-token').read_text().strip()
count=text.count(secret) if secret else 0
if secret:text=text.replace(secret,'[REDACTED_NAVIGATION_TOKEN]')
(out/'device.log').write_text(text)
terms=('error','warn','safety','blocked','stop','reject','stale','invalid','cancel','fail','timeout')
(out/'safety-filter.log').write_text('\n'.join(x for x in text.splitlines() if any(w in x.lower() for w in terms))+'\n')
summary.update(endedAtUnixMs=int(time.time()*1000),errors=errors,knownCredentialRedactions=count)
save('summary.json',summary)
save('manifest.json',{str(f.relative_to(out)):{'size':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in out.iterdir() if f.is_file()})
print(json.dumps(summary,ensure_ascii=False))
