# scan002 continuation bootstrap defect — 2026-10-29

This is an offline source/evidence audit and deterministic fixture validation. No ROS process, Gazebo command, Docker action, controller dispatch, real robot or LLM request was started here. The original failed scan is not converted into a successful run.

## Confirmed cause and limits

Read-only inputs are the original `artifacts/acceptance/user-e2e-20261028-001/mapping-002/final.json`, `progress.jsonl`, and `environment/scan002-bounded-step-events.jsonl`; SHA-256 values are in `source-before.json`. They were hash-checked again after testing and left unchanged.

Operation `1ba72d23a2f74a679aec11285775f2d4` reached 40 accepted frames and 0.5656837554385995 m of measured SLAM odometry travel in leg 1. Its actual final stop reason was `no_reachable_frontier`, with 712 remaining nonblind frontier cells, one refused approach, one route failure since progress and one visited viewpoint. The 37 retained bounded-step events contain 36 `STEP_COMPLETE` and one final `NAV_ENVELOPE`; the final event says its zero command was published. This establishes a safety-refusal / unreachable-frontier stop, not a frame cap, whole-scene coverage, or proof of physically measured braking. No safety threshold was relaxed.

`_open_leg` resets consecutive depth rejection to zero and calls `_sample` once. The saved leg-2 result has zero frames and `consecutiveInsufficientDepth=1`: the sole new-session sample therefore hit `InsufficientDepthError`. The continuation then skips its initial sweep; `_live_grid` returns None before consulting the inherited grid, and the runner immediately returns `no_frames`. A duplicate sensor stamp alone does not explain this saved counter. The new provider has no previous accepted timestamp; a repeated timestamp against the previous provider is not the confirmed cause.

`reproduce.py` loads the preserved old workflow and survey source and drives synthetic, valid protobuf RGB-D observations through the real DenseSlamProvider. With an unusable exposure followed by a usable one, old code reads once and ends `no_frames`; changed code reads twice and admits one actual frame. `before-after.json` records both. It makes no claim that the real scene's next exposure is usable.

## Change

- `_open_leg` waits for a first registered frame, bounded by 8 seconds of acquisition waiting and at most three distinct exposure attempts. Individual provider capture/add calls remain governed by their existing provider contract; this is not a hard interrupt of a blocking provider call.
- Per-read observation IDs cannot inflate depth loss: source ID + source sensor stamp identifies an exposure; older adapters without a source stamp use source ID + actual capture wall timestamp. Duplicate reads count separately and do not reset or increment the depth-loss streak. Neither capture timestamps nor depth values are changed.
- After bounded stationary attempts, a continuation without a measured grid may spend exactly one of its existing `maxLooksPerLeg` budget on the ordinary controller-guarded look-around. Already-initialized continuations do not repeat their initial sweep. Persistent missing depth, cancellation, lease expiry, stale capture, changed calibration, frame/travel/time budgets and spatial refusal remain fail-closed. The existing 120-second look budget, command limits and <=0.5 rad steps are unchanged.
- `scanEvidence.bootstraps` retains at most six leg records with attempts, duplicate count, status, accepted frame delta and elapsed seconds. `exploration.continuationScanAttempted/Status` records the separate recovery look. An inherited map is never treated as a fresh measurement.

## Verification

The exact commands and outcomes are in `commands.json`; 189 focused tests passed, including 17 new regression cases, in 1.65 s. Ruff passed. Tests use in-process fixtures only and include the real DenseSlamProvider depth gate. The first development run's five failures (protobuf Struct access plus a future-stamped fixture) are retained in `bootstrap-tests.*`; the corrected final result is `regressions-01.*`.

Changed files and hashes are in `source-final.json`, and the bounded change patch is `changes.patch`. `source-before/` preserves only the relevant old source. A complete package deployment and a newly identified physical simulation run are still required before claiming that the real continuation recovers or that exploration reaches the remaining rooms. Commissioned room names do not establish measured free space or map coverage.
