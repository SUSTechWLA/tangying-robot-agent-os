"""Read saved source copies; deterministic in-process capture fixtures only."""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import MethodType

ROOT = Path('/Users/wanglian/Projects/tangying-robot-agent-os')
sys.path[:0] = [str(ROOT/'robot/gateway'), str(ROOT/'python'), str(ROOT)]
import pytest
from tangying_robot_gateway import robot_workflow as current
from robot.gateway.tests.test_survey_continuation_bootstrap import setup, exposure
from robot.gateway.tests.test_survey import FakeDriver, FakeReport

BASE = Path('/tmp/scan002-bootstrap-fix')
def load(name, relative):
    spec = importlib.util.spec_from_file_location(name, BASE/'source-before'/relative)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module
old = load('tangying_robot_gateway._scan002_workflow_before',
           'robot/gateway/tangying_robot_gateway/robot_workflow.py')
old_survey = load('tangying_robot_gateway._scan002_survey_before',
                  'robot/gateway/tangying_robot_gateway/survey.py')
report = {'scope': 'in-process synthetic RGB-D regression; no robot/ROS/Gazebo/LLM', 'runs': []}
for version in ('before', 'after'):
    with tempfile.TemporaryDirectory() as directory, pytest.MonkeyPatch.context() as patch:
        workflow, owner, calls, clock = setup(Path(directory), patch,
            [exposure(1, depth=False), exposure(2)])
        if version == 'before':
            patch.setattr(old, 'time', current.time)
            workflow._open_leg = MethodType(old.RobotWorkflow._open_leg, workflow)
            workflow._sample = MethodType(old.RobotWorkflow._sample, workflow)
        workflow._open_leg(2)
        item = {'version': version, 'captureCalls': len(calls),
                'frameCount': workflow.slam.frame_count,
                'consecutiveInsufficientDepth': workflow._depth_starved,
                'depthRejectedFrames': workflow._depth_rejected,
                'operationId': workflow.operation_id,
                'noPhysicalCommands': True}
        if version == 'before':
            # Old continuation exits before any driver call because live_grid has
            # no frame. Use the production workflow measurement adapter directly.
            driver = FakeDriver()
            result = old_survey.SurveyRunner(clock=clock.monotonic).run_leg(
                workflow._survey_map(), driver, FakeReport(), remaining_m=8., number=2)
            item.update(stopReason=result.exploration['stopReason'],
                        complete=result.complete, looks=driver.looks, steps=driver.steps)
            assert item['frameCount'] == 0 and item['stopReason'] == 'no_frames'
            assert item['captureCalls'] == 1 and item['consecutiveInsufficientDepth'] == 1
        else:
            item['bootstrap'] = workflow._scan_evidence['bootstraps'][-1]
            assert item['frameCount'] == 1 and item['captureCalls'] == 2
            assert item['consecutiveInsufficientDepth'] == 0
        workflow._release_session()
        assert owner[0] is None
        report['runs'].append(item)
print(json.dumps(report, ensure_ascii=False, indent=2))
