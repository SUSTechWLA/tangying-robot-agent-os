# task001 独立指标与完整收尾审计

任务：`task-e133310fd2f0b570d65e4dce`。用户请求为“先到卧室看看，再检查卫生间，结束后请回到客厅。每到一处都确认到位。”任务实际为 **RECOVERABLE_FAILURE / PHYSICAL_OUTCOME_UNKNOWN**，不是成功案例，也不是纯LLM失败。没有执行重试、resume或reconcile。

## 任务与收尾

- API与SQLite在线一致备份均为45条事件，task state/revision/plan及全部事件逐项相符。备份包含WAL已提交内容；没有对活库做checkpoint或写入。
- 两份历史观测的task/robot/revision/source身份与数据库一致。唯一子步骤 `observe_scene` 的确认回执匹配命令发送后的RGB-D采样。没有足够证据说明已到达卧室、卫生间或客厅。
- `navigation.pre_position` 在数据库仍是 `STARTED`，无对账结论；`observe_scene` 是 `COMPLETED`。Recovery API明确 `requiresReconciliation=true`、`canResume=false`；UNKNOWN的限制保持有效。
- 旧运行没有显式 `LOCAL_RUN_FINISHED`。应记录为 `legacy_no_explicit_finish`、`closureVerified=false`，而不是说它违反了一个旧代码从未定义的 `LOCAL_RUN_FAILED` 合同。失败及历史证据本身仍完整保留。
- 4次运维动作是3次`execution.read-history`和1次`observe.re-read`。后续`ops.anomaly_cleared`不是任务成功，也不解除物理结果对账要求。

## 分母必须分开

|指标|分子/分母|含义|
|---|---:|---|
|本次用户任务成功|0/1|任务未完成，待人工/独立证据对账|
|模型决策被拒绝|1/4|首轮一次返回不满足“单轮恰好一个工具”|
|记录的HTTP非2xx|0/4|4个唯一model-call记录均HTTP 200|
|有效供应商usage覆盖|4/4|包含那次invalid_decision，不能删去其用量|
|只读查询成功|2/2|semantic.locations、navigation.status|
|批准前最终计划生成|1/1|第四轮冻结2个capability调用；计划生成不代表任务完成|

`metrics-after.json` 的 totalTasks=1、failedTasks=1、succeededTasks=0、endToEndSuccessRate=0 与任务结果一致。`metrics-before`已包含READY草案，因此前后totalTasks差为0，不应拿差值作为任务分母。`orchestrationScore=15`不能称为物理任务质量；`llmRejectionCount=0`与trace的1次MODEL_DECISION_REJECTED口径不同，未经生产指标定义审计不能把前者直接解释为“模型从未被拒绝”。建议面板拆出HTTP失败、决策拒绝、提案拒绝和任务失败，而不是用一个失败率覆盖它们。

## LLM用量

|轮次|HTTP|决策结果|输入tokens|输出tokens|总tokens|供应商cached输入tokens|记录时长ms|
|---|---:|---|---:|---:|---:|---:|---:|
|1|200|invalid_decision|9961|205|10166|0|1560|
|2|200|accepted|10168|360|10528|6784|3040|
|3|200|accepted|12808|284|13092|6784|2632|
|4|200|accepted|13198|654|13852|6784|4415|

合计：**输入46,135 + 输出1,503 = 47,638 tokens**。供应商reported cached输入为20,352，占输入44.114%，它已包含在46,135输入tokens中，不能再加到总量。每条`usage_status=valid`，本报告采用供应商返回并由本地账本记录的usage，**没有使用字符数估算tokens**；这仍不是供应商账单或独立抓包认证。

每次 `output_tokens=4096` 是输出上限，不是实耗；4次上限之和16,384不能作为输出tokens。`compaction.input_bytes`是上下文字节，不是token计数；wire request总字节数与context字节口径也不同。4份保留wire request逐项与request_bytes和model_request_sha256匹配。

虽然本地`cache_mode=off`，供应商仍报告cached_tokens。它说明供应商侧隐式缓存统计存在，不证明本地缓存开关带来20,352 tokens节省，更不证明KV缓存跨机器人共享或既有事实可复用。没有TTFT、对照组、缓存关闭基线和账单价，不能据此推导延迟收益或费用金额。

规划为4轮，恰好对应4个唯一model_call记录。校验器按call_id去重，不把draft/final/事件上下文里的重复引用重复计费；它不假设一般情况下“规划一轮等于一次HTTP请求”。统计的是可见客户端请求记录与响应，不声称拥有网络级重试全量抓包。

## 时延口径

- 4次模型记录时长之和11,647ms，第一请求开始至最后响应结束跨度约11,685.783ms。
- task.createdAt在模型规划之后；不能用task.createdAt开始计时来测完整规划延迟。
- approval至RECOVERABLE_FAILURE transition为181,599.072ms。task.updatedAt随后还包含运维事件，不能直接视为失败发生时间或物理收尾结束时间。
- observe_scene总耗时651.737ms，navigation.pre_position总耗时180,179.023ms，其中执行部分180,159.926ms。它主要是导航可用性等待/超时链路，不能归因于LLM慢。
- 每个capability只有1个样本，p50/p95/p99都等于该样本不是统计可靠性证明。分阶段总和与总时长仅差0.001–0.002ms的舍入/未归因微量，不构成重复计时证据。
- user-actions.jsonl没有HTTP请求起止时间，动作记录时刻晚于服务端创建/审批；不据此虚构点击响应延迟。

## 可复用只读收集器

路径：`artifacts/acceptance/user-e2e-20261028-001/tools/collect_task_closure.py`。

```sh
python3 artifacts/acceptance/user-e2e-20261028-001/tools/collect_task_closure.py   --task-id TASK_ID   --task-dir artifacts/acceptance/user-e2e-20261028-001/task-002   --journal artifacts/acceptance/user-e2e-20261028-001/local-agent/agent.db   --output artifacts/acceptance/user-e2e-20261028-001/task-002-closure   --wait-seconds 600
```

新合同要求：终态 + 最新终态transition之后、state/revision匹配的LOCAL_RUN_FINISHED；成功还需LOCAL_RUN_SUCCEEDED。然后通过GET前后快照、在线SQLite backup、完整事件/plan、robot/revision/call/观测身份比对。稳定两次轮询仅作为备份期间一致性辅助，不能替代显式完成标记。

退出0表示“收尾证据验证通过”，**不等于任务成功**（失败任务也可完整收尾）；退出2表示收尾尚未证实。结果中的taskSucceeded必须单独查看。它只发GET，不读取console-session、环境、配置或密钥文件；不调用approve、resume、retry、reconcile。全部新证据写入拒绝覆盖的新目录。

14个正负测试已通过，覆盖旧任务缺marker、错误state/revision、非终态finish、前次run遗留marker、缺成功标记、同call重复引用、冲突call、非法usage、跨robot观测以及真实task001的在线备份比对。调用记录/原始API与数据库证据在本目录；数据库含任务与视觉记录，应按项目实验数据管理，不能据此称为已经匿名化的公开论文材料。

本审计读取范围限本次artifacts与127.0.0.1:8897 GET。没有读取/复制密钥，没有改变其他agent负责的生产代码，也没有把UNKNOWN重新执行。当前task001属于旧二进制base79a8c3553；后续新收尾marker的实现及新任务应单独登记源码和数据，不能覆盖此次失败。
