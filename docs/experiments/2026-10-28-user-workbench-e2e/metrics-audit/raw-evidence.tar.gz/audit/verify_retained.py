"""Offline verification only. Does not launch ROS, Gazebo, Docker, agents or models."""
from pathlib import Path
import hashlib,json,math,sys,tarfile
ROOT=Path('/Users/wanglian/Projects/tangying-robot-agent-os')
BASE=Path('/tmp/user-e2e-metrics-20261028')
sys.path.insert(0,str(ROOT))
from scripts.analyze_gazebo_field_campaign import analyze
from scripts.run_gazebo_stop_checks import measured_stop
phase=BASE/sys.argv[1];phase.mkdir(exist_ok=False)
files=['scripts/analyze_gazebo_field_campaign.py','scripts/run_gazebo_stop_checks.py','tests/scripts/test_analyze_gazebo_field_campaign.py','tests/scripts/test_gazebo_stop_checks.py']
before={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files}
evidence=BASE/'archive/evidence';field=evidence/'run-002'
metrics=analyze(field/'campaign-001',field/'hub',phase/'campaign',field/'world.sdf')
old=json.loads((field/'analysis/metrics.json').read_text())
unchanged={key:metrics[key]==old[key] for key in ['taskCount','successCount','navigationCommands','independentArrivalChecks','minimumMeasuredBoundingSphereGapM','measuredPathLengthM','maximumMeasuredSpeedMps','simulationDurationS','physicsCaptures','safetyMetricsPassed']}
assert all(unchanged.values())
stop=evidence/'run-003-stops/stops-001';summary=json.loads((stop/'summary.json').read_text());samples=[json.loads(s) for s in (stop/'samples.jsonl').read_text().splitlines()]
rechecked=[]
for trial in summary['trials']:
 rows=[s['state'] for s in samples if s['robotId']==trial['robotId'] and s['mode']==trial['mode'] and s['phase']=='deceleration']
 result=measured_stop(rows,trial['triggerState'])
 passed=result['measuredStopped'] and any(s.get('stopReason')==trial['expectedControllerReason'] for s in rows) and result['maximumDisplacementMeters']<=trial['criterion']['maxDisplacementMeters'] and result['elapsedSimulationSeconds']<=4
 assert passed and trial['passed']
 for key in ['maximumDisplacementMeters','travelDistanceMeters','elapsedSimulationSeconds','lastSpeedMetersPerSecond','sampleCount']:
  assert math.isclose(result[key],trial[key])
 rechecked.append({'robotId':trial['robotId'],'mode':trial['mode'],'passed':passed,'metrics':result})
# Check all originally archived bytes still match, including read-only SQLite.
public=ROOT/'docs/experiments/2026-10-28-edge-task-validation/gazebo/public'
manifest=json.loads((public/'manifest.json').read_text())
assert hashlib.sha256((public/'evidence.tar.gz').read_bytes()).hexdigest()==manifest['archive']['sha256']
for record in manifest['publicMembers']:
 raw=(BASE/'archive'/record['path']).read_bytes()
 assert len(raw)==record['size'] and hashlib.sha256(raw).hexdigest()==record['sha256'],record['path']
after={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files}
assert before==after
report={'command':['python3',str(Path(__file__)),sys.argv[1]],'reportedBaselineCommit':'79a8c3553','sourceSHA256':before,'sourceStable':True,'archiveSHA256':manifest['archive']['sha256'],'unchangedOriginalMembers':len(manifest['publicMembers']),'originalMetricValuesUnchanged':unchanged,'taskCount':metrics['taskCount'],'successCount':metrics['successCount'],'plannedTaskCount':metrics['plannedTaskCount'],'taskJournalsVerified':metrics['taskJournalsVerified'],'endToEndClosureVerified':metrics['endToEndClosureVerified'],'safetyMetricsPassed':metrics['safetyMetricsPassed'],'stops':rechecked,'scope':'offline retained-data reanalysis only; no new physical/model run'}
(phase/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['sourceSHA256','stops']},indent=2))
