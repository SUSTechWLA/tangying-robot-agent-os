from pathlib import Path
import sys,json,runpy,copy,math,hashlib,sqlite3
ROOT=Path('/Users/wanglian/Projects/tangying-robot-agent-os');sys.path.insert(0,str(ROOT))
from scripts.analyze_gazebo_field_campaign import analyze
from scripts.run_gazebo_stop_checks import measured_stop
base=Path('/tmp/user-e2e-metrics-20261028');out=base/'negative-before';out.mkdir(exist_ok=False)
fixture=runpy.run_path(str(ROOT/'tests/scripts/test_analyze_gazebo_field_campaign.py'))['evidence']
results=[]
for mutation in ['wrong_robot_clock_world','nonfinite_global_clock','missing_final_execution_events','contradictory_sqlite_terminal','unfinished_declared_trial','nonterminal_result','missing_roster_state']:
 path=out/mutation;campaign,hub,summary,events=fixture(path)
 rows=[json.loads(s) for s in (hub/'physics.jsonl').read_text().splitlines()]
 if mutation=='wrong_robot_clock_world':
  for row in rows:
   for state in row['states'].values():state.update(robotId='foreign-robot',clockDomain='wall',frameId='foreign-frame',worldId='foreign-world')
 elif mutation=='nonfinite_global_clock': rows[-1]['simulationTime']=float('nan')
 elif mutation=='missing_final_execution_events':
  p=campaign/'ground-a/final-3.json'; f=json.loads(p.read_text());f['events']=[{'type':'TASK_APPROVED'}];p.write_text(json.dumps(f))
 elif mutation=='contradictory_sqlite_terminal':
  db=campaign/'ground-a/local-agent/agent.db';db.parent.mkdir();c=sqlite3.connect(db);c.execute('create table tasks(id text,state text)');c.execute('insert into tasks values(?,?)',('task-1','FAILED'));c.commit();c.close()
 elif mutation=='unfinished_declared_trial':summary.update(success=False,seeds=[3,7])
 elif mutation=='nonterminal_result':
  summary['success']=False;summary['trials'][0]['tasks']['ground-a']['state']='EXECUTING'
  p=campaign/'ground-a/final-3.json';f=json.loads(p.read_text());f['state']='EXECUTING';p.write_text(json.dumps(f))
 else:
  extra=copy.deepcopy(rows[-1]);extra.update(sequence=3,capturedAtUnixMs=1150,simulationTime=1.2,contactCounts={'ground-a':3});del extra['states']['ground-a'];rows.append(extra)
 (campaign/'summary.json').write_text(json.dumps(summary));(hub/'physics.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
 world=path/'world.sdf';world.write_text('<sdf version="1.9"><world name="audit">'+''.join(f'<model name="{r}"><link name="base_link"><collision name="body"><geometry><box><size>.5 .4 .3</size></box></geometry></collision></link></model>' for r in ['ground-a','ground-b'])+'</world></sdf>')
 try:
  result=analyze(campaign,hub,path/'metrics',world)
  results.append({'scenario':mutation,'accepted':True,'metrics':{k:result[k] for k in ['taskCampaignSuccess','taskCount','successCount','arrivalReceiptsMatchedToPhysics','simulationDurationS','safetyMetricsPassed']}})
 except Exception as e:results.append({'scenario':mutation,'accepted':False,'error':str(e)})
def state(t,x):return {'simulationTime':t,'position':[x,0,0],'linearVelocity':[0,0,0],'angularVelocity':[0,0,0]}
trigger=state(1.,0);trigger['linearVelocity']=[.3,0,0]
for mutation,samples in [('nan_stop_position',[state(1.1,float('nan')),state(1.5,float('nan'))]),('infinite_stop_clock',[state(1.1,0),state(float('inf'),0)]),('foreign_stop_identity',[dict(state(1.1,0),robotId='wrong',clockDomain='wall'),dict(state(1.5,0),robotId='wrong',clockDomain='wall')])]:
 try: results.append({'scenario':mutation,'accepted':True,'metrics':measured_stop(samples,trigger)})
 except Exception as e:results.append({'scenario':mutation,'accepted':False,'error':str(e)})
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
source={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['scripts/analyze_gazebo_field_campaign.py','scripts/run_gazebo_stop_checks.py','tests/scripts/test_analyze_gazebo_field_campaign.py','tests/scripts/test_gazebo_stop_checks.py']}
(out/'source.json').write_text(json.dumps({'reportedBaselineCommit':'79a8c3553','sha256':source},indent=2)+'\n')
print(json.dumps(results,indent=2))
