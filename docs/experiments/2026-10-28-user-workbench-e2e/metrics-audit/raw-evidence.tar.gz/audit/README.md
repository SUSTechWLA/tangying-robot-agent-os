# Gazebo 任务、收尾与停止指标独立审计

日期：2026-10-28（Asia/Shanghai）。父任务提供的当前基线为 `79a8c3553`；本审计没有运行 Git 或 Docker，没有发机器人命令、调用模型、启动新物理任务。生产修复仅限两个公共指标脚本及对应两个测试文件。

## 结论

归档完整性校验183/183文件通过。旧物理数据重新计算仍支持**3/3条完整固定路线、30次导航+30次独立到达确认、6/6停止测试**；原有数值未改变。此结论属于原 `robot.task` deterministic/legacy 入口、Gazebo刚体和回环ROS2链路，不是本轮用户浏览器任务或新GOAL/Host链路的运行结果。

- 保守包围球最小采样间隙为 `0.09590039787802385 m`。UAV接触计数覆盖不足，严格安全指标继续为 `false/not_fully_verified`。
- 3个SQLite任务终态都是SUCCEEDED，均有连续166条事件，其中包括终态 `state.transition` 和 `LOCAL_RUN_SUCCEEDED`。ground-a与ground-b的final API JSON仅164条，早于SQLite最后两条收尾事件；uav-a的final JSON为166条。旧JSON保持原样。
- 改进后任务状态、持久任务收尾和安全验证分开输出。实际旧档案的 `taskJournalsVerified=true`、`endToEndClosureVerified=true`，含义严格限定为该legacy robot.task路线及本地任务日志闭环；不声称GOAL/Host/硬件已验证。
- 主任务physics共983帧，其中970帧在campaign时间窗内；最大相邻仿真采样间隔0.10000000000000853秒，最大墙钟间隔222ms，最大机器人状态相对帧时钟滞后0.02200000000000557秒；停止数据111帧，最大墙钟采样间隔175ms。均无源序号/仿真时钟/墙钟回退。
- scan与IMU计数在主任务970个采样窗口都存在并推进。这仅证明通道计数可见和推进，不证明标定正确、连续新鲜或完整避碰覆盖。

## 真实缺陷与修复边界

1. **非有限数值与身份缺口**：旧分析器接受foreign robot/clock/world/frame以及NaN全局时钟，仍给出安全成功；旧stop函数接受NaN坐标，输出最大位移0、停稳true以及NaN路程。现在验证有限值、维度、仿真时间、源序号/时钟单调性、状态完整机器人集合、已有身份字段一致性，并拒绝派生溢出。错误指标不再写出JSON NaN/Infinity。
2. **到达时间边界**：保留原有速度、位姿和命令后仿真时间判据，新增有限准入时钟、准入帧时间先后和campaign时间窗约束；未改变控制器阈值。
3. **完整收尾证据**：旧分析器不读SQLite，SQLite tasks=FAILED与summary/final=SUCCEEDED的矛盾也能通过。现在只读已checkpoint数据库核对状态及连续事件、终态transition、成功的LOCAL_RUN_SUCCEEDED；有非空WAL拒绝离线不完整快照。无数据库或缺终态事件可继续给出已保存的数值，但闭环收尾标为未验证。API终态轮询早于收尾落盘是旧runner的观察时机限制，当前未改runner；新E2E应等待journal闭环标记后再保存最终快照。
4. **成功分母**：漏跑seed时旧taskCount只计算已经返回终态的条目。保留此字段的原含义，新增plannedTaskCount、observedTerminalTaskCount、unobservedTaskCount、missingDeclaredTrials、successRateOverPlannedTasks；例：计划2个仅完成1个，计划分母成功率为0.5。非终态task不再混入终态统计。
5. **停止失败归因**：增加计划、尝试准入、已准入、实际物理触发、跳过分母；区分measurement/admission/motion-readiness/physical-stop/cleanup失败。旧失败轮列出6项，但实际只有3次goal准入尝试、0次建立运动并触发停止、另3项跳过。它不是0/6实际制动成功率。
6. **旧格式兼容**：field transport逻辑worldId是`field-validation`，与SDF world名`field_validation`不同，未做错误字符串等同。缺worldId等旧元数据时保持数值可读但identity/safety/closure不宣称已验证；提供了矛盾字段则拒绝。stop缺身份不证明停稳。

## 原停止数据独立复算

|机器人|模式|触发后样本|最大位移m|仿真耗时s|低速停稳采样跨度s|结论|
|---|---|---:|---:|---:|---:|---|
|ground-a|watchdog|12|0.256076206|1.210|0.402|通过|
|ground-a|explicit_stop|9|0.115872380|0.906|0.402|通过|
|ground-b|watchdog|12|0.207591014|1.190|0.488|通过|
|ground-b|explicit_stop|8|0.057860167|0.810|0.404|通过|
|uav-a|watchdog|18|0.350692114|1.790|0.404|通过|
|uav-a|explicit_stop|16|0.205066648|1.596|0.488|通过|

每项独立检查触发前最后3个采样速度均≥0.18m/s，trigger等于加速段末样本；trigger与每个减速样本均逐字匹配原physics中同robot的状态。以独立数学运算重算位移、路程、速度、停稳时间、原因；随后再调用修复后的公共函数交叉比对。UAV结果仍是hover，非landing。离散低速样本跨度不是连续时间停止证明，新增maximumSampleGapSimulationSeconds明确采样边界。

## 验证与材料

最终定向测试：69 passed（0失败、0跳过），项目`.venv`环境，无warnings。Ruff通过。早期系统python测试的pytest-timeout插件警告和无法找到ruff的尝试记录未替代最终结果。没有运行全repo流水线。

```sh
.venv/bin/python -m pytest -q tests/scripts/test_analyze_gazebo_field_campaign.py tests/scripts/test_gazebo_stop_checks.py
.venv/bin/ruff check scripts/analyze_gazebo_field_campaign.py scripts/run_gazebo_stop_checks.py tests/scripts/test_analyze_gazebo_field_campaign.py tests/scripts/test_gazebo_stop_checks.py
python3 /tmp/user-e2e-metrics-20261028/verify_retained.py fresh-verification-directory
```

- `archive-verification.json`：公开归档SHA与183成员首次校验。
- `archive/`：只在/tmp解压的审计副本，包含SQLite，**不应整目录提交到仓库**。原归档未修改；最终校验183文件仍匹配原始哈希。
- `independent-raw-recomputation.json`：独立时钟/身份、SQLite、原停止数学复算。
- `negative-before/`与`probe_negative.py`：旧实现负例，故意保留NaN/Infinity的错误输出，不重写历史失败证据。
- `negative-after-results.json`：同一负例输入的拒绝/明确未验证结果。
- `metrics-tests-verified.txt/xml`、`ruff-verified.txt`：最终定向测试原始输出。
- `verification-final/report.json`及`campaign/metrics.json`：冻结源码下的原值一致性与6项停止重新校验。
- `source-before/`、`source-final.json`、`metrics-fixes.patch`：审计前源码与最终SHA/差异。

哈希保证字节身份，不认证物理实验真实发生；field transport identity校验也不是跨主机签名/来源认证。离散采样不能排除采样间碰撞，接触计数缺失不能推成无碰撞。原始归档含固定地面真实值定位与集中式hub的边界没有改变。
